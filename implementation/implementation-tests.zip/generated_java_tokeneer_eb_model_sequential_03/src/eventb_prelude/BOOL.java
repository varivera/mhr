package eventb_prelude;

/** a class to represent type BOOL as a set in JML 
 * @author Nestor Catano.
 */

public class BOOL extends BSet<Boolean> {
	public static final BOOL instance = new BOOL();
	
	/*@ public static initially BOOL.instance.has(true) && BOOL.instance.has(false); */
	
	private BOOL() {
		add(true);
		add(false);
	}
	
	public static boolean implication(boolean p, boolean q){
		return (!p || q);
	}
	
	public static boolean bi_implication(boolean p, boolean q){
		return (p && q) || (!p && !q);
	}
}