package eventb_prelude;

/** a class to model B sets in Java 
 * @author Nestor Catano
 */

import java.util.Iterator;
import java.util.TreeSet;

import tokeneer_eb_model_sequential.Test_ref6_admin;

public class BSet<E> extends TreeSet<E> implements Comparable<E> {

	/*@ public static invariant EMPTY.int_size() == 0; */

	public static BSet EMPTY = new BSet();

	/*@ assignable \nothing;
	    ensures \result != null && \result.int_size() == 1 && \result.has(elem);
	 */
	public static <EE> BSet<EE> singleton(EE elem) {
		BSet<EE> res = new BSet<EE>();
		res.add(elem);
		return res;
	}

	//@ ensures \result == this.size();
	public int int_size(){
		return this.size();
	}

	/*@ ensures \result <==> this.has(obj);*/
	public /*@ pure */ boolean has(Object obj) {
		return contains(obj);
	}

	//@ ensures \result <==> this.size() == 1;
	public /*@ pure */ boolean isSingleton(){
		return (size() == 1);
	}

	/*@ ensures this.isEmpty();*/
	public /*@ pure */ BSet() {	}

	/** for implementing set extension */
	/*@ ensures (\forall int i; i >= 0 && i < elems.length ==> this.has(elems[i]));*/
	public BSet(E ... elems) {
		this();
		for (E e : elems) {
			add(e);
		}
	}

	/*@ ensures (\forall E e; elems.contains(e) ==> this.has(e));*/
	public BSet(TreeSet<E> elems) {
		this();
		for (E e : elems)
			add(e);
	}

	/*@ ensures \result.equals(this.add(elem));*/
	public /*@ pure */ BSet<E> insert(E elem) {
		BSet<E> res = new BSet<E>();
		res.addAll(this);

		res.add(elem);
		return res;
	}

	/*@ ensures this.equals(\old(this).add(elem));*/
	public void insertInPlace(E elem) {
		add(elem);
	}

	//@ ensures !\result.contains(elem);
	public /*@ pure */ BSet<E> delete(E elem) {
		BSet<E> res = new BSet<E>();
		for(E e : this)
			if(!e.equals(elem))
				res.add(e);
		return res;
	}

	//@ ensures !this.contains(elem);
	public void deleteInPlace(E elem) {
		remove(elem);
	}

	/*@ ensures \result <==> (\forall E e; c.contains(e); this.has(e));*/
	public /*@ pure */ boolean containsAll(java.util.Collection<?> c) {
		return super.containsAll(c);
	}

	/*@ also assignable \nothing;
    	  ensures \result <==> obj instanceof BSet && 
              (\forall E e; ((BSet) obj).has(e) <==> this.has(e));*/
	public boolean equals(Object obj) {
		if (obj instanceof BRelation) {
			BSet s = ((BRelation) obj).toSet();
			return(size() == s.size() && containsAll(s) && s.containsAll(this));
		} 
		else if (obj instanceof BSet) {
			BSet s = (BSet) obj;

			return(size() == s.size() && containsAll(s) && s.containsAll(this));
		}
		else return false;
	}

	/*@ ensures \result <==> (\forall E e; this.has(e); s2.contains(e));*/
	public /*@ pure */ boolean isSubset(TreeSet<E> s2) {
		if (s2 instanceof INT) {
			return true;
		} else if (s2 instanceof NAT || s2 instanceof NAT1) {
			for (Object obj : this) {
				Integer i = (Integer) obj;
				if (i < 0) return false;
				else if (i == 0 && s2 instanceof NAT1) return false;
			}
			return true;
		} else {
			return s2.containsAll(this);
		}
	}

	/*@ ensures \result <==> this.isSubset(s2) && !this.equals(s2);*/
	public /*@ pure */ boolean isProperSubset(BSet<E> s2) {
		if (s2 instanceof INT || s2 instanceof NAT || s2 instanceof NAT1) {
			return isSubset(s2);
		} else {
			return s2.containsAll(this) && !this.containsAll(s2);
		}
	}

	/*@ ensures \result <==> s2.isSubset(this);*/
	public /*@ pure */ boolean isSuperset(BSet<E> s2) {
		return s2.isSubset(this);
	}

	/*@ ensures \result <==> s2.isProperSubset(this);*/
	public /*@ pure */ boolean isProperSuperset(BSet<E> s2) {
		return s2.isProperSubset(this);
	}


	//@ ensures \result.equals(this.first());
	public /*@ pure */ E choose() {
		//return iterator().next();
		return first();
	}

	/*@ensures (\forall E e; \result.has(e) <==> this.has(e) || s2.contains(e));*/
	public /*@ pure */ BSet<E> union(TreeSet<E> s2) {
		if (s2 instanceof INT) {
			return (BSet<E>) s2;
		} else if (s2 instanceof NAT || s2 instanceof NAT1) {
			for (Object obj : this) {
				Integer i = (Integer) obj;
				if (i < 0) throw new UnsupportedOperationException("Error: can't union with NAT.");
				else if (i == 0 && s2 instanceof NAT1) throw new UnsupportedOperationException("Error: can't union with NAT1.");
			}
			return (BSet<E>) s2;
		} else {
			BSet<E> res = new BSet<E>();
			res.addAll(this);

			for (E e : s2)
				res.add(e);
			return res;
		}
	}

	//@ ensures this.equals(\old(this).union(s2));
	public void unionInPlace(TreeSet<E> s2) {
		if (s2 instanceof INT) {
			clear();
			addAll(s2);
		} else if (s2 instanceof NAT || s2 instanceof NAT1) {
			for (Object obj : this) {
				Integer i = (Integer) obj;
				if (i < 0) throw new UnsupportedOperationException("Error: can't union with NAT.");
				else if (i == 0 && s2 instanceof NAT1) throw new UnsupportedOperationException("Error: can't union with NAT1.");
			}
			clear();
			addAll(s2);
		} else {				
			for (E e : s2)
				add(e);
		}
	}

	/*@ ensures \result.isEmpty();*/
	public /*@ pure */ static <E> BSet<E> union() {
		return new BSet<E>();
	}

	/*@ensures (\forall E e; \result.has(e) <==>
	(\exists int i; 0 <= 1 && i < sets.length; sets[i].has(e)));*/
	public /*@ pure */ static <E> BSet<E> union(BSet<E> ... sets) {
		BSet<E> res = new BSet<E>();
		for (BSet<E> set : sets) {
			res.unionInPlace(set);
		}
		return res;
	}

	/*@ ensures (\forall E e; \result.has(e) <==> 
	(\exists int i; 0 <= 1 && i < elems.length; elems[i].equals(e)));*/
	public /*@ pure */ static <E> BSet<E> extension(E ... elems) {
		BSet<E> res = new BSet<E>();
		for (E e : elems) {
			res.add(e);
		}
		return res;
	}	

	/*@ ensures (\forall E e; \result.has(e) <==> this.has(e) && s2.contains(e));*/
	public /*@ pure */ BSet<E> intersection(TreeSet<E> s2) {
		if (s2 instanceof INT) {
			BSet<E> res = (BSet<E>) clone();
			return res;
		} else if (s2 instanceof NAT || s2 instanceof NAT1) {
			BSet<E> res = (BSet<E>) clone();
			for (E obj : this) {
				Integer i = (Integer) obj;
				if (i < 0) res.remove(obj);
				else if (i == 0 && s2 instanceof NAT1) res.remove(obj);				
			}
			return res;
		} else {
			BSet<E> res = new  BSet<E>(); // the empty set

			for (E e : s2) { 
				if (contains(e)) {
					res.add(e);
				}
			}
			return res;
		}
	}

	/*@ ensures (\forall E e; this.has(e) <==> \old(this).has(e) && s2.contains(e));*/
	public void intersectionInPlace(TreeSet<E> s2) {
		if (s2 instanceof INT) {
			//
		} else if (s2 instanceof NAT || s2 instanceof NAT1) {
			for (E obj : this) {
				Integer i = (Integer) obj;
				if (i < 0) remove(obj);
				else if (i == 0 && s2 instanceof NAT1) remove(obj);				
			}
		} else {
			clear(); //TODO why clear?
			for (E e : s2) { 
				if (contains(e))
					add(e);
			}
		}
	}

	/*@ensures (\forall E e; \result.has(e) <==>
          (\forall int i; 0 <= 1 && i < sets.length; sets[i].has(e)));*/
	public /*@ pure */ static <E> BSet<E> intersection(BSet<E> ... sets) {
		BSet<E> res = sets[0];
		for (int i = 1; i < sets.length; i++) {
			res.intersectionInPlace(sets[i]);
		}
		return res;
	}

	/*@ public exceptional_behavior
	    signals (IllegalStateException);*/
	public /*@ pure */ static <E> BSet<E> intersection() {
		throw new IllegalStateException("Error: generalized intersection over 0 sets.");
	}

	/*@ ensures (\forall E e; \result.has(e) <==> this.has(e) && !s2.contains(e));*/
	public /*@ pure */ BSet<E> difference(TreeSet<E> s2) {
		if (s2 instanceof INT) {
			return new BSet<E>(); // the empty set
		} else if (s2 instanceof NAT || s2 instanceof NAT1) {
			BSet<E> res = (BSet<E>) clone();
			for (E obj : this) {
				Integer i = (Integer) obj;
				if (i > 0) res.remove(obj);
				else if (i == 0 && s2 instanceof NAT) res.remove(obj);
			}
			return res;
		} else {
			BSet<E> res = (BSet<E>) clone();

			for (E e : s2) 
				if (has(e)) res.remove(e);
			return res;
		}
	}

	//@ ensures (\forall E i; s2.contains(i) ==> !this.has(i));
	public void differenceInPlace(TreeSet<E> s2) {
		if (s2 instanceof INT) {
			clear(); // the empty set
		} else if (s2 instanceof NAT || s2 instanceof NAT1) {
			for (E obj : this) {
				Integer i = (Integer) obj;
				if (i > 0) remove(obj);
				else if (i == 0 && s2 instanceof NAT) remove(obj);
			}
		} else {			
			for (E e : s2) 
				if (contains(e)) remove(e);
		}
	}

	/*@ public exceptional_behavior
		signals (UnsupportedOperationException);*/
	public /*@ pure */ TreeSet<TreeSet<E>> powerSet() {
		throw new UnsupportedOperationException("Error: do not call powerSet through a BSet.");
	}

	/*@ also 
		ensures \result.equals(this.toString());*/
	public /*@ pure */ String toString() {
		return super.toString();
	}

	/*@ also
			ensures \result.equals(this.toArray());*/
	public /*@ pure */ Object [] toArray() {
		return super.toArray();
	}

	/*@ also
		ensures \result.equals(this.iterator());*/
	public /*@ pure */ Iterator<E> iterator() {
		return super.iterator();
	}

	/*@ ensures (\forall BSet<E> es; \result.has(es) <==> es.isSubset(this));*/
	public /*@ pure */ BSet<BSet<E>> pow() {
		BSet<BSet<E>> ps = new BSet<BSet<E>>();
		ps.add(new BSet<E>());   // add the empty set 

		// for every item in the original set
		for(E item : this) {	
			BSet<BSet<E>> newPs = new BSet<BSet<E>>();

			for (BSet<E> subset : ps) {
				// copy all of the current powerset's subsets
				newPs.add(subset);

				// plus the subsets appended with the current item
				BSet<E> newSubset = new BSet<E>(subset);
				newSubset.add(item);
				newPs.add(newSubset);
			}
			ps = newPs;
		}

		return ps;
	}

	/*@ ensures (\forall BSet<E> es; \result.has(es) <==> 
	  	es.isSubset(this) && !es.isEmpty());*/
	public /*@ pure */ BSet<BSet<E>> pow1() {
		BSet<BSet<E>> res = pow();
		BSet<E> empty = new BSet<E>();
		res.remove(empty);

		return res;
	}

	/* ensures \result <==> 
	  !(this instanceof INT || this instanceof NAT || this instanceof NAT1);*/
	public /*@ pure */ boolean finite() {
		//TODO to check
		return true;
	}

	/*TODO ensures \result <==> (\forall int i; 0 <= i && i < parts.length; 
	!(\exists int j; 0 <= j && j < parts.length; i != j && !parts[i].intersection(parts[j]).isEmpty()))
	&& (\forall E e; this.has(e) <==> (\exists int i; 0 <= i && i < parts.length; parts[i].has(e)));*/
	public /*@ pure */ static <E> boolean partition(BSet<E> ... parts) {
		BSet<E> tmp = new BSet<E>(); // the empty set

		if(parts.length == 0) return false;
		if(parts.length == 1) return true;

		for(BSet<E> part : parts) {
			if(!tmp.intersection(part).isEmpty()) return false;
			tmp.unionInPlace(part);
		}
		return true;
	}

	//@ ensures \result.equals(last());
	public /*@ pure */ E max() {
		return last();
	}

	//@ ensures \result.equals(last());
	public /*@ pure */ E min() {
		return first();
	}

	public boolean contains(Object obj) {
		return super.contains(obj);
	}
	
	/*public boolean contains(Object obj) {
		//return super.contains(obj);		
		if(obj instanceof BSet) {
			BSet<E> s = (BSet<E>) obj;
			for(E ee : this) { 
				BSet ss = (BSet<E>) ee;
				if(s.equals(ss))
				//if(s.compareTo(ss) == 0)
					return true;
			}
			return false;
		}
		else
			return super.contains(obj);
	}*/
	
	

	public int compareTo(Object o) {
		//System.out.println("HERE " + o.toString() + " this " + this.toString());
		if(o instanceof BSet) {
			BSet<E> s = (BSet<E>) o;
			Iterator<E> i1 = this.iterator();
            Iterator<E> i2 = ((BSet<E>) o).iterator();
            while (i1.hasNext() && i2.hasNext()) {
                int res = ((Comparable<E>) i1.next()).compareTo(i2.next());
                if (res != 0) return res;
            }
            if (i1.hasNext()) return 1;
            if (i2.hasNext()) return -1;
            return 0;
		}
		throw new UnsupportedOperationException("Error: can only compare sets.");
	}
	
	/*public int compareTo(Object o) {
		System.out.println("HERE");
		if(o instanceof BSet) {
			BSet<E> s = (BSet<E>) o;
			if(containsAll(s)) {
				if(s.containsAll(this)) return 0;
				return 1;
			}
			if(s.containsAll(this)) return -1;
			
			return size() >= s.size() ? 1 : -1;
		}
		throw new UnsupportedOperationException("Error: can only compare sets.");
	}*/
	
}