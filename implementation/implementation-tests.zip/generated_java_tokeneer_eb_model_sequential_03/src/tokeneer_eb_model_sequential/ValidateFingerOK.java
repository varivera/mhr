package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ValidateFingerOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ValidateFingerOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_entry_status1().equals(machine.gotFinger) && machine.get_fingerprint().has(currentFinger) && machine.get_goodFP().apply(currentFinger).equals(machine.goodF) && machine.get_userTokenPresence().equals(machine.present)); @*/
	public boolean guard_ValidateFingerOK( Integer currentFinger) {
		return (machine.get_entry_status1().equals(machine.gotFinger) && machine.get_fingerprint().has(currentFinger) && machine.get_goodFP().apply(currentFinger).equals(machine.goodF) && machine.get_userTokenPresence().equals(machine.present));
	}

	/*@ requires guard_ValidateFingerOK(currentFinger);
		assignable machine.entry_status1, machine.displayMessage1;
		ensures guard_ValidateFingerOK(currentFinger) &&  machine.get_entry_status1() == \old(machine.waitingUpdateToken) &&  machine.get_displayMessage1() == \old(machine.wait); 
	 also
		requires !guard_ValidateFingerOK(currentFinger);
		assignable \nothing;
		ensures true; @*/
	public void run_ValidateFingerOK( Integer currentFinger){
		if(guard_ValidateFingerOK(currentFinger)) {
			Integer entry_status1_tmp = machine.get_entry_status1();
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_entry_status1(machine.waitingUpdateToken);
			machine.set_entry_status2(machine.waitingUpdateToken);
			machine.set_displayMessage1(machine.wait);
			machine.set_displayMessage2(machine.wait);
			machine.set_displayMessage3(machine.wait);

			System.out.println("ValidateFingerOK executed currentFinger: " + currentFinger + " ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
