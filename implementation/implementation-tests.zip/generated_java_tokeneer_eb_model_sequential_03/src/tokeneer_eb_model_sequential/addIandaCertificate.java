package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class addIandaCertificate{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public addIandaCertificate(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.CERTIFICATES.difference(machine.get_certificates()).has(p_ce) && machine.SERIAL_NUMBER.difference(machine.get_serial()).has(p_serial) && machine.get_issuer().has(p_issuer) && machine.get_publicKeys().has(p_pubkey) && NAT.instance.has(p_period) && !machine.get_isValidatedBy().has(new Pair<Integer,Integer>(p_ce,p_pubkey)) && !machine.get_validityPeriods().domain().has(p_ce) && !machine.get_isValidatedBy().domain().has(p_ce) && !machine.get_isValidatedBy().range().has(p_pubkey) && !machine.get_attCert().has(p_ce) && !machine.get_IDCert().has(p_ce) && machine.get_IDCert().has(p_id_cert) && machine.get_fingerprint().difference(machine.get_iandaCertfpTemplate().range()).has(p_fingerPrint) && !machine.get_iandaCertfpTemplate().domain().has(p_ce) && !machine.get_iandaCertfpTemplate().has(new Pair<Integer,Integer>(p_ce,p_fingerPrint)) && machine.get_tokenID().difference(machine.get_attcert_tokenID().range()).has(p_tid) && !machine.get_attcert_tokenID().domain().has(p_ce)); @*/
	public boolean guard_addIandaCertificate( Integer p_id_cert, Integer p_fingerPrint, Integer p_ce, Integer p_tid, Integer p_serial, BSet<Integer> p_issuer, Integer p_period, Integer p_pubkey) {
		return (machine.CERTIFICATES.difference(machine.get_certificates()).has(p_ce) && machine.SERIAL_NUMBER.difference(machine.get_serial()).has(p_serial) && machine.get_issuer().has(p_issuer) && machine.get_publicKeys().has(p_pubkey) && NAT.instance.has(p_period) && !machine.get_isValidatedBy().has(new Pair<Integer,Integer>(p_ce,p_pubkey)) && !machine.get_validityPeriods().domain().has(p_ce) && !machine.get_isValidatedBy().domain().has(p_ce) && !machine.get_isValidatedBy().range().has(p_pubkey) && !machine.get_attCert().has(p_ce) && !machine.get_IDCert().has(p_ce) && machine.get_IDCert().has(p_id_cert) && machine.get_fingerprint().difference(machine.get_iandaCertfpTemplate().range()).has(p_fingerPrint) && !machine.get_iandaCertfpTemplate().domain().has(p_ce) && !machine.get_iandaCertfpTemplate().has(new Pair<Integer,Integer>(p_ce,p_fingerPrint)) && machine.get_tokenID().difference(machine.get_attcert_tokenID().range()).has(p_tid) && !machine.get_attcert_tokenID().domain().has(p_ce));
	}

	/*@ requires guard_addIandaCertificate(p_id_cert,p_fingerPrint,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey);
		assignable machine.certificates, machine.serial, machine.certificateIssuer, machine.certificateID, machine.validityPeriods, machine.isValidatedBy, machine.attCert, machine.attcert_baseCertID, machine.iandaCert, machine.iandaCertfpTemplate, machine.attcert_tokenID;
		ensures guard_addIandaCertificate(p_id_cert,p_fingerPrint,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey) &&  machine.get_certificates().equals(\old((machine.get_certificates().union(new BSet<Integer>(p_ce))))) &&  machine.get_serial().equals(\old((machine.get_serial().union(new BSet<Integer>(p_serial))))) &&  machine.get_certificateIssuer().equals(\old((machine.get_certificateIssuer().union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(p_ce,p_issuer)))))) &&  machine.get_certificateID().equals(\old((machine.get_certificateID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_serial)))))) &&  machine.get_validityPeriods().equals(\old((machine.get_validityPeriods().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_period)))))) &&  machine.get_isValidatedBy().equals(\old((machine.get_isValidatedBy().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey)))))) &&  machine.get_attCert().equals(\old((machine.get_attCert().union(new BSet<Integer>(p_ce))))) &&  machine.get_attcert_baseCertID().equals(\old((machine.get_attcert_baseCertID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_serial,machine.get_certificateID().apply(p_id_cert))))))) &&  machine.get_iandaCert().equals(\old((machine.get_iandaCert().union(new BSet<Integer>(p_ce))))) &&  machine.get_iandaCertfpTemplate().equals(\old((machine.get_iandaCertfpTemplate().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_fingerPrint)))))) &&  machine.get_attcert_tokenID().equals(\old((machine.get_attcert_tokenID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_tid)))))); 
	 also
		requires !guard_addIandaCertificate(p_id_cert,p_fingerPrint,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey);
		assignable \nothing;
		ensures true; @*/
	public void run_addIandaCertificate( Integer p_id_cert, Integer p_fingerPrint, Integer p_ce, Integer p_tid, Integer p_serial, BSet<Integer> p_issuer, Integer p_period, Integer p_pubkey){
		if(guard_addIandaCertificate(p_id_cert,p_fingerPrint,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey)) {
			BSet<Integer> certificates_tmp = machine.get_certificates();
			BSet<Integer> serial_tmp = machine.get_serial();
			BRelation<Integer,BSet<Integer>> certificateIssuer_tmp = machine.get_certificateIssuer();
			BRelation<Integer,Integer> certificateID_tmp = machine.get_certificateID();
			BRelation<Integer,Integer> validityPeriods_tmp = machine.get_validityPeriods();
			BRelation<Integer,Integer> isValidatedBy_tmp = machine.get_isValidatedBy();
			BSet<Integer> attCert_tmp = machine.get_attCert();
			BRelation<Integer,Integer> attcert_baseCertID_tmp = machine.get_attcert_baseCertID();
			BSet<Integer> iandaCert_tmp = machine.get_iandaCert();
			BRelation<Integer,Integer> iandaCertfpTemplate_tmp = machine.get_iandaCertfpTemplate();
			BRelation<Integer,Integer> attcert_tokenID_tmp = machine.get_attcert_tokenID();

			machine.set_certificates((certificates_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_serial((serial_tmp.union(new BSet<Integer>(p_serial))));
			machine.set_certificateIssuer((certificateIssuer_tmp.union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(p_ce,p_issuer)))));
			machine.set_certificateID((certificateID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_serial)))));
			machine.set_validityPeriods((validityPeriods_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_period)))));
			machine.set_isValidatedBy((isValidatedBy_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey)))));
			machine.set_attCert((attCert_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_attcert_baseCertID((attcert_baseCertID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_serial,certificateID_tmp.apply(p_id_cert))))));
			machine.set_iandaCert((iandaCert_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_iandaCertfpTemplate((iandaCertfpTemplate_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_fingerPrint)))));
			machine.set_attcert_tokenID((attcert_tokenID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_tid)))));

			System.out.println("addIandaCertificate executed p_id_cert: " + p_id_cert + " p_fingerPrint: " + p_fingerPrint + " p_tid: " + p_tid + " p_ce: " + p_ce + " p_serial: " + p_serial + " p_pubkey: " + p_pubkey + " p_period: " + p_period + " p_issuer: " + p_issuer + " ");
		}
	}

}
