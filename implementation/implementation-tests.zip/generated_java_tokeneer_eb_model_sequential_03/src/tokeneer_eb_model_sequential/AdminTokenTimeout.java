package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class AdminTokenTimeout{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public AdminTokenTimeout(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus2().equals(machine.enclaveQuiescent) && machine.get_adminTokenPresence().equals(machine.present) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && NAT.instance.has(currentTime) && !(machine.get_tokenID().has(machine.get_currentAdminToken()) && machine.get_goodTok().apply(machine.get_currentAdminToken()).equals(machine.goodT) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken()))) && machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.AdminPrivilege.has(machine.get_authCertRole().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_validityPeriods().image(new BSet<Integer>(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).has(currentTime))); @*/
	public boolean guard_AdminTokenTimeout( Integer currentTime) {
		return (
				machine.get_enclaveStatus2().equals(machine.enclaveQuiescent) && 
				machine.get_adminTokenPresence().equals(machine.present) && 
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				!machine.get_rolePresent().equals(machine.NoRole) && 
				NAT.instance.has(currentTime) && 
				!(machine.get_tokenID().has(machine.get_currentAdminToken()) && 
				 machine.get_goodTok().apply(machine.get_currentAdminToken()).equals(machine.goodT) && 
				 machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken()))) && 
				machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken())))) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken())))) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.AdminPrivilege.has(machine.get_authCertRole().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_validityPeriods().image(new BSet<Integer>(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).has(currentTime)));
	}

	/*@ requires guard_AdminTokenTimeout(currentTime);
		assignable machine.enclaveStatus2;
		ensures guard_AdminTokenTimeout(currentTime) &&  machine.get_enclaveStatus2() == \old(machine.waitingRemoveAdminTokenFail); 
	 also
		requires !guard_AdminTokenTimeout(currentTime);
		assignable \nothing;
		ensures true; @*/
	public void run_AdminTokenTimeout( Integer currentTime){
		if(guard_AdminTokenTimeout(currentTime)) {
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();

			machine.set_enclaveStatus1(machine.waitingRemoveAdminTokenFail);
			machine.set_enclaveStatus2(machine.waitingRemoveAdminTokenFail);

			System.out.println("AdminTokenTimeout executed currentTime: " + currentTime + " ");
		}
	}

}
