package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class RequestEnrolment{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public RequestEnrolment(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_floppyPresence().equals(machine.absent) && machine.get_enclaveStatus1().equals(machine.notEnrolled)); @*/
	public boolean guard_RequestEnrolment() {
		return (
				machine.get_floppyPresence().equals(machine.absent) && 
				machine.get_enclaveStatus1().equals(machine.notEnrolled));
	}

	/*@ requires guard_RequestEnrolment();
		assignable machine.screenMsg1, machine.displayMessage2;
		ensures guard_RequestEnrolment() &&  machine.get_screenMsg1() == \old(machine.insertEnrolmentData) &&  machine.get_displayMessage2() == \old(machine.blank); 
	 also
		requires !guard_RequestEnrolment();
		assignable \nothing;
		ensures true; @*/
	public void run_RequestEnrolment(){
		if(guard_RequestEnrolment()) {
			Integer screenMsg1_tmp = machine.get_screenMsg1();
			Integer displayMessage2_tmp = machine.get_displayMessage2();

			machine.set_screenMsg1(machine.insertEnrolmentData);
			machine.set_screenMsg2(machine.insertEnrolmentData);
			machine.set_displayMessage1(machine.blank);
			machine.set_displayMessage2(machine.blank);
			machine.set_displayMessage3(machine.blank);

			System.out.println("RequestEnrolment executed ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg1()));
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage2()));
		}
	}

}
