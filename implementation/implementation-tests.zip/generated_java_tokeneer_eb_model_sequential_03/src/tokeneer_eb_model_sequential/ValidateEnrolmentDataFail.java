package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ValidateEnrolmentDataFail{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ValidateEnrolmentDataFail(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.FLOPPY.has(p_currentFloppy) && !machine.get_enrolmentFile().image(new BSet<Integer>(p_currentFloppy)).isSubset(machine.get_validEnrol()) && machine.get_enclaveStatus1().equals(machine.waitingEnrol)); @*/
	public boolean guard_ValidateEnrolmentDataFail( Integer p_currentFloppy) {
		return (
				machine.FLOPPY.has(p_currentFloppy) && 
				!machine.get_enrolmentFile().image(new BSet<Integer>(p_currentFloppy)).
					isSubset(machine.get_validEnrol()) && 
				machine.get_enclaveStatus1().equals(machine.waitingEnrol)
				
				);
	}

	/*@ requires guard_ValidateEnrolmentDataFail(p_currentFloppy,p_cert_floopy);
		assignable machine.screenMsg1, machine.enclaveStatus1, machine.displayMessage2;
		ensures guard_ValidateEnrolmentDataFail(p_currentFloppy,p_cert_floopy) &&  machine.get_screenMsg1() == \old(machine.enrolmentFailed) &&  machine.get_enclaveStatus1() == \old(machine.waitingEndEnrol) &&  machine.get_displayMessage2() == \old(machine.blank); 
	 also
		requires !guard_ValidateEnrolmentDataFail(p_currentFloppy,p_cert_floopy);
		assignable \nothing;
		ensures true; @*/
	public void run_ValidateEnrolmentDataFail( Integer p_currentFloppy){
		if(guard_ValidateEnrolmentDataFail(p_currentFloppy)) {
			Integer screenMsg1_tmp = machine.get_screenMsg1();
			Integer enclaveStatus1_tmp = machine.get_enclaveStatus1();
			Integer displayMessage2_tmp = machine.get_displayMessage2();

			machine.set_screenMsg1(machine.enrolmentFailed);
			machine.set_screenMsg2(machine.enrolmentFailed);
			machine.set_enclaveStatus1(machine.waitingEndEnrol);
			machine.set_enclaveStatus2(machine.waitingEndEnrol);
			machine.set_displayMessage1(machine.blank);
			machine.set_displayMessage2(machine.blank);
			machine.set_displayMessage3(machine.blank);

			System.out.println("ValidateEnrolmentDataFail executed p_currentFloppy: " + p_currentFloppy + " ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg1()));
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage2()));
		}
	}

}