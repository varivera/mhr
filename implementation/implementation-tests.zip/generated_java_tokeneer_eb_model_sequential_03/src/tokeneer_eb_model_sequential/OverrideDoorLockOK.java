package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class OverrideDoorLockOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public OverrideDoorLockOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus2().equals(machine.waitingStartAdminOp) && machine.get_adminTokenPresence().equals(machine.present) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && !machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoOp) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.overrideLock) && NAT.instance.has(currentTime)); @*/
	public boolean guard_OverrideDoorLockOK( Integer currentTime) {
		return (
				machine.get_enclaveStatus2().equals(machine.waitingStartAdminOp) &&
				machine.get_adminTokenPresence().equals(machine.present) &&
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) &&
				!machine.get_rolePresent().equals(machine.NoRole) &&
				!machine.get_currentAdminOp().equals(machine.NoOp) &&
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) &&
				machine.get_currentAdminOp().equals(machine.overrideLock) &&
				NAT.instance.has(currentTime));
	}

	/*@ requires guard_OverrideDoorLockOK(currentTime);
		assignable machine.latchTimeout2, machine.alarmTimeout2, machine.screenMsg2, machine.displayMessage3, machine.enclaveStatus2;
		ensures guard_OverrideDoorLockOK(currentTime) &&  machine.get_latchTimeout2() == \old((currentTime + machine.get_latchUnlockDuration())) &&  machine.get_alarmTimeout2() == \old((currentTime + machine.get_latchUnlockDuration() + machine.get_alarmSilentDuration())) &&  machine.get_screenMsg2() == \old(machine.requestAdminOp) &&  machine.get_displayMessage3() == \old(machine.doorUnlocked) &&  machine.get_enclaveStatus2() == \old(machine.enclaveQuiescent); 
	 also
		requires !guard_OverrideDoorLockOK(currentTime);
		assignable \nothing;
		ensures true; @*/
	public void run_OverrideDoorLockOK( Integer currentTime){
		if(guard_OverrideDoorLockOK(currentTime)) {
			Integer latchTimeout2_tmp = machine.get_latchTimeout2();
			Integer alarmTimeout2_tmp = machine.get_alarmTimeout2();
			Integer screenMsg2_tmp = machine.get_screenMsg2();
			Integer displayMessage3_tmp = machine.get_displayMessage3();
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();

			machine.set_latchTimeout1((currentTime + machine.get_latchUnlockDuration()));
			machine.set_latchTimeout2((currentTime + machine.get_latchUnlockDuration()));
			machine.set_alarmTimeout1((currentTime + machine.get_latchUnlockDuration() + machine.get_alarmSilentDuration()));
			machine.set_alarmTimeout2((currentTime + machine.get_latchUnlockDuration() + machine.get_alarmSilentDuration()));
			machine.set_screenMsg1(machine.requestAdminOp);
			machine.set_screenMsg2(machine.requestAdminOp);
			machine.set_displayMessage1(machine.doorUnlocked);
			machine.set_displayMessage2(machine.doorUnlocked);
			machine.set_displayMessage3(machine.doorUnlocked);
			machine.set_enclaveStatus1(machine.enclaveQuiescent);
			machine.set_enclaveStatus2(machine.enclaveQuiescent);

			System.out.println("OverrideDoorLockOK executed currentTime: " + currentTime + " ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage3()));
		}
	}

}
