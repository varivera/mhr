package tokeneer_eb_model_sequential;

import eventb_prelude.*;
import Util.*;

public class ref6_admin{
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;

	public unlockDoorOK evt_unlockDoorOK = new unlockDoorOK(this);
	public FailedAdminTokenRemoved evt_FailedAdminTokenRemoved = new FailedAdminTokenRemoved(this);
	public ReadFingerOK evt_ReadFingerOK = new ReadFingerOK(this);
	public FinishUpdateConfigDataFail evt_FinishUpdateConfigDataFail = new FinishUpdateConfigDataFail(this);
	public addPrivCertificate evt_addPrivCertificate = new addPrivCertificate(this);
	public BioCheckRequired evt_BioCheckRequired = new BioCheckRequired(this);
	public RequestEnrolment evt_RequestEnrolment = new RequestEnrolment(this);
	public FinishArchiveLogFail evt_FinishArchiveLogFail = new FinishArchiveLogFail(this);
	public FailedEnrolFloppyRemoved evt_FailedEnrolFloppyRemoved = new FailedEnrolFloppyRemoved(this);
	public EntryNotAllowed evt_EntryNotAllowed = new EntryNotAllowed(this);
	public FinishUpdateConfigDataOK evt_FinishUpdateConfigDataOK = new FinishUpdateConfigDataOK(this);
	public StartArchiveLogWaitingFloppy evt_StartArchiveLogWaitingFloppy = new StartArchiveLogWaitingFloppy(this);
	public ValidateOpRequestFail evt_ValidateOpRequestFail = new ValidateOpRequestFail(this);
	public WriteUserTokenFail evt_WriteUserTokenFail = new WriteUserTokenFail(this);
	public BioCheckNotRequired evt_BioCheckNotRequired = new BioCheckNotRequired(this);
	public readAdminToken evt_readAdminToken = new readAdminToken(this);
	public WriteUserTokenOK evt_WriteUserTokenOK = new WriteUserTokenOK(this);
	public ValidateEnrolmentDataFail evt_ValidateEnrolmentDataFail = new ValidateEnrolmentDataFail(this);
	public addCertificate_idcert evt_addCertificate_idcert = new addCertificate_idcert(this);
	public FailedAccessTokenRemoved evt_FailedAccessTokenRemoved = new FailedAccessTokenRemoved(this);
	public TokenRemovalTimeout evt_TokenRemovalTimeout = new TokenRemovalTimeout(this);
	public ReadUserToken evt_ReadUserToken = new ReadUserToken(this);
	public OverrideDoorLockOK evt_OverrideDoorLockOK = new OverrideDoorLockOK(this);
	public AdminTokenTimeout evt_AdminTokenTimeout = new AdminTokenTimeout(this);
	public ShutdownOK evt_ShutdownOK = new ShutdownOK(this);
	public ValidateAdminTokenFail evt_ValidateAdminTokenFail = new ValidateAdminTokenFail(this);
	public addIandaCertificate evt_addIandaCertificate = new addIandaCertificate(this);
	public StartUpdateConfigWaitingFloppy evt_StartUpdateConfigWaitingFloppy = new StartUpdateConfigWaitingFloppy(this);
	public ShutdownWaitingDoor evt_ShutdownWaitingDoor = new ShutdownWaitingDoor(this);
	public ValidateFingerOK evt_ValidateFingerOK = new ValidateFingerOK(this);
	public UserTokenTear evt_UserTokenTear = new UserTokenTear(this);
	public StartUpdateConfigOK evt_StartUpdateConfigOK = new StartUpdateConfigOK(this);
	public ValidateUserTokenFail evt_ValidateUserTokenFail = new ValidateUserTokenFail(this);
	public TokenRemovedAdminLogout evt_TokenRemovedAdminLogout = new TokenRemovedAdminLogout(this);
	public BadAdminLogout evt_BadAdminLogout = new BadAdminLogout(this);
	public ValidateEnrolmentDataOK evt_ValidateEnrolmentDataOK = new ValidateEnrolmentDataOK(this);
	public StartArchiveLogOK evt_StartArchiveLogOK = new StartArchiveLogOK(this);
	public ValidateOpRequestOK evt_ValidateOpRequestOK = new ValidateOpRequestOK(this);
	public ValidateFingerFail evt_ValidateFingerFail = new ValidateFingerFail(this);
	public EntryOK evt_EntryOK = new EntryOK(this);
	public FingerTimeout evt_FingerTimeout = new FingerTimeout(this);
	public ReadEnrolmentFloppy evt_ReadEnrolmentFloppy = new ReadEnrolmentFloppy(this);
	public FinishArchiveLogOK evt_FinishArchiveLogOK = new FinishArchiveLogOK(this);
	public ValidateAdminTokenOK evt_ValidateAdminTokenOK = new ValidateAdminTokenOK(this);
	public doNothing evt_doNothing = new doNothing(this);


	/******Set definitions******/
	//@ public constraint CERTIFICATEID.equals(\old(CERTIFICATEID)); 
	public static final BSet<Integer> CERTIFICATEID = new Enumerated(min_integer,max_integer);
	
	//@ public constraint SERIAL_NUMBER.equals(\old(SERIAL_NUMBER)); 
	public static final BSet<Integer> SERIAL_NUMBER = new Enumerated(min_integer,max_integer);

	//@ public constraint CERTIFICATES.equals(\old(CERTIFICATES)); 
	public static final BSet<Integer> CERTIFICATES = new Enumerated(min_integer,max_integer);

	//@ public constraint KEYS.equals(\old(KEYS)); 
	public static final BSet<Integer> KEYS = new Enumerated(min_integer,max_integer);

	//@ public constraint USER.equals(\old(USER)); 
	public static final BSet<Integer> USER = new Enumerated(min_integer,max_integer);

	//@ public constraint FINGERPRINTTEMPLATE.equals(\old(FINGERPRINTTEMPLATE)); 
	public static final BSet<Integer> FINGERPRINTTEMPLATE = new Enumerated(min_integer,max_integer);

	//@ public constraint TOKENID.equals(\old(TOKENID)); 
	public static final BSet<Integer> TOKENID = new Enumerated(min_integer,max_integer);

	//@ public constraint LOCKING.equals(\old(LOCKING)); 
	public static final BSet<Integer> LOCKING = new Enumerated(min_integer,max_integer);

	//@ public constraint ADMIN.equals(\old(ADMIN)); 
	public static final BSet<Integer> ADMIN = new Enumerated(min_integer,max_integer);


	/******Constant definitions******/
	//@ public constraint NoRole.equals(\old(NoRole)); 
	public static final Integer NoRole = Test_ref6_admin.random_NoRole;

	//@ public constraint auditManager.equals(\old(auditManager)); 
	public static final Integer auditManager = Test_ref6_admin.random_auditManager;

	//@ public constraint confidential.equals(\old(confidential)); 
	public static final Integer confidential = Test_ref6_admin.random_confidential;

	//@ public constraint guard.equals(\old(guard)); 
	public static final Integer guard = Test_ref6_admin.random_guard;

	//@ public constraint restricted.equals(\old(restricted)); 
	public static final Integer restricted = Test_ref6_admin.random_restricted;

	//@ public constraint secret.equals(\old(secret)); 
	public static final Integer secret = Test_ref6_admin.random_secret;

	//@ public constraint securityOfficer.equals(\old(securityOfficer)); 
	public static final Integer securityOfficer = Test_ref6_admin.random_securityOfficer;

	//@ public constraint topsecret.equals(\old(topsecret)); 
	public static final Integer topsecret = Test_ref6_admin.random_topsecret;

	//@ public constraint unclassified.equals(\old(unclassified)); 
	public static final Integer unclassified = Test_ref6_admin.random_unclassified;

	//@ public constraint unmarked.equals(\old(unmarked)); 
	public static final Integer unmarked = Test_ref6_admin.random_unmarked;

	//@ public constraint userOnly.equals(\old(userOnly)); 
	public static final Integer userOnly = Test_ref6_admin.random_userOnly;

	//@ public constraint gotFinger.equals(\old(gotFinger)); 
	public static final Integer gotFinger = Test_ref6_admin.random_gotFinger;

	//@ public constraint gotUserToken.equals(\old(gotUserToken)); 
	public static final Integer gotUserToken = Test_ref6_admin.random_gotUserToken;

	//@ public constraint quiescent.equals(\old(quiescent)); 
	public static final Integer quiescent = Test_ref6_admin.random_quiescent;

	//@ public constraint waitingEntry.equals(\old(waitingEntry)); 
	public static final Integer waitingEntry = Test_ref6_admin.random_waitingEntry;

	//@ public constraint waitingFinger.equals(\old(waitingFinger)); 
	public static final Integer waitingFinger = Test_ref6_admin.random_waitingFinger;

	//@ public constraint waitingRemoveTokenFail.equals(\old(waitingRemoveTokenFail)); 
	public static final Integer waitingRemoveTokenFail = Test_ref6_admin.random_waitingRemoveTokenFail;

	//@ public constraint waitingRemoveTokenSuccess.equals(\old(waitingRemoveTokenSuccess)); 
	public static final Integer waitingRemoveTokenSuccess = Test_ref6_admin.random_waitingRemoveTokenSuccess;

	//@ public constraint waitingUpdateToken.equals(\old(waitingUpdateToken)); 
	public static final Integer waitingUpdateToken = Test_ref6_admin.random_waitingUpdateToken;

	//@ public constraint MAXTIME.equals(\old(MAXTIME)); 
	public static final Integer MAXTIME = Test_ref6_admin.random_MAXTIME;

	//@ public constraint absent.equals(\old(absent)); 
	public static final Integer absent = Test_ref6_admin.random_absent;

	//@ public constraint badFP.equals(\old(badFP)); 
	public static final Integer badFP = Test_ref6_admin.random_badFP;

	//@ public constraint badT.equals(\old(badT)); 
	public static final Integer badT = Test_ref6_admin.random_badT;

	//@ public constraint blank.equals(\old(blank)); 
	public static final Integer blank = Test_ref6_admin.random_blank;

	//@ public constraint doorUnlocked.equals(\old(doorUnlocked)); 
	public static final Integer doorUnlocked = Test_ref6_admin.random_doorUnlocked;

	//@ public constraint goodF.equals(\old(goodF)); 
	public static final Integer goodF = Test_ref6_admin.random_goodF;

	//@ public constraint goodT.equals(\old(goodT)); 
	public static final Integer goodT = Test_ref6_admin.random_goodT;

	//@ public constraint initFPTry.equals(\old(initFPTry)); 
	public static final Integer initFPTry = Test_ref6_admin.random_initFPTry;

	//@ public constraint initTokenTry.equals(\old(initTokenTry)); 
	public static final Integer initTokenTry = Test_ref6_admin.random_initTokenTry;

	//@ public constraint insertFinger.equals(\old(insertFinger)); 
	public static final Integer insertFinger = Test_ref6_admin.random_insertFinger;

	//@ public constraint noFP.equals(\old(noFP)); 
	public static final Integer noFP = Test_ref6_admin.random_noFP;

	//@ public constraint noT.equals(\old(noT)); 
	public static final Integer noT = Test_ref6_admin.random_noT;

	//@ public constraint openDoor.equals(\old(openDoor)); 
	public static final Integer openDoor = Test_ref6_admin.random_openDoor;

	//@ public constraint present.equals(\old(present)); 
	public static final Integer present = Test_ref6_admin.random_present;

	//@ public constraint removeToken.equals(\old(removeToken)); 
	public static final Integer removeToken = Test_ref6_admin.random_removeToken;

	//@ public constraint time.equals(\old(time)); 
	public static final BSet<Integer> time = Test_ref6_admin.random_time;

	//@ public constraint tokenUpdateFailed.equals(\old(tokenUpdateFailed)); 
	public static final Integer tokenUpdateFailed = Test_ref6_admin.random_tokenUpdateFailed;

	//@ public constraint wait.equals(\old(wait)); 
	public static final Integer wait = Test_ref6_admin.random_wait;

	//@ public constraint welcome.equals(\old(welcome)); 
	public static final Integer welcome = Test_ref6_admin.random_welcome;

	//@ public constraint archiveFailed.equals(\old(archiveFailed)); 
	public static final Integer archiveFailed = Test_ref6_admin.random_archiveFailed;

	//@ public constraint badFloppy.equals(\old(badFloppy)); 
	public static final Integer badFloppy = Test_ref6_admin.random_badFloppy;

	//@ public constraint busy.equals(\old(busy)); 
	public static final Integer busy = Test_ref6_admin.random_busy;

	//@ public constraint clear.equals(\old(clear)); 
	public static final Integer clear = Test_ref6_admin.random_clear;

	//@ public constraint closeDoor.equals(\old(closeDoor)); 
	public static final Integer closeDoor = Test_ref6_admin.random_closeDoor;

	//@ public constraint doingOp.equals(\old(doingOp)); 
	public static final Integer doingOp = Test_ref6_admin.random_doingOp;

	//@ public constraint emptyFloppy.equals(\old(emptyFloppy)); 
	public static final Integer emptyFloppy = Test_ref6_admin.random_emptyFloppy;

	//@ public constraint enclaveQuiescent.equals(\old(enclaveQuiescent)); 
	public static final Integer enclaveQuiescent = Test_ref6_admin.random_enclaveQuiescent;

	//@ public constraint enrolmentFailed.equals(\old(enrolmentFailed)); 
	public static final Integer enrolmentFailed = Test_ref6_admin.random_enrolmentFailed;

	//@ public constraint gotAdminToken.equals(\old(gotAdminToken)); 
	public static final Integer gotAdminToken = Test_ref6_admin.random_gotAdminToken;

	//@ public constraint insertBlankFloppy.equals(\old(insertBlankFloppy)); 
	public static final Integer insertBlankFloppy = Test_ref6_admin.random_insertBlankFloppy;

	//@ public constraint insertConfigData.equals(\old(insertConfigData)); 
	public static final Integer insertConfigData = Test_ref6_admin.random_insertConfigData;

	//@ public constraint insertEnrolmentData.equals(\old(insertEnrolmentData)); 
	public static final Integer insertEnrolmentData = Test_ref6_admin.random_insertEnrolmentData;

	//@ public constraint invalidData.equals(\old(invalidData)); 
	public static final Integer invalidData = Test_ref6_admin.random_invalidData;

	//@ public constraint invalidRequest.equals(\old(invalidRequest)); 
	public static final Integer invalidRequest = Test_ref6_admin.random_invalidRequest;

	//@ public constraint noFloppy.equals(\old(noFloppy)); 
	public static final Integer noFloppy = Test_ref6_admin.random_noFloppy;

	//@ public constraint notEnrolled.equals(\old(notEnrolled)); 
	public static final Integer notEnrolled = Test_ref6_admin.random_notEnrolled;

	//@ public constraint removeAdminToken.equals(\old(removeAdminToken)); 
	public static final Integer removeAdminToken = Test_ref6_admin.random_removeAdminToken;

	//@ public constraint requestAdminOp.equals(\old(requestAdminOp)); 
	public static final Integer requestAdminOp = Test_ref6_admin.random_requestAdminOp;

	//@ public constraint shutdown.equals(\old(shutdown)); 
	public static final Integer shutdown = Test_ref6_admin.random_shutdown;

	//@ public constraint validatingEnrolmentData.equals(\old(validatingEnrolmentData)); 
	public static final Integer validatingEnrolmentData = Test_ref6_admin.random_validatingEnrolmentData;

	//@ public constraint waitingEndEnrol.equals(\old(waitingEndEnrol)); 
	public static final Integer waitingEndEnrol = Test_ref6_admin.random_waitingEndEnrol;

	//@ public constraint waitingEnrol.equals(\old(waitingEnrol)); 
	public static final Integer waitingEnrol = Test_ref6_admin.random_waitingEnrol;

	//@ public constraint waitingFinishAdminOp.equals(\old(waitingFinishAdminOp)); 
	public static final Integer waitingFinishAdminOp = Test_ref6_admin.random_waitingFinishAdminOp;

	//@ public constraint waitingRemoveAdminTokenFail.equals(\old(waitingRemoveAdminTokenFail)); 
	public static final Integer waitingRemoveAdminTokenFail = Test_ref6_admin.random_waitingRemoveAdminTokenFail;

	//@ public constraint waitingStartAdminOp.equals(\old(waitingStartAdminOp)); 
	public static final Integer waitingStartAdminOp = Test_ref6_admin.random_waitingStartAdminOp;

	//@ public constraint welcomeAdmin.equals(\old(welcomeAdmin)); 
	public static final Integer welcomeAdmin = Test_ref6_admin.random_welcomeAdmin;

	//@ public constraint AdminPrivilege.equals(\old(AdminPrivilege)); 
	public static final BSet<Integer> AdminPrivilege = Test_ref6_admin.random_AdminPrivilege;

	//@ public constraint NoOp.equals(\old(NoOp)); 
	public static final Integer NoOp = Test_ref6_admin.random_NoOp;

	//@ public constraint archiveLog.equals(\old(archiveLog)); 
	public static final Integer archiveLog = Test_ref6_admin.random_archiveLog;

	//@ public constraint badKB.equals(\old(badKB)); 
	public static final Integer badKB = Test_ref6_admin.random_badKB;

	//@ public constraint closed.equals(\old(closed)); 
	public static final Integer closed = Test_ref6_admin.random_closed;

	//@ public constraint noKB.equals(\old(noKB)); 
	public static final Integer noKB = Test_ref6_admin.random_noKB;
	
	//@ public constraint t1.equals(\old(t1)); 
	public static final Integer t1 = Test_ref6_admin.random_t1;

	//@ public constraint t1.equals(\old(t1)); 
	public static final Integer t2 = Test_ref6_admin.random_t2;

	//@ public constraint t1.equals(\old(t1)); 
	public static final Integer t3 = Test_ref6_admin.random_t3;
	
	//@ public constraint availableOps.equals(\old(availableOps)); 
	public static final BRelation<Integer,Integer> availableOps = Test_ref6_admin.random_availableOps;
	
	//@ public constraint open.equals(\old(open)); 
	public static final Integer open = Test_ref6_admin.random_open;

	//@ public constraint overrideLock.equals(\old(overrideLock)); 
	public static final Integer overrideLock = Test_ref6_admin.random_overrideLock;

	//@ public constraint shutdownOp.equals(\old(shutdownOp)); 
	public static final Integer shutdownOp = Test_ref6_admin.random_shutdownOp;

	//@ public constraint updateConfigData.equals(\old(updateConfigData)); 
	public static final Integer updateConfigData = Test_ref6_admin.random_updateConfigData;


	//carrier sets
	//@ public constraint CLEARENCE.equals(\old(CLEARENCE)); 
	public static final BSet<Integer> CLEARENCE = new BSet<Integer>(
			unmarked, unclassified, restricted, confidential, secret, topsecret
			);

	//@ public constraint PRIVILEGE.equals(\old(PRIVILEGE)); 
	public static final BSet<Integer> PRIVILEGE = new BSet<Integer>(
			userOnly, guard, securityOfficer, auditManager, NoRole
			);

	//@ public constraint ENTRY_STATUS.equals(\old(ENTRY_STATUS)); 
	public static final BSet<Integer> ENTRY_STATUS = new BSet<Integer>(
			quiescent, gotUserToken, waitingFinger, gotFinger, waitingUpdateToken, waitingEntry,
			waitingRemoveTokenSuccess, waitingRemoveTokenFail
			);

	//@ public constraint FINGERPRINTTRY.equals(\old(FINGERPRINTTRY)); 
	public static final BSet<Integer> FINGERPRINTTRY = new BSet<Integer>(
			badFP,noFP,initFPTry,goodF
			);
	//@ public constraint DISPLAYMESSAGE.equals(\old(DISPLAYMESSAGE)); 
	public static final BSet<Integer> DISPLAYMESSAGE = new BSet<Integer>(
			blank, welcome, insertFinger, openDoor, wait, removeToken, tokenUpdateFailed, doorUnlocked
			);

	//@ public constraint TOKENTRY.equals(\old(TOKENTRY)); 
	public static final BSet<Integer> TOKENTRY = new BSet<Integer>(
			goodT,badT , noT, initTokenTry
			);

	//@ public constraint PRESENCE.equals(\old(PRESENCE)); 
	public static final BSet<Integer> PRESENCE = new BSet<Integer>(
			absent, present
			);

	//@ public constraint ENCLAVESTATUS.equals(\old(ENCLAVESTATUS)); 
	public static final BSet<Integer> ENCLAVESTATUS = new BSet<Integer>(notEnrolled, waitingEnrol, waitingEndEnrol, enclaveQuiescent, gotAdminToken,
			waitingRemoveAdminTokenFail, waitingStartAdminOp, waitingFinishAdminOp, shutdown
			);

	//@ public constraint FLOPPY.equals(\old(FLOPPY)); 
	public static final BSet<Integer> FLOPPY = new BSet<Integer>(
			noFloppy, emptyFloppy, badFloppy
			);

	//@ public constraint SCREENTEXT.equals(\old(SCREENTEXT)); 
	public static final BSet<Integer> SCREENTEXT = new BSet<Integer>(clear, welcomeAdmin, busy, removeAdminToken, closeDoor, requestAdminOp,
			doingOp, invalidRequest, invalidData, insertEnrolmentData, validatingEnrolmentData,
			enrolmentFailed, archiveFailed, insertBlankFloppy, insertConfigData
			);

	//@ public constraint ADMINOP.equals(\old(ADMINOP)); 
	public static final BSet<Integer> ADMINOP = new BSet<Integer>(
			archiveLog, updateConfigData, overrideLock, shutdownOp, NoOp
			);

	//@ public constraint KEYBOARD.equals(\old(KEYBOARD)); 
	public static final BSet<Integer> KEYBOARD = new BSet<Integer>(
			noKB, badKB, t1, t2, t3
			);

	//@ public constraint DOOR.equals(\old(DOOR)); 
	public static final BSet<Integer> DOOR = new BSet<Integer>(
			open, closed
			);



	/******Axiom definitions******/
	/*@ public static invariant PRIVILEGE.equals(new BSet<Integer>(userOnly,guard,securityOfficer,auditManager,NoRole)); @*/
	/*@ public static invariant CLEARENCE.equals(new BSet<Integer>(unmarked,unclassified,restricted,confidential,secret,topsecret)); @*/
	/*@ public static invariant !userOnly.equals(guard); @*/
	/*@ public static invariant !userOnly.equals(securityOfficer); @*/
	/*@ public static invariant !userOnly.equals(auditManager); @*/
	/*@ public static invariant !userOnly.equals(NoRole); @*/
	/*@ public static invariant !guard.equals(securityOfficer); @*/
	/*@ public static invariant !guard.equals(auditManager); @*/
	/*@ public static invariant !guard.equals(NoRole); @*/
	/*@ public static invariant !securityOfficer.equals(auditManager); @*/
	/*@ public static invariant !securityOfficer.equals(NoRole); @*/
	/*@ public static invariant !auditManager.equals(NoRole); @*/
	/*@ public static invariant !unmarked.equals(unclassified); @*/
	/*@ public static invariant !unmarked.equals(restricted); @*/
	/*@ public static invariant !unmarked.equals(confidential); @*/
	/*@ public static invariant !unmarked.equals(secret); @*/
	/*@ public static invariant !unmarked.equals(topsecret); @*/
	/*@ public static invariant !unclassified.equals(restricted); @*/
	/*@ public static invariant !unclassified.equals(confidential); @*/
	/*@ public static invariant !unclassified.equals(secret); @*/
	/*@ public static invariant !unclassified.equals(topsecret); @*/
	/*@ public static invariant !restricted.equals(confidential); @*/
	/*@ public static invariant !restricted.equals(secret); @*/
	/*@ public static invariant !restricted.equals(topsecret); @*/
	/*@ public static invariant !confidential.equals(secret); @*/
	/*@ public static invariant !confidential.equals(topsecret); @*/
	/*@ public static invariant !secret.equals(topsecret); @*/
	/*@ public static invariant ENTRY_STATUS.equals(new BSet<Integer>(quiescent,gotUserToken,waitingFinger,gotFinger,waitingUpdateToken,waitingEntry,waitingRemoveTokenSuccess,waitingRemoveTokenFail)); @*/
	/*@ public static invariant !quiescent.equals(gotUserToken); @*/
	/*@ public static invariant !quiescent.equals(waitingFinger); @*/
	/*@ public static invariant !quiescent.equals(gotFinger); @*/
	/*@ public static invariant !quiescent.equals(waitingUpdateToken); @*/
	/*@ public static invariant !quiescent.equals(waitingEntry); @*/
	/*@ public static invariant !quiescent.equals(waitingRemoveTokenSuccess); @*/
	/*@ public static invariant !quiescent.equals(waitingRemoveTokenFail); @*/
	/*@ public static invariant !gotUserToken.equals(waitingFinger); @*/
	/*@ public static invariant !gotUserToken.equals(gotFinger); @*/
	/*@ public static invariant !gotUserToken.equals(waitingUpdateToken); @*/
	/*@ public static invariant !gotUserToken.equals(waitingEntry); @*/
	/*@ public static invariant !gotUserToken.equals(waitingRemoveTokenSuccess); @*/
	/*@ public static invariant !gotUserToken.equals(waitingRemoveTokenFail); @*/
	/*@ public static invariant !waitingFinger.equals(gotFinger); @*/
	/*@ public static invariant !waitingFinger.equals(waitingUpdateToken); @*/
	/*@ public static invariant !waitingFinger.equals(waitingEntry); @*/
	/*@ public static invariant !waitingFinger.equals(waitingRemoveTokenSuccess); @*/
	/*@ public static invariant !waitingFinger.equals(waitingRemoveTokenFail); @*/
	/*@ public static invariant !gotFinger.equals(waitingUpdateToken); @*/
	/*@ public static invariant !gotFinger.equals(waitingEntry); @*/
	/*@ public static invariant !gotFinger.equals(waitingRemoveTokenSuccess); @*/
	/*@ public static invariant !gotFinger.equals(waitingRemoveTokenFail); @*/
	/*@ public static invariant !waitingUpdateToken.equals(waitingEntry); @*/
	/*@ public static invariant !waitingUpdateToken.equals(waitingRemoveTokenSuccess); @*/
	/*@ public static invariant !waitingUpdateToken.equals(waitingRemoveTokenFail); @*/
	/*@ public static invariant !waitingEntry.equals(waitingRemoveTokenSuccess); @*/
	/*@ public static invariant !waitingEntry.equals(waitingRemoveTokenFail); @*/
	/*@ public static invariant !waitingRemoveTokenSuccess.equals(waitingRemoveTokenFail); @*/
	/*@ public static invariant FINGERPRINTTRY.equals(new BSet<Integer>(badFP,noFP,initFPTry,goodF)); @*/
	/*@ public static invariant !badFP.equals(noFP); @*/
	/*@ public static invariant !badFP.equals(initFPTry); @*/
	/*@ public static invariant !badFP.equals(goodF); @*/
	/*@ public static invariant !noFP.equals(initFPTry); @*/
	/*@ public static invariant !noFP.equals(goodF); @*/
	/*@ public static invariant !initFPTry.equals(goodF); @*/
	/*@ public static invariant DISPLAYMESSAGE.equals(new BSet<Integer>(blank,welcome,insertFinger,openDoor,wait,removeToken,tokenUpdateFailed,doorUnlocked)); @*/
	/*@ public static invariant !blank.equals(welcome); @*/
	/*@ public static invariant !blank.equals(insertFinger); @*/
	/*@ public static invariant !blank.equals(openDoor); @*/
	/*@ public static invariant !blank.equals(wait); @*/
	/*@ public static invariant !blank.equals(removeToken); @*/
	/*@ public static invariant !blank.equals(tokenUpdateFailed); @*/
	/*@ public static invariant !blank.equals(doorUnlocked); @*/
	/*@ public static invariant !welcome.equals(insertFinger); @*/
	/*@ public static invariant !welcome.equals(openDoor); @*/
	/*@ public static invariant !welcome.equals(wait); @*/
	/*@ public static invariant !welcome.equals(removeToken); @*/
	/*@ public static invariant !welcome.equals(tokenUpdateFailed); @*/
	/*@ public static invariant !welcome.equals(doorUnlocked); @*/
	/*@ public static invariant !insertFinger.equals(openDoor); @*/
	/*@ public static invariant !insertFinger.equals(wait); @*/
	/*@ public static invariant !insertFinger.equals(removeToken); @*/
	/*@ public static invariant !insertFinger.equals(tokenUpdateFailed); @*/
	/*@ public static invariant !insertFinger.equals(doorUnlocked); @*/
	/*@ public static invariant !openDoor.equals(wait); @*/
	/*@ public static invariant !openDoor.equals(removeToken); @*/
	/*@ public static invariant !openDoor.equals(tokenUpdateFailed); @*/
	/*@ public static invariant !openDoor.equals(doorUnlocked); @*/
	/*@ public static invariant !wait.equals(removeToken); @*/
	/*@ public static invariant !wait.equals(tokenUpdateFailed); @*/
	/*@ public static invariant !wait.equals(doorUnlocked); @*/
	/*@ public static invariant !removeToken.equals(tokenUpdateFailed); @*/
	/*@ public static invariant !removeToken.equals(doorUnlocked); @*/
	/*@ public static invariant !tokenUpdateFailed.equals(doorUnlocked); @*/
	/*@ public static invariant TOKENTRY.equals(new BSet<Integer>(goodT,badT,noT,initTokenTry)); @*/
	/*@ public static invariant !goodT.equals(badT); @*/
	/*@ public static invariant !goodT.equals(noT); @*/
	/*@ public static invariant !goodT.equals(initTokenTry); @*/
	/*@ public static invariant !badT.equals(noT); @*/
	/*@ public static invariant !badT.equals(initTokenTry); @*/
	/*@ public static invariant !noT.equals(initTokenTry); @*/
	/*@ public static invariant time.equals(NAT.instance); @*/
	/*@ public static invariant NAT1.instance.has(MAXTIME); @*/
	/*@ public static invariant PRESENCE.equals(new BSet<Integer>(absent,present)); @*/
	/*@ public static invariant ENCLAVESTATUS.equals(new BSet<Integer>(notEnrolled,waitingEnrol,waitingEndEnrol,enclaveQuiescent,gotAdminToken,waitingRemoveAdminTokenFail,waitingStartAdminOp,waitingFinishAdminOp,shutdown)); @*/
	/*@ public static invariant !notEnrolled.equals(waitingEnrol); @*/
	/*@ public static invariant !notEnrolled.equals(waitingEndEnrol); @*/
	/*@ public static invariant !notEnrolled.equals(enclaveQuiescent); @*/
	/*@ public static invariant !notEnrolled.equals(gotAdminToken); @*/
	/*@ public static invariant !notEnrolled.equals(waitingRemoveAdminTokenFail); @*/
	/*@ public static invariant !notEnrolled.equals(waitingStartAdminOp); @*/
	/*@ public static invariant !notEnrolled.equals(waitingFinishAdminOp); @*/
	/*@ public static invariant !notEnrolled.equals(shutdown); @*/
	/*@ public static invariant !waitingEnrol.equals(waitingEndEnrol); @*/
	/*@ public static invariant !waitingEnrol.equals(enclaveQuiescent); @*/
	/*@ public static invariant !waitingEnrol.equals(gotAdminToken); @*/
	/*@ public static invariant !waitingEnrol.equals(waitingRemoveAdminTokenFail); @*/
	/*@ public static invariant !waitingEnrol.equals(waitingStartAdminOp); @*/
	/*@ public static invariant !waitingEnrol.equals(waitingFinishAdminOp); @*/
	/*@ public static invariant !waitingEnrol.equals(shutdown); @*/
	/*@ public static invariant !waitingEndEnrol.equals(enclaveQuiescent); @*/
	/*@ public static invariant !waitingEndEnrol.equals(gotAdminToken); @*/
	/*@ public static invariant !waitingEndEnrol.equals(waitingRemoveAdminTokenFail); @*/
	/*@ public static invariant !waitingEndEnrol.equals(waitingStartAdminOp); @*/
	/*@ public static invariant !waitingEndEnrol.equals(waitingFinishAdminOp); @*/
	/*@ public static invariant !waitingEndEnrol.equals(shutdown); @*/
	/*@ public static invariant !enclaveQuiescent.equals(gotAdminToken); @*/
	/*@ public static invariant !enclaveQuiescent.equals(waitingRemoveAdminTokenFail); @*/
	/*@ public static invariant !enclaveQuiescent.equals(waitingStartAdminOp); @*/
	/*@ public static invariant !enclaveQuiescent.equals(waitingFinishAdminOp); @*/
	/*@ public static invariant !enclaveQuiescent.equals(shutdown); @*/
	/*@ public static invariant !gotAdminToken.equals(waitingRemoveAdminTokenFail); @*/
	/*@ public static invariant !gotAdminToken.equals(waitingStartAdminOp); @*/
	/*@ public static invariant !gotAdminToken.equals(waitingFinishAdminOp); @*/
	/*@ public static invariant !gotAdminToken.equals(shutdown); @*/
	/*@ public static invariant !waitingRemoveAdminTokenFail.equals(waitingStartAdminOp); @*/
	/*@ public static invariant !waitingRemoveAdminTokenFail.equals(waitingFinishAdminOp); @*/
	/*@ public static invariant !waitingRemoveAdminTokenFail.equals(shutdown); @*/
	/*@ public static invariant !waitingStartAdminOp.equals(waitingFinishAdminOp); @*/
	/*@ public static invariant !waitingStartAdminOp.equals(shutdown); @*/
	/*@ public static invariant !waitingFinishAdminOp.equals(shutdown); @*/
	/*@ public static invariant FLOPPY.equals(new BSet<Integer>(noFloppy,emptyFloppy,badFloppy)); @*/
	/*@ public static invariant !noFloppy.equals(emptyFloppy); @*/
	/*@ public static invariant !noFloppy.equals(badFloppy); @*/
	/*@ public static invariant !emptyFloppy.equals(badFloppy); @*/
	/*@ public static invariant SCREENTEXT.equals(new BSet<Integer>(clear,welcomeAdmin,busy,removeAdminToken,closeDoor,requestAdminOp,doingOp,invalidRequest,invalidData,insertEnrolmentData,validatingEnrolmentData,enrolmentFailed,archiveFailed,insertBlankFloppy,insertConfigData)); @*/
	/*@ public static invariant !clear.equals(welcomeAdmin); @*/
	/*@ public static invariant !clear.equals(busy); @*/
	/*@ public static invariant !clear.equals(removeAdminToken); @*/
	/*@ public static invariant !clear.equals(closeDoor); @*/
	/*@ public static invariant !clear.equals(requestAdminOp); @*/
	/*@ public static invariant !clear.equals(doingOp); @*/
	/*@ public static invariant !clear.equals(invalidRequest); @*/
	/*@ public static invariant !clear.equals(invalidData); @*/
	/*@ public static invariant !clear.equals(insertEnrolmentData); @*/
	/*@ public static invariant !clear.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !clear.equals(enrolmentFailed); @*/
	/*@ public static invariant !clear.equals(archiveFailed); @*/
	/*@ public static invariant !clear.equals(insertBlankFloppy); @*/
	/*@ public static invariant !clear.equals(insertConfigData); @*/
	/*@ public static invariant !welcomeAdmin.equals(busy); @*/
	/*@ public static invariant !welcomeAdmin.equals(removeAdminToken); @*/
	/*@ public static invariant !welcomeAdmin.equals(closeDoor); @*/
	/*@ public static invariant !welcomeAdmin.equals(requestAdminOp); @*/
	/*@ public static invariant !welcomeAdmin.equals(doingOp); @*/
	/*@ public static invariant !welcomeAdmin.equals(invalidRequest); @*/
	/*@ public static invariant !welcomeAdmin.equals(invalidData); @*/
	/*@ public static invariant !welcomeAdmin.equals(insertEnrolmentData); @*/
	/*@ public static invariant !welcomeAdmin.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !welcomeAdmin.equals(enrolmentFailed); @*/
	/*@ public static invariant !welcomeAdmin.equals(archiveFailed); @*/
	/*@ public static invariant !welcomeAdmin.equals(insertBlankFloppy); @*/
	/*@ public static invariant !welcomeAdmin.equals(insertConfigData); @*/
	/*@ public static invariant !busy.equals(removeAdminToken); @*/
	/*@ public static invariant !busy.equals(closeDoor); @*/
	/*@ public static invariant !busy.equals(requestAdminOp); @*/
	/*@ public static invariant !busy.equals(doingOp); @*/
	/*@ public static invariant !busy.equals(invalidRequest); @*/
	/*@ public static invariant !busy.equals(invalidData); @*/
	/*@ public static invariant !busy.equals(insertEnrolmentData); @*/
	/*@ public static invariant !busy.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !busy.equals(enrolmentFailed); @*/
	/*@ public static invariant !busy.equals(archiveFailed); @*/
	/*@ public static invariant !busy.equals(insertBlankFloppy); @*/
	/*@ public static invariant !busy.equals(insertConfigData); @*/
	/*@ public static invariant !removeAdminToken.equals(closeDoor); @*/
	/*@ public static invariant !removeAdminToken.equals(requestAdminOp); @*/
	/*@ public static invariant !removeAdminToken.equals(doingOp); @*/
	/*@ public static invariant !removeAdminToken.equals(invalidRequest); @*/
	/*@ public static invariant !removeAdminToken.equals(invalidData); @*/
	/*@ public static invariant !removeAdminToken.equals(insertEnrolmentData); @*/
	/*@ public static invariant !removeAdminToken.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !removeAdminToken.equals(enrolmentFailed); @*/
	/*@ public static invariant !removeAdminToken.equals(archiveFailed); @*/
	/*@ public static invariant !removeAdminToken.equals(insertBlankFloppy); @*/
	/*@ public static invariant !removeAdminToken.equals(insertConfigData); @*/
	/*@ public static invariant !closeDoor.equals(requestAdminOp); @*/
	/*@ public static invariant !closeDoor.equals(doingOp); @*/
	/*@ public static invariant !closeDoor.equals(invalidRequest); @*/
	/*@ public static invariant !closeDoor.equals(invalidData); @*/
	/*@ public static invariant !closeDoor.equals(insertEnrolmentData); @*/
	/*@ public static invariant !closeDoor.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !closeDoor.equals(enrolmentFailed); @*/
	/*@ public static invariant !closeDoor.equals(archiveFailed); @*/
	/*@ public static invariant !closeDoor.equals(insertBlankFloppy); @*/
	/*@ public static invariant !closeDoor.equals(insertConfigData); @*/
	/*@ public static invariant !requestAdminOp.equals(doingOp); @*/
	/*@ public static invariant !requestAdminOp.equals(invalidRequest); @*/
	/*@ public static invariant !requestAdminOp.equals(invalidData); @*/
	/*@ public static invariant !requestAdminOp.equals(insertEnrolmentData); @*/
	/*@ public static invariant !requestAdminOp.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !requestAdminOp.equals(enrolmentFailed); @*/
	/*@ public static invariant !requestAdminOp.equals(archiveFailed); @*/
	/*@ public static invariant !requestAdminOp.equals(insertBlankFloppy); @*/
	/*@ public static invariant !requestAdminOp.equals(insertConfigData); @*/
	/*@ public static invariant !doingOp.equals(invalidRequest); @*/
	/*@ public static invariant !doingOp.equals(invalidData); @*/
	/*@ public static invariant !doingOp.equals(insertEnrolmentData); @*/
	/*@ public static invariant !doingOp.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !doingOp.equals(enrolmentFailed); @*/
	/*@ public static invariant !doingOp.equals(archiveFailed); @*/
	/*@ public static invariant !doingOp.equals(insertBlankFloppy); @*/
	/*@ public static invariant !doingOp.equals(insertConfigData); @*/
	/*@ public static invariant !invalidRequest.equals(invalidData); @*/
	/*@ public static invariant !invalidRequest.equals(insertEnrolmentData); @*/
	/*@ public static invariant !invalidRequest.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !invalidRequest.equals(enrolmentFailed); @*/
	/*@ public static invariant !invalidRequest.equals(archiveFailed); @*/
	/*@ public static invariant !invalidRequest.equals(insertBlankFloppy); @*/
	/*@ public static invariant !invalidRequest.equals(insertConfigData); @*/
	/*@ public static invariant !invalidData.equals(insertEnrolmentData); @*/
	/*@ public static invariant !invalidData.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !invalidData.equals(enrolmentFailed); @*/
	/*@ public static invariant !invalidData.equals(archiveFailed); @*/
	/*@ public static invariant !invalidData.equals(insertBlankFloppy); @*/
	/*@ public static invariant !invalidData.equals(insertConfigData); @*/
	/*@ public static invariant !insertEnrolmentData.equals(validatingEnrolmentData); @*/
	/*@ public static invariant !insertEnrolmentData.equals(enrolmentFailed); @*/
	/*@ public static invariant !insertEnrolmentData.equals(archiveFailed); @*/
	/*@ public static invariant !insertEnrolmentData.equals(insertBlankFloppy); @*/
	/*@ public static invariant !insertEnrolmentData.equals(insertConfigData); @*/
	/*@ public static invariant !validatingEnrolmentData.equals(enrolmentFailed); @*/
	/*@ public static invariant !validatingEnrolmentData.equals(archiveFailed); @*/
	/*@ public static invariant !validatingEnrolmentData.equals(insertBlankFloppy); @*/
	/*@ public static invariant !validatingEnrolmentData.equals(insertConfigData); @*/
	/*@ public static invariant !enrolmentFailed.equals(archiveFailed); @*/
	/*@ public static invariant !enrolmentFailed.equals(insertBlankFloppy); @*/
	/*@ public static invariant !enrolmentFailed.equals(insertConfigData); @*/
	/*@ public static invariant !archiveFailed.equals(insertBlankFloppy); @*/
	/*@ public static invariant !archiveFailed.equals(insertConfigData); @*/
	/*@ public static invariant !insertBlankFloppy.equals(insertConfigData); @*/
	/*@ public static invariant ADMINOP.equals(new BSet<Integer>(archiveLog,updateConfigData,overrideLock,shutdownOp,NoOp)); @*/
	/*@ public static invariant !archiveLog.equals(updateConfigData); @*/
	/*@ public static invariant !archiveLog.equals(overrideLock); @*/
	/*@ public static invariant !archiveLog.equals(shutdownOp); @*/
	/*@ public static invariant !archiveLog.equals(NoOp); @*/
	/*@ public static invariant !updateConfigData.equals(overrideLock); @*/
	/*@ public static invariant !updateConfigData.equals(shutdownOp); @*/
	/*@ public static invariant !updateConfigData.equals(NoOp); @*/
	/*@ public static invariant !overrideLock.equals(shutdownOp); @*/
	/*@ public static invariant !overrideLock.equals(NoOp); @*/
	/*@ public static invariant !shutdownOp.equals(NoOp); @*/
	/*@ public static invariant AdminPrivilege.equals(new BSet<Integer>(guard,securityOfficer,auditManager,NoRole)); @*/
	/*@ public static invariant KEYBOARD.equals(new BSet<Integer>(noKB,badKB,t1,t2,t3)); @*/
	/*@ public static invariant !noKB.equals(badKB); @*/
	/*@ public static invariant !noKB.equals(t1); @*/
	/*@ public static invariant !noKB.equals(t2); @*/
	/*@ public static invariant !noKB.equals(t3); @*/
	/*@ public static invariant !noKB.equals(t1); @*/
	/*@ public static invariant !noKB.equals(t2); @*/
	/*@ public static invariant !noKB.equals(t3); @*/
	/*@ public static invariant !t1.equals(t2); @*/
	/*@ public static invariant !t1.equals(t3); @*/
	/*@ public static invariant !t2.equals(t3); @*/
	/*@ public static invariant DOOR.equals(new BSet<Integer>(open,closed)); @*/
	/*@ public static invariant !open.equals(closed); @*/
	/*@ public static invariant KEYBOARD.finite(); @*/
	/*@ public static invariant ADMINOP.finite(); @*/


	/******Variable definitions******/
	/*@ spec_public */ private Integer FingerPresence;
	/*@ spec_public */ private BSet<Integer> admin;
	/*@ spec_public */ private BRelation<Integer,Integer> adminToken;
	/*@ spec_public */ private Integer adminTokenPresence;
	/*@ spec_public */ private Integer alarmSilentDuration;
	/*@ spec_public */ private Integer alarmTimeout1;
	/*@ spec_public */ private Integer alarmTimeout2;
	/*@ spec_public */ private BSet<Integer> attCert;
	/*@ spec_public */ private BSet<Integer> authCert;
	/*@ spec_public */ private BRelation<Integer,Integer> authCertClearence;
	/*@ spec_public */ private BRelation<Integer,Integer> authCertRole;
	/*@ spec_public */ private BSet<Integer> certificates;
	/*@ spec_public */ private BSet<Integer> clearence;
	/*@ spec_public */ private BRelation<Integer,Integer> configFile;
	/*@ spec_public */ private Integer currentAdminOp;
	/*@ spec_public */ private Integer currentDoor;
	/*@ spec_public */ private Integer displayMessage1;
	/*@ spec_public */ private Integer displayMessage2;
	/*@ spec_public */ private Integer displayMessage3;
	/*@ spec_public */ private Integer enclaveStatus1;
	/*@ spec_public */ private Integer enclaveStatus2;
	/*@ spec_public */ private BRelation<Integer,Integer> enrolmentFile;
	/*@ spec_public */ private BRelation<Integer,BRelation<Integer,BSet<Integer>>> entryPeriod;
	/*@ spec_public */ private Integer entry_status1;
	/*@ spec_public */ private Integer entry_status2;
	/*@ spec_public */ private BSet<Integer> fingerprint;
	/*@ spec_public */ private BSet<Integer> fingerprintTry;
	/*@ spec_public */ private Integer floppyPresence;
	/*@ spec_public */ private BRelation<Integer,Integer> goodFP;
	/*@ spec_public */ private BRelation<Integer,Integer> goodTok;
	/*@ spec_public */ private BSet<Integer> iandaCert;
	/*@ spec_public */ private BRelation<Integer,Integer> isValidatedBy;
	/*@ spec_public */ private Integer keyedDataPresence;
	/*@ spec_public */ private BRelation<Integer,Integer> keyedOps;
	/*@ spec_public */ private Integer latchTimeout1;
	/*@ spec_public */ private Integer latchTimeout2;
	/*@ spec_public */ private Integer latchUnlockDuration;
	/*@ spec_public */ private Boolean locked;
	/*@ spec_public */ private BSet<Integer> privCert;
	/*@ spec_public */ private BRelation<Integer,Integer> privCertClearence;
	/*@ spec_public */ private BRelation<Integer,Integer> privCertRole;
	/*@ spec_public */ private BSet<Integer> privilege;
	/*@ spec_public */ private BSet<Integer> publicKeys;
	/*@ spec_public */ private Integer rolePresent;
	/*@ spec_public */ private Integer screenMsg1;
	/*@ spec_public */ private Integer screenMsg2;
	/*@ spec_public */ private BRelation<Integer,Integer> tokenAuthCert;
	/*@ spec_public */ private BSet<Integer> tokenID;
	/*@ spec_public */ private BRelation<Integer,Integer> tokenIandaCert;
	/*@ spec_public */ private BRelation<Integer,Integer> tokenPrivCert;
	/*@ spec_public */ private Integer tokenRemovalDuration;
	/*@ spec_public */ private Integer tokenRemovalTimeout;
	/*@ spec_public */ private BSet<Integer> tokenTry;
	/*@ spec_public */ private Integer userTokenPresence;
	/*@ spec_public */ private BSet<Integer> validEnrol;
	/*@ spec_public */ private BRelation<Integer,Integer> validityPeriods;
	/*@ spec_public */ private  BSet<Integer> users;
	/*@ spec_public */ private BRelation<Integer,Integer> tokenIDCert;
	/*@ spec_public */ private  BRelation<Pair<Integer,Integer>,Integer> minClearance;
	/*@ spec_public */ private  BRelation<Integer,Integer> attcert_tokenID;
	/*@ spec_public */ private  BSet<Integer> IDCert;
	/*@ spec_public */ private  BRelation<Integer,Integer> iandaCertfpTemplate;
	/*@ spec_public */ private  BSet<Integer> floppy;	
	/*@ spec_public */ private  BSet<BSet<Integer>> issuer;
	/*@ spec_public */ private  BSet<Integer> adminop;
	/*@ spec_public */ private  BSet<Integer> keyboard;
	/*@ spec_public */ private  BRelation<Integer,Integer> attcert_baseCertID;
	/*@ spec_public */ private  BRelation<Integer,Integer> idcert_subject;
	/*@ spec_public */ private  BRelation<Integer,Integer> authPeriod;
	/*@ spec_public */ private  BRelation<Integer,Integer> idcert_subjectPubK;
	/*@ spec_public */ private Integer currentAdminToken;
	/*@ spec_public */ private Integer currentToken;
	/*@ spec_public */ private BRelation<Integer,Integer> certificateID;
	/*@ spec_public */ private BRelation<BSet<Integer>,Integer> issuerKey;
	/*@ spec_public */ private BRelation<Integer,BSet<Integer>> certificateIssuer;
	/*@ spec_public */ private BSet<Integer> serial;
	



	/******Invariant definition******/
	/*@ public invariant
		serial.isSubset(SERIAL_NUMBER) &&
		users.isSubset(USER) &&
		issuer.isSubset(((users).pow())) &&
		certificates.isSubset(CERTIFICATES) &&
		publicKeys.isSubset(KEYS) &&
		certificateIssuer.isaFunction() && (BRelation.cross(INT.instance,(INT.instance).pow()).pow()).has(certificateIssuer)  && certificateIssuer.domain().equals(certificates) && certificateIssuer.range().isSubset(issuer) &&
		certificateID.isaFunction() && certificateID.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(certificateID)  && certificateID.domain().equals(certificates) && certificateID.range().isSubset(serial) &&
		(BRelation.cross(INT.instance,INT.instance).pow()).has(validityPeriods)  && validityPeriods.domain().equals(certificates) && validityPeriods.range().isSubset(NAT.instance) &&
		isValidatedBy.isaFunction() && isValidatedBy.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(isValidatedBy)  && isValidatedBy.domain().isSubset(certificates) && isValidatedBy.range().isSubset(publicKeys) &&
		IDCert.isSubset(certificates) &&
		attCert.isSubset(certificates) &&
		BSet.partition(certificates,IDCert,attCert) &&
		idcert_subject.isaFunction() && idcert_subject.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(idcert_subject)  && idcert_subject.domain().isSubset(IDCert) && idcert_subject.range().isSubset(users) &&
		idcert_subjectPubK.isaFunction() && idcert_subjectPubK.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(idcert_subjectPubK)  && idcert_subjectPubK.domain().equals(IDCert) && idcert_subjectPubK.range().isSubset(publicKeys) &&
		attcert_baseCertID.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(attcert_baseCertID)  && attcert_baseCertID.domain().isSubset(serial) && attcert_baseCertID.range().isSubset(serial) &&
		attcert_baseCertID.domain().equals(certificateID.restrictDomainTo(attCert).range()) &&
		privCert.isSubset(attCert) &&
		iandaCert.isSubset(attCert) &&
		authCert.isSubset(attCert) &&
		BSet.partition(attCert,privCert,iandaCert,authCert) &&
		privilege.isSubset(PRIVILEGE) &&
		clearence.isSubset(CLEARENCE) &&
		fingerprint.isSubset(FINGERPRINTTEMPLATE) &&
		privCertRole.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(privCertRole)  && privCertRole.domain().equals(privCert) && privCertRole.range().isSubset(privilege) &&
		privCertClearence.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(privCertClearence)  && privCertClearence.domain().equals(privCert) && privCertClearence.range().isSubset(clearence) &&
		authCertRole.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(authCertRole)  && authCertRole.domain().equals(authCert) && authCertRole.range().isSubset(privilege) &&
		authCertClearence.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(authCertClearence)  && authCertClearence.domain().equals(authCert) && authCertClearence.range().isSubset(clearence) &&
		iandaCertfpTemplate.isaFunction() && iandaCertfpTemplate.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(iandaCertfpTemplate)  && iandaCertfpTemplate.domain().equals(iandaCert) && iandaCertfpTemplate.range().isSubset(fingerprint) &&
		tokenID.isSubset(TOKENID) &&
		tokenIDCert.isaFunction() && tokenIDCert.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(tokenIDCert)  && tokenIDCert.domain().equals(tokenID) && tokenIDCert.range().isSubset(IDCert) &&
		tokenPrivCert.isaFunction() && tokenPrivCert.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(tokenPrivCert)  && tokenPrivCert.domain().equals(tokenID) && tokenPrivCert.range().isSubset(privCert) &&
		tokenIandaCert.isaFunction() && tokenIandaCert.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(tokenIandaCert)  && tokenIandaCert.domain().equals(tokenID) && tokenIandaCert.range().isSubset(iandaCert) &&
		tokenAuthCert.isaFunction() && tokenAuthCert.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(tokenAuthCert)  && tokenAuthCert.domain().isSubset(tokenID) && tokenAuthCert.range().isSubset(authCert) &&
		attcert_tokenID.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(attcert_tokenID)  && attcert_tokenID.domain().isSubset(attCert) && attcert_tokenID.range().isSubset(tokenID) &&
		ENTRY_STATUS.has(entry_status1) &&
		TOKENID.has(currentToken) &&
		issuerKey.isaFunction() && (BRelation.cross((INT.instance).pow(),INT.instance).pow()).has(issuerKey)  && issuerKey.domain().equals(issuer) && issuerKey.range().isSubset(publicKeys) &&
		fingerprintTry.isSubset(FINGERPRINTTRY) &&
		goodFP.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(goodFP)  && goodFP.domain().equals(fingerprint) && goodFP.range().isSubset(fingerprintTry) &&
		tokenTry.isSubset(TOKENTRY) &&
		goodTok.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(goodTok)  && goodTok.domain().equals(tokenID) && goodTok.range().isSubset(tokenTry) &&
		DISPLAYMESSAGE.has(displayMessage1) &&
		NAT.instance.has(latchUnlockDuration) &&
		NAT.instance.has(latchTimeout1) &&
		BOOL.instance.has(locked) &&
		 (\exists Integer currentTime;((NAT.instance.has(currentTime) && currentTime <= MAXTIME && locked == true) <==> (currentTime <= (latchTimeout1 - latchUnlockDuration) || currentTime >= latchTimeout1))) &&
		latchTimeout1 <= MAXTIME &&
		(latchTimeout1 - latchUnlockDuration) >= 0 &&
		PRESENCE.has(userTokenPresence) &&
		PRESENCE.has(FingerPresence) &&
		entryPeriod.isaFunction() && (BRelation.cross(INT.instance,BRelation.cross(INT.instance,(INT.instance).pow()).pow()).pow()).has(entryPeriod)  && entryPeriod.domain().equals(PRIVILEGE) && entryPeriod.range().isaFunction() && (BRelation.cross(INT.instance,(INT.instance).pow()).pow()).has(entryPeriod.range())  && entryPeriod.range().domain().equals(CLEARENCE) && entryPeriod.range().range().isSubset(((time).pow())) &&
		NAT.instance.has(tokenRemovalTimeout) &&
		NAT.instance.has(alarmTimeout1) &&
		NAT.instance.has(alarmSilentDuration) &&
		NAT.instance.has(tokenRemovalDuration) &&
		authPeriod.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(authPeriod)  && authPeriod.domain().equals(PRIVILEGE) && authPeriod.range().isSubset(NAT.instance) &&
		minClearance.isaFunction() && (BRelation.cross(BRelation.cross(INT.instance,INT.instance),INT.instance).pow()).has(minClearance)  && minClearance.domain().equals(BRelation.cross(CLEARENCE,CLEARENCE)) && minClearance.range().isSubset(CLEARENCE) &&
		ENCLAVESTATUS.has(enclaveStatus1) &&
		SCREENTEXT.has(screenMsg1) &&
		validEnrol.isSubset(ENROL) &&
		enrolmentFile.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(enrolmentFile)  && enrolmentFile.domain().equals(FLOPPY) && enrolmentFile.range().isSubset(ENROL) &&
		PRESENCE.has(floppyPresence) &&
		ENTRY_STATUS.has(entry_status2) &&
		DISPLAYMESSAGE.has(displayMessage2) &&
		admin.isSubset(ADMIN) &&
		adminop.isSubset(ADMINOP) &&
		keyboard.isSubset(KEYBOARD) &&
		floppy.isSubset(FLOPPY) &&
		adminToken.isaFunction() && adminToken.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(adminToken)  && adminToken.domain().equals(admin) && adminToken.range().isSubset(TOKENID) &&
		availableOps.isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(availableOps)  && availableOps.domain().equals(admin) && availableOps.range().isSubset(ADMINOP) &&
		
		keyedOps.isaFunction() && keyedOps.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(keyedOps)  && keyedOps.domain().equals(adminop) && keyedOps.range().isSubset(keyboard) &&
		 (\forall Integer admn;((admin.has(admn) && rolePresent.domain().has(admn) && rolePresent.apply(admn).equals(NoRole)) ==> (availableOps.apply(admn).equals(NoOp)))) &&
		 (\forall Integer admn;((admin.has(admn) && rolePresent.domain().has(admn) && !rolePresent.apply(admn).equals(NoRole) && rolePresent.apply(admn).equals(guard)) ==> (availableOps.apply(admn).equals(overrideLock)))) &&
		 (\forall Integer admn;((admin.has(admn) && !rolePresent.apply(admn).equals(NoRole) && rolePresent.apply(admn).equals(auditManager) && rolePresent.domain().has(admn)) ==> (availableOps.apply(admn).equals(archiveLog)))) &&
		 (\forall Integer admn;((admin.has(admn) && !rolePresent.apply(admn).equals(NoRole) && rolePresent.apply(admn).equals(securityOfficer) && rolePresent.domain().has(admn)) ==> (availableOps.apply(admn).equals(updateConfigData) || availableOps.apply(admn).equals(shutdownOp)))) &&
		PRESENCE.has(adminTokenPresence) &&
		PRESENCE.has(keyedDataPresence) &&
		configFile.isaFunction() && configFile.inverse().isaFunction() && (BRelation.cross(INT.instance,INT.instance).pow()).has(configFile)  && configFile.domain().equals(keyboard) && configFile.range().isSubset(floppy) &&
		DOOR.has(currentDoor) &&
		NAT.instance.has(alarmTimeout2) &&
		NAT.instance.has(latchTimeout2) &&
		ENCLAVESTATUS.has(enclaveStatus2) &&
		SCREENTEXT.has(screenMsg2) &&
		DISPLAYMESSAGE.has(displayMessage3) &&
		TOKENID.has(currentAdminToken); @*/


	/******Getter and Mutator methods definition******/
	/*@ requires true;
	    ensures \result == this.users;*/
	public BSet<Integer> get_users(){
		return this.users;
	}

	/*@ requires true;
	    ensures this.users == users;*/
	public void set_users(BSet<Integer> users){
		this.users = users;
	}

	/*@ requires true;
	    ensures \result == this.privCertClearence;*/
	public BRelation<Integer,Integer> get_privCertClearence(){
		return this.privCertClearence;
	}

	/*@ requires true;
	    ensures this.privCertClearence == privCertClearence;*/
	public void set_privCertClearence(BRelation<Integer,Integer> privCertClearence){
		this.privCertClearence = privCertClearence;
	}

	/*@ requires true;
	    ensures \result == this.authCertRole;*/
	public BRelation<Integer,Integer> get_authCertRole(){
		return this.authCertRole;
	}

	/*@ requires true;
	    ensures this.authCertRole == authCertRole;*/
	public void set_authCertRole(BRelation<Integer,Integer> authCertRole){
		this.authCertRole = authCertRole;
	}

	/*@ requires true;
	    ensures \result == this.attCert;*/
	public BSet<Integer> get_attCert(){
		return this.attCert;
	}

	/*@ requires true;
	    ensures this.attCert == attCert;*/
	public void set_attCert(BSet<Integer> attCert){
		this.attCert = attCert;
	}

	/*@ requires true;
	    ensures \result == this.authCert;*/
	public BSet<Integer> get_authCert(){
		return this.authCert;
	}

	/*@ requires true;
	    ensures this.authCert == authCert;*/
	public void set_authCert(BSet<Integer> authCert){
		this.authCert = authCert;
	}

	/*@ requires true;
	    ensures \result == this.iandaCert;*/
	public BSet<Integer> get_iandaCert(){
		return this.iandaCert;
	}

	/*@ requires true;
	    ensures this.iandaCert == iandaCert;*/
	public void set_iandaCert(BSet<Integer> iandaCert){
		this.iandaCert = iandaCert;
	}

	/*@ requires true;
	    ensures \result == this.validityPeriods;*/
	public BRelation<Integer,Integer> get_validityPeriods(){
		return this.validityPeriods;
	}

	/*@ requires true;
	    ensures this.validityPeriods == validityPeriods;*/
	public void set_validityPeriods(BRelation<Integer,Integer> validityPeriods){
		this.validityPeriods = validityPeriods;
	}

	/*@ requires true;
	    ensures \result == this.currentAdminToken;*/
	public Integer get_currentAdminToken(){
		return this.currentAdminToken;
	}

	/*@ requires true;
	    ensures this.currentAdminToken == currentAdminToken;*/
	public void set_currentAdminToken(Integer currentAdminToken){
		this.currentAdminToken = currentAdminToken;
	}

	/*@ requires true;
	    ensures \result == this.tokenIDCert;*/
	public BRelation<Integer,Integer> get_tokenIDCert(){
		return this.tokenIDCert;
	}

	/*@ requires true;
	    ensures this.tokenIDCert == tokenIDCert;*/
	public void set_tokenIDCert(BRelation<Integer,Integer> tokenIDCert){
		this.tokenIDCert = tokenIDCert;
	}

	/*@ requires true;
	    ensures \result == this.latchTimeout2;*/
	public Integer get_latchTimeout2(){
		return this.latchTimeout2;
	}

	/*@ requires true;
	    ensures this.latchTimeout2 == latchTimeout2;*/
	public void set_latchTimeout2(Integer latchTimeout2){
		this.latchTimeout2 = latchTimeout2;
	}

	/*@ requires true;
	    ensures \result == this.latchTimeout1;*/
	public Integer get_latchTimeout1(){
		return this.latchTimeout1;
	}

	/*@ requires true;
	    ensures this.latchTimeout1 == latchTimeout1;*/
	public void set_latchTimeout1(Integer latchTimeout1){
		this.latchTimeout1 = latchTimeout1;
	}

	/*@ requires true;
	    ensures \result == this.configFile;*/
	public BRelation<Integer,Integer> get_configFile(){
		return this.configFile;
	}

	/*@ requires true;
	    ensures this.configFile == configFile;*/
	public void set_configFile(BRelation<Integer,Integer> configFile){
		this.configFile = configFile;
	}

	/*@ requires true;
	    ensures \result == this.enrolmentFile;*/
	public BRelation<Integer,Integer> get_enrolmentFile(){
		return this.enrolmentFile;
	}

	/*@ requires true;
	    ensures this.enrolmentFile == enrolmentFile;*/
	public void set_enrolmentFile(BRelation<Integer,Integer> enrolmentFile){
		this.enrolmentFile = enrolmentFile;
	}

	/*@ requires true;
	    ensures \result == this.entryPeriod;*/
	public BRelation<Integer,BRelation<Integer,BSet<Integer>>> get_entryPeriod(){
		return this.entryPeriod;
	}

	/*@ requires true;
	    ensures this.entryPeriod == entryPeriod;*/
	public void set_entryPeriod(BRelation<Integer,BRelation<Integer,BSet<Integer>>> entryPeriod){
		this.entryPeriod = entryPeriod;
	}

	/*@ requires true;
	    ensures \result == this.minClearance;*/
	public BRelation<Pair<Integer,Integer>,Integer> get_minClearance(){
		return this.minClearance;
	}

	/*@ requires true;
	    ensures this.minClearance == minClearance;*/
	public void set_minClearance(BRelation<Pair<Integer,Integer>,Integer> minClearance){
		this.minClearance = minClearance;
	}

	/*@ requires true;
	    ensures \result == this.attcert_tokenID;*/
	public BRelation<Integer,Integer> get_attcert_tokenID(){
		return this.attcert_tokenID;
	}

	/*@ requires true;
	    ensures this.attcert_tokenID == attcert_tokenID;*/
	public void set_attcert_tokenID(BRelation<Integer,Integer> attcert_tokenID){
		this.attcert_tokenID = attcert_tokenID;
	}

	/*@ requires true;
	    ensures \result == this.goodFP;*/
	public BRelation<Integer,Integer> get_goodFP(){
		return this.goodFP;
	}

	/*@ requires true;
	    ensures this.goodFP == goodFP;*/
	public void set_goodFP(BRelation<Integer,Integer> goodFP){
		this.goodFP = goodFP;
	}

	/*@ requires true;
	    ensures \result == this.tokenRemovalDuration;*/
	public Integer get_tokenRemovalDuration(){
		return this.tokenRemovalDuration;
	}

	/*@ requires true;
	    ensures this.tokenRemovalDuration == tokenRemovalDuration;*/
	public void set_tokenRemovalDuration(Integer tokenRemovalDuration){
		this.tokenRemovalDuration = tokenRemovalDuration;
	}

	/*@ requires true;
	    ensures \result == this.alarmTimeout2;*/
	public Integer get_alarmTimeout2(){
		return this.alarmTimeout2;
	}

	/*@ requires true;
	    ensures this.alarmTimeout2 == alarmTimeout2;*/
	public void set_alarmTimeout2(Integer alarmTimeout2){
		this.alarmTimeout2 = alarmTimeout2;
	}

	/*@ requires true;
	    ensures \result == this.authCertClearence;*/
	public BRelation<Integer,Integer> get_authCertClearence(){
		return this.authCertClearence;
	}

	/*@ requires true;
	    ensures this.authCertClearence == authCertClearence;*/
	public void set_authCertClearence(BRelation<Integer,Integer> authCertClearence){
		this.authCertClearence = authCertClearence;
	}

	/*@ requires true;
	    ensures \result == this.alarmTimeout1;*/
	public Integer get_alarmTimeout1(){
		return this.alarmTimeout1;
	}

	/*@ requires true;
	    ensures this.alarmTimeout1 == alarmTimeout1;*/
	public void set_alarmTimeout1(Integer alarmTimeout1){
		this.alarmTimeout1 = alarmTimeout1;
	}

	/*@ requires true;
	    ensures \result == this.IDCert;*/
	public BSet<Integer> get_IDCert(){
		return this.IDCert;
	}

	/*@ requires true;
	    ensures this.IDCert == IDCert;*/
	public void set_IDCert(BSet<Integer> IDCert){
		this.IDCert = IDCert;
	}

	/*@ requires true;
	    ensures \result == this.iandaCertfpTemplate;*/
	public BRelation<Integer,Integer> get_iandaCertfpTemplate(){
		return this.iandaCertfpTemplate;
	}

	/*@ requires true;
	    ensures this.iandaCertfpTemplate == iandaCertfpTemplate;*/
	public void set_iandaCertfpTemplate(BRelation<Integer,Integer> iandaCertfpTemplate){
		this.iandaCertfpTemplate = iandaCertfpTemplate;
	}

	/*@ requires true;
	    ensures \result == this.publicKeys;*/
	public BSet<Integer> get_publicKeys(){
		return this.publicKeys;
	}

	/*@ requires true;
	    ensures this.publicKeys == publicKeys;*/
	public void set_publicKeys(BSet<Integer> publicKeys){
		this.publicKeys = publicKeys;
	}

	/*@ requires true;
	    ensures \result == this.tokenPrivCert;*/
	public BRelation<Integer,Integer> get_tokenPrivCert(){
		return this.tokenPrivCert;
	}

	/*@ requires true;
	    ensures this.tokenPrivCert == tokenPrivCert;*/
	public void set_tokenPrivCert(BRelation<Integer,Integer> tokenPrivCert){
		this.tokenPrivCert = tokenPrivCert;
	}

	/*@ requires true;
	    ensures \result == this.displayMessage3;*/
	public Integer get_displayMessage3(){
		return this.displayMessage3;
	}

	/*@ requires true;
	    ensures this.displayMessage3 == displayMessage3;*/
	public void set_displayMessage3(Integer displayMessage3){
		this.displayMessage3 = displayMessage3;
	}

	/*@ requires true;
	    ensures \result == this.displayMessage1;*/
	public Integer get_displayMessage1(){
		return this.displayMessage1;
	}

	/*@ requires true;
	    ensures this.displayMessage1 == displayMessage1;*/
	public void set_displayMessage1(Integer displayMessage1){
		this.displayMessage1 = displayMessage1;
	}

	/*@ requires true;
	    ensures \result == this.displayMessage2;*/
	public Integer get_displayMessage2(){
		return this.displayMessage2;
	}

	/*@ requires true;
	    ensures this.displayMessage2 == displayMessage2;*/
	public void set_displayMessage2(Integer displayMessage2){
		this.displayMessage2 = displayMessage2;
	}

	/*@ requires true;
	    ensures \result == this.floppy;*/
	public BSet<Integer> get_floppy(){
		return this.floppy;
	}

	/*@ requires true;
	    ensures this.floppy == floppy;*/
	public void set_floppy(BSet<Integer> floppy){
		this.floppy = floppy;
	}

	/*@ requires true;
	    ensures \result == this.tokenID;*/
	public BSet<Integer> get_tokenID(){
		return this.tokenID;
	}

	/*@ requires true;
	    ensures this.tokenID == tokenID;*/
	public void set_tokenID(BSet<Integer> tokenID){
		this.tokenID = tokenID;
	}

	/*@ requires true;
	    ensures \result == this.isValidatedBy;*/
	public BRelation<Integer,Integer> get_isValidatedBy(){
		return this.isValidatedBy;
	}

	/*@ requires true;
	    ensures this.isValidatedBy == isValidatedBy;*/
	public void set_isValidatedBy(BRelation<Integer,Integer> isValidatedBy){
		this.isValidatedBy = isValidatedBy;
	}

	/*@ requires true;
	    ensures \result == this.currentToken;*/
	public Integer get_currentToken(){
		return this.currentToken;
	}

	/*@ requires true;
	    ensures this.currentToken == currentToken;*/
	public void set_currentToken(Integer currentToken){
		this.currentToken = currentToken;
	}

	/*@ requires true;
	    ensures \result == this.issuer;*/
	public BSet<BSet<Integer>> get_issuer(){
		return this.issuer;
	}

	/*@ requires true;
	    ensures this.issuer == issuer;*/
	public void set_issuer(BSet<BSet<Integer>> issuer){
		this.issuer = issuer;
	}

	/*@ requires true;
	    ensures \result == this.keyedOps;*/
	public BRelation<Integer,Integer> get_keyedOps(){
		return this.keyedOps;
	}

	/*@ requires true;
	    ensures this.keyedOps == keyedOps;*/
	public void set_keyedOps(BRelation<Integer,Integer> keyedOps){
		this.keyedOps = keyedOps;
	}

	/*@ requires true;
	    ensures \result == this.tokenTry;*/
	public BSet<Integer> get_tokenTry(){
		return this.tokenTry;
	}

	/*@ requires true;
	    ensures this.tokenTry == tokenTry;*/
	public void set_tokenTry(BSet<Integer> tokenTry){
		this.tokenTry = tokenTry;
	}

	/*@ requires true;
	    ensures \result == this.locked;*/
	public Boolean get_locked(){
		return this.locked;
	}

	/*@ requires true;
	    ensures this.locked == locked;*/
	public void set_locked(Boolean locked){
		this.locked = locked;
	}

	/*@ requires true;
	    ensures \result == this.FingerPresence;*/
	public Integer get_FingerPresence(){
		return this.FingerPresence;
	}

	/*@ requires true;
	    ensures this.FingerPresence == FingerPresence;*/
	public void set_FingerPresence(Integer FingerPresence){
		this.FingerPresence = FingerPresence;
	}

	/*@ requires true;
	    ensures \result == this.userTokenPresence;*/
	public Integer get_userTokenPresence(){
		return this.userTokenPresence;
	}

	/*@ requires true;
	    ensures this.userTokenPresence == userTokenPresence;*/
	public void set_userTokenPresence(Integer userTokenPresence){
		this.userTokenPresence = userTokenPresence;
	}

	/*@ requires true;
	    ensures \result == this.latchUnlockDuration;*/
	public Integer get_latchUnlockDuration(){
		return this.latchUnlockDuration;
	}

	/*@ requires true;
	    ensures this.latchUnlockDuration == latchUnlockDuration;*/
	public void set_latchUnlockDuration(Integer latchUnlockDuration){
		this.latchUnlockDuration = latchUnlockDuration;
	}

	/*@ requires true;
	    ensures \result == this.tokenAuthCert;*/
	public BRelation<Integer,Integer> get_tokenAuthCert(){
		return this.tokenAuthCert;
	}

	/*@ requires true;
	    ensures this.tokenAuthCert == tokenAuthCert;*/
	public void set_tokenAuthCert(BRelation<Integer,Integer> tokenAuthCert){
		this.tokenAuthCert = tokenAuthCert;
	}

	/*@ requires true;
	    ensures \result == this.tokenIandaCert;*/
	public BRelation<Integer,Integer> get_tokenIandaCert(){
		return this.tokenIandaCert;
	}

	/*@ requires true;
	    ensures this.tokenIandaCert == tokenIandaCert;*/
	public void set_tokenIandaCert(BRelation<Integer,Integer> tokenIandaCert){
		this.tokenIandaCert = tokenIandaCert;
	}

	/*@ requires true;
	    ensures \result == this.adminop;*/
	public BSet<Integer> get_adminop(){
		return this.adminop;
	}

	/*@ requires true;
	    ensures this.adminop == adminop;*/
	public void set_adminop(BSet<Integer> adminop){
		this.adminop = adminop;
	}

	/*@ requires true;
	    ensures \result == this.currentAdminOp;*/
	public Integer get_currentAdminOp(){
		return this.currentAdminOp;
	}

	/*@ requires true;
	    ensures this.currentAdminOp == currentAdminOp;*/
	public void set_currentAdminOp(Integer currentAdminOp){
		this.currentAdminOp = currentAdminOp;
	}

	/*@ requires true;
	    ensures \result == this.privCertRole;*/
	public BRelation<Integer,Integer> get_privCertRole(){
		return this.privCertRole;
	}

	/*@ requires true;
	    ensures this.privCertRole == privCertRole;*/
	public void set_privCertRole(BRelation<Integer,Integer> privCertRole){
		this.privCertRole = privCertRole;
	}

	/*@ requires true;
	    ensures \result == this.adminToken;*/
	public BRelation<Integer,Integer> get_adminToken(){
		return this.adminToken;
	}

	/*@ requires true;
	    ensures this.adminToken == adminToken;*/
	public void set_adminToken(BRelation<Integer,Integer> adminToken){
		this.adminToken = adminToken;
	}

	/*@ requires true;
	    ensures \result == this.fingerprintTry;*/
	public BSet<Integer> get_fingerprintTry(){
		return this.fingerprintTry;
	}

	/*@ requires true;
	    ensures this.fingerprintTry == fingerprintTry;*/
	public void set_fingerprintTry(BSet<Integer> fingerprintTry){
		this.fingerprintTry = fingerprintTry;
	}

	/*@ requires true;
	    ensures \result == this.enclaveStatus1;*/
	public Integer get_enclaveStatus1(){
		return this.enclaveStatus1;
	}

	/*@ requires true;
	    ensures this.enclaveStatus1 == enclaveStatus1;*/
	public void set_enclaveStatus1(Integer enclaveStatus1){
		this.enclaveStatus1 = enclaveStatus1;
	}

	/*@ requires true;
	    ensures \result == this.fingerprint;*/
	public BSet<Integer> get_fingerprint(){
		return this.fingerprint;
	}

	/*@ requires true;
	    ensures this.fingerprint == fingerprint;*/
	public void set_fingerprint(BSet<Integer> fingerprint){
		this.fingerprint = fingerprint;
	}

	/*@ requires true;
	    ensures \result == this.privCert;*/
	public BSet<Integer> get_privCert(){
		return this.privCert;
	}

	/*@ requires true;
	    ensures this.privCert == privCert;*/
	public void set_privCert(BSet<Integer> privCert){
		this.privCert = privCert;
	}

	/*@ requires true;
	    ensures \result == this.enclaveStatus2;*/
	public Integer get_enclaveStatus2(){
		return this.enclaveStatus2;
	}

	/*@ requires true;
	    ensures this.enclaveStatus2 == enclaveStatus2;*/
	public void set_enclaveStatus2(Integer enclaveStatus2){
		this.enclaveStatus2 = enclaveStatus2;
	}

	/*@ requires true;
	    ensures \result == this.screenMsg1;*/
	public Integer get_screenMsg1(){
		return this.screenMsg1;
	}

	/*@ requires true;
	    ensures this.screenMsg1 == screenMsg1;*/
	public void set_screenMsg1(Integer screenMsg1){
		this.screenMsg1 = screenMsg1;
	}

	/*@ requires true;
	    ensures \result == this.certificateID;*/
	public BRelation<Integer,Integer> get_certificateID(){
		return this.certificateID;
	}

	/*@ requires true;
	    ensures this.certificateID == certificateID;*/
	public void set_certificateID(BRelation<Integer,Integer> certificateID){
		this.certificateID = certificateID;
	}

	/*@ requires true;
	    ensures \result == this.screenMsg2;*/
	public Integer get_screenMsg2(){
		return this.screenMsg2;
	}

	/*@ requires true;
	    ensures this.screenMsg2 == screenMsg2;*/
	public void set_screenMsg2(Integer screenMsg2){
		this.screenMsg2 = screenMsg2;
	}

	/*@ requires true;
	    ensures \result == this.validEnrol;*/
	public BSet<Integer> get_validEnrol(){
		return this.validEnrol;
	}

	/*@ requires true;
	    ensures this.validEnrol == validEnrol;*/
	public void set_validEnrol(BSet<Integer> validEnrol){
		this.validEnrol = validEnrol;
	}

	/*@ requires true;
	    ensures \result == this.tokenRemovalTimeout;*/
	public Integer get_tokenRemovalTimeout(){
		return this.tokenRemovalTimeout;
	}

	/*@ requires true;
	    ensures this.tokenRemovalTimeout == tokenRemovalTimeout;*/
	public void set_tokenRemovalTimeout(Integer tokenRemovalTimeout){
		this.tokenRemovalTimeout = tokenRemovalTimeout;
	}

	/*@ requires true;
	    ensures \result == this.clearence;*/
	public BSet<Integer> get_clearence(){
		return this.clearence;
	}

	/*@ requires true;
	    ensures this.clearence == clearence;*/
	public void set_clearence(BSet<Integer> clearence){
		this.clearence = clearence;
	}

	/*@ requires true;
	    ensures \result == this.certificates;*/
	public BSet<Integer> get_certificates(){
		return this.certificates;
	}

	/*@ requires true;
	    ensures this.certificates == certificates;*/
	public void set_certificates(BSet<Integer> certificates){
		this.certificates = certificates;
	}

	/*@ requires true;
	    ensures \result == this.keyboard;*/
	public BSet<Integer> get_keyboard(){
		return this.keyboard;
	}

	/*@ requires true;
	    ensures this.keyboard == keyboard;*/
	public void set_keyboard(BSet<Integer> keyboard){
		this.keyboard = keyboard;
	}

	/*@ requires true;
	    ensures \result == this.keyedDataPresence;*/
	public Integer get_keyedDataPresence(){
		return this.keyedDataPresence;
	}

	/*@ requires true;
	    ensures this.keyedDataPresence == keyedDataPresence;*/
	public void set_keyedDataPresence(Integer keyedDataPresence){
		this.keyedDataPresence = keyedDataPresence;
	}

	/*@ requires true;
	    ensures \result == this.currentDoor;*/
	public Integer get_currentDoor(){
		return this.currentDoor;
	}

	/*@ requires true;
	    ensures this.currentDoor == currentDoor;*/
	public void set_currentDoor(Integer currentDoor){
		this.currentDoor = currentDoor;
	}

	/*@ requires true;
	    ensures \result == this.alarmSilentDuration;*/
	public Integer get_alarmSilentDuration(){
		return this.alarmSilentDuration;
	}

	/*@ requires true;
	    ensures this.alarmSilentDuration == alarmSilentDuration;*/
	public void set_alarmSilentDuration(Integer alarmSilentDuration){
		this.alarmSilentDuration = alarmSilentDuration;
	}

	/*@ requires true;
	    ensures \result == this.attcert_baseCertID;*/
	public BRelation<Integer,Integer> get_attcert_baseCertID(){
		return this.attcert_baseCertID;
	}

	/*@ requires true;
	    ensures this.attcert_baseCertID == attcert_baseCertID;*/
	public void set_attcert_baseCertID(BRelation<Integer,Integer> attcert_baseCertID){
		this.attcert_baseCertID = attcert_baseCertID;
	}

	/*@ requires true;
	    ensures \result == this.entry_status1;*/
	public Integer get_entry_status1(){
		return this.entry_status1;
	}

	/*@ requires true;
	    ensures this.entry_status1 == entry_status1;*/
	public void set_entry_status1(Integer entry_status1){
		this.entry_status1 = entry_status1;
	}

	/*@ requires true;
	    ensures \result == this.entry_status2;*/
	public Integer get_entry_status2(){
		return this.entry_status2;
	}

	/*@ requires true;
	    ensures this.entry_status2 == entry_status2;*/
	public void set_entry_status2(Integer entry_status2){
		this.entry_status2 = entry_status2;
	}

	/*@ requires true;
	    ensures \result == this.issuerKey;*/
	public BRelation<BSet<Integer>,Integer> get_issuerKey(){
		return this.issuerKey;
	}

	/*@ requires true;
	    ensures this.issuerKey == issuerKey;*/
	public void set_issuerKey(BRelation<BSet<Integer>,Integer> issuerKey){
		this.issuerKey = issuerKey;
	}

	/*@ requires true;
	    ensures \result == this.rolePresent;*/
	public Integer get_rolePresent(){
		return this.rolePresent;
	}

	/*@ requires true;
	    ensures this.rolePresent == rolePresent;*/
	public void set_rolePresent(Integer rolePresent){
		this.rolePresent = rolePresent;
	}

	/*@ requires true;
	    ensures \result == this.idcert_subject;*/
	public BRelation<Integer,Integer> get_idcert_subject(){
		return this.idcert_subject;
	}

	/*@ requires true;
	    ensures this.idcert_subject == idcert_subject;*/
	public void set_idcert_subject(BRelation<Integer,Integer> idcert_subject){
		this.idcert_subject = idcert_subject;
	}

	/*@ requires true;
	    ensures \result == this.certificateIssuer;*/
	public BRelation<Integer,BSet<Integer>> get_certificateIssuer(){
		return this.certificateIssuer;
	}

	/*@ requires true;
	    ensures this.certificateIssuer == certificateIssuer;*/
	public void set_certificateIssuer(BRelation<Integer,BSet<Integer>> certificateIssuer){
		this.certificateIssuer = certificateIssuer;
	}

	/*@ requires true;
	    ensures \result == this.admin;*/
	public BSet<Integer> get_admin(){
		return this.admin;
	}

	/*@ requires true;
	    ensures this.admin == admin;*/
	public void set_admin(BSet<Integer> admin){
		this.admin = admin;
	}

	/*@ requires true;
	    ensures \result == this.floppyPresence;*/
	public Integer get_floppyPresence(){
		return this.floppyPresence;
	}

	/*@ requires true;
	    ensures this.floppyPresence == floppyPresence;*/
	public void set_floppyPresence(Integer floppyPresence){
		this.floppyPresence = floppyPresence;
	}

	/*@ requires true;
	    ensures \result == this.privilege;*/
	public BSet<Integer> get_privilege(){
		return this.privilege;
	}

	/*@ requires true;
	    ensures this.privilege == privilege;*/
	public void set_privilege(BSet<Integer> privilege){
		this.privilege = privilege;
	}

	/*@ requires true;
	    ensures \result == this.adminTokenPresence;*/
	public Integer get_adminTokenPresence(){
		return this.adminTokenPresence;
	}

	/*@ requires true;
	    ensures this.adminTokenPresence == adminTokenPresence;*/
	public void set_adminTokenPresence(Integer adminTokenPresence){
		this.adminTokenPresence = adminTokenPresence;
	}

	/*@ requires true;
	    ensures \result == this.authPeriod;*/
	public BRelation<Integer,Integer> get_authPeriod(){
		return this.authPeriod;
	}

	/*@ requires true;
	    ensures this.authPeriod == authPeriod;*/
	public void set_authPeriod(BRelation<Integer,Integer> authPeriod){
		this.authPeriod = authPeriod;
	}

	/*@ requires true;
	    ensures \result == this.serial;*/
	public BSet<Integer> get_serial(){
		return this.serial;
	}

	/*@ requires true;
	    ensures this.serial == serial;*/
	public void set_serial(BSet<Integer> serial){
		this.serial = serial;
	}

	/*@ requires true;
	    ensures \result == this.goodTok;*/
	public BRelation<Integer,Integer> get_goodTok(){
		return this.goodTok;
	}

	/*@ requires true;
	    ensures this.goodTok == goodTok;*/
	public void set_goodTok(BRelation<Integer,Integer> goodTok){
		this.goodTok = goodTok;
	}

	/*@ requires true;
	    ensures \result == this.idcert_subjectPubK;*/
	public BRelation<Integer,Integer> get_idcert_subjectPubK(){
		return this.idcert_subjectPubK;
	}

	/*@ requires true;
	    ensures this.idcert_subjectPubK == idcert_subjectPubK;*/
	public void set_idcert_subjectPubK(BRelation<Integer,Integer> idcert_subjectPubK){
		this.idcert_subjectPubK = idcert_subjectPubK;
	}



	/*@ requires true;
	    assignable \everything;
	    ensures
		certificates.isEmpty() &&
		publicKeys.isEmpty() &&
		issuer.isEmpty() &&
		certificateID.isEmpty() &&
		validityPeriods.isEmpty() &&
		isValidatedBy.isEmpty() &&
		users.isEmpty() &&
		certificateIssuer.isEmpty() &&
		serial.isEmpty() &&
		IDCert.isEmpty() &&
		attCert.isEmpty() &&
		idcert_subject.isEmpty() &&
		idcert_subjectPubK.isEmpty() &&
		attcert_baseCertID.isEmpty() &&
		privCert.isEmpty() &&
		iandaCert.isEmpty() &&
		authCert.isEmpty() &&
		privilege.isEmpty() &&
		clearence.isEmpty() &&
		fingerprint.isEmpty() &&
		privCertRole.isEmpty() &&
		privCertClearence.isEmpty() &&
		authCertRole.isEmpty() &&
		authCertClearence.isEmpty() &&
		iandaCertfpTemplate.isEmpty() &&
		tokenID.isEmpty() &&
		tokenIDCert.isEmpty() &&
		tokenPrivCert.isEmpty() &&
		tokenIandaCert.isEmpty() &&
		tokenAuthCert.isEmpty() &&
		attcert_tokenID.isEmpty() &&
		entry_status1 == quiescent &&
		(\exists Integer currentToken_localVar; TOKENID.has(currentToken_localVar); currentToken.equals(currentToken_localVar)) &&
		issuerKey.isEmpty() &&
		fingerprintTry.isEmpty() &&
		goodFP.isEmpty() &&
		goodTok.isEmpty() &&
		tokenTry.isEmpty() &&
		displayMessage1 == blank &&
		latchUnlockDuration == 0 &&
		latchTimeout1 == 0 &&
		locked == true &&
		userTokenPresence == absent &&
		FingerPresence == absent &&
		(\exists BRelation<Integer,BRelation<Integer,BSet<Integer>>> entryPeriod_localVar; BRelation.cross(PRIVILEGE,BRelation.cross(CLEARENCE,new BSet<BSet<Integer>>(new BSet<Integer>(1))).pow()).pow().has(entryPeriod_localVar); entryPeriod.equals(entryPeriod_localVar)) &&
		tokenRemovalTimeout == 0 &&
		alarmTimeout1 == 0 &&
		alarmSilentDuration == 0 &&
		tokenRemovalDuration == 0 &&
		(\exists BRelation<Integer,Integer> authPeriod_localVar; BRelation.cross(PRIVILEGE,NAT.instance).pow().has(authPeriod_localVar); authPeriod.equals(authPeriod_localVar)) &&
		(\exists BRelation<Pair<Integer,Integer>,Integer> minClearance_localVar; BRelation.cross(BRelation.cross(CLEARENCE,CLEARENCE),CLEARENCE).pow().has(minClearance_localVar); minClearance.equals(minClearance_localVar)) &&
		enclaveStatus1 == notEnrolled &&
		screenMsg1 == clear &&
		validEnrol.isEmpty() &&
		(\exists BRelation<Integer,Integer> enrolmentFile_localVar; BRelation.cross(FLOPPY,ENROL).pow().has(enrolmentFile_localVar); enrolmentFile.equals(enrolmentFile_localVar)) &&
		floppyPresence == absent &&
		entry_status2 == quiescent &&
		displayMessage2 == blank &&
		admin.isEmpty() &&
		rolePresent.isEmpty() &&
		availableOps.isEmpty() &&
		currentAdminOp.isEmpty() &&
		keyedOps.isEmpty() &&
		adminTokenPresence == absent &&
		adminToken.isEmpty() &&
		keyedDataPresence == absent &&
		configFile.isEmpty() &&
		currentDoor == closed &&
		alarmTimeout2 == 0 &&
		latchTimeout2 == 0 &&
		enclaveStatus2 == notEnrolled &&
		screenMsg2 == clear &&
		displayMessage3 == blank &&
		(\exists Integer currentAdminToken_localVar; TOKENID.has(currentAdminToken_localVar); currentAdminToken.equals(currentAdminToken_localVar)) &&
		adminop.isEmpty() &&
		keyboard.isEmpty() &&
		floppy.isEmpty();*/
	public ref6_admin(){
	}
}