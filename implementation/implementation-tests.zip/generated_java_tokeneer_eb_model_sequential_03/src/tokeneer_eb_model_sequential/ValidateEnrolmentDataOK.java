package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ValidateEnrolmentDataOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ValidateEnrolmentDataOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.FLOPPY.has(p_currentFloppy) && machine.get_enrolmentFile().image(new BSet<Integer>(p_currentFloppy)).isSubset(machine.get_validEnrol()) && machine.get_enclaveStatus1().equals(machine.waitingEnrol)); @*/
	public boolean guard_ValidateEnrolmentDataOK( Integer p_currentFloppy) {
		return (machine.FLOPPY.has(p_currentFloppy) && machine.get_enrolmentFile().image(new BSet<Integer>(p_currentFloppy)).isSubset(machine.get_validEnrol()) && machine.get_enclaveStatus1().equals(machine.waitingEnrol));
	}

	/*@ requires guard_ValidateEnrolmentDataOK(p_currentFloppy);
		assignable machine.screenMsg1, machine.enclaveStatus1, machine.entry_status2, machine.displayMessage2;
		ensures guard_ValidateEnrolmentDataOK(p_currentFloppy) &&  machine.get_screenMsg1() == \old(machine.welcomeAdmin) &&  machine.get_enclaveStatus1() == \old(machine.enclaveQuiescent) &&  machine.get_entry_status2() == \old(machine.quiescent) &&  machine.get_displayMessage2() == \old(machine.welcome); 
	 also
		requires !guard_ValidateEnrolmentDataOK(p_currentFloppy);
		assignable \nothing;
		ensures true; @*/
	public void run_ValidateEnrolmentDataOK( Integer p_currentFloppy){
		if(guard_ValidateEnrolmentDataOK(p_currentFloppy)) {
			Integer screenMsg1_tmp = machine.get_screenMsg1();
			Integer enclaveStatus1_tmp = machine.get_enclaveStatus1();
			Integer entry_status2_tmp = machine.get_entry_status2();
			Integer displayMessage2_tmp = machine.get_displayMessage2();

			machine.set_screenMsg1(machine.welcomeAdmin);
			machine.set_screenMsg2(machine.welcomeAdmin);
			machine.set_enclaveStatus1(machine.enclaveQuiescent);
			machine.set_enclaveStatus2(machine.enclaveQuiescent);
			machine.set_entry_status1(machine.quiescent);
			machine.set_entry_status2(machine.quiescent);
			machine.set_displayMessage1(machine.welcome);
			machine.set_displayMessage2(machine.welcome);
			machine.set_displayMessage3(machine.welcome);

			System.out.println("ValidateEnrolmentDataOK executed p_currentFloppy: " + p_currentFloppy + " ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg1()));
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
