package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ReadEnrolmentFloppy{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ReadEnrolmentFloppy(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus1().equals(machine.notEnrolled) && machine.get_floppyPresence().equals(machine.present)); @*/
	public boolean guard_ReadEnrolmentFloppy() {
		return (
				machine.get_enclaveStatus1().equals(machine.notEnrolled) && 
				machine.get_floppyPresence().equals(machine.present)
				);
	}

	/*@ requires guard_ReadEnrolmentFloppy();
		assignable machine.screenMsg1, machine.enclaveStatus1, machine.displayMessage2;
		ensures guard_ReadEnrolmentFloppy() &&  machine.get_screenMsg1() == \old(machine.validatingEnrolmentData) &&  machine.get_enclaveStatus1() == \old(machine.waitingEnrol) &&  machine.get_displayMessage2() == \old(machine.blank); 
	 also
		requires !guard_ReadEnrolmentFloppy();
		assignable \nothing;
		ensures true; @*/
	public void run_ReadEnrolmentFloppy(){
		if(guard_ReadEnrolmentFloppy()) {
			Integer screenMsg1_tmp = machine.get_screenMsg1();
			Integer enclaveStatus1_tmp = machine.get_enclaveStatus1();
			Integer displayMessage2_tmp = machine.get_displayMessage2();

			machine.set_screenMsg1(machine.validatingEnrolmentData);
			machine.set_screenMsg2(machine.validatingEnrolmentData);
			machine.set_enclaveStatus1(machine.waitingEnrol);
			machine.set_enclaveStatus2(machine.waitingEnrol);
			machine.set_displayMessage1(machine.blank);
			machine.set_displayMessage2(machine.blank);
			machine.set_displayMessage3(machine.blank);

			System.out.println("ReadEnrolmentFloppy executed ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg1()));
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage2()));
		}
	}

}
