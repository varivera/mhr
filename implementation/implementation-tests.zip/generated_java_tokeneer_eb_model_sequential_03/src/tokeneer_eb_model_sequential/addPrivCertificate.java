package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class addPrivCertificate{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public addPrivCertificate(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.CERTIFICATES.difference(machine.get_certificates()).has(p_ce) && machine.SERIAL_NUMBER.difference(machine.get_serial()).has(p_serial) && machine.get_issuer().has(p_issuer) && machine.get_publicKeys().has(p_pubkey) && NAT.instance.has(p_period) && !machine.get_isValidatedBy().has(new Pair<Integer,Integer>(p_ce,p_pubkey)) && !machine.get_validityPeriods().domain().has(p_ce) && !machine.get_isValidatedBy().domain().has(p_ce) && !machine.get_isValidatedBy().range().has(p_pubkey) && !machine.get_attCert().has(p_ce) && !machine.get_IDCert().has(p_ce) && machine.get_IDCert().has(p_id_cert) && machine.get_privilege().has(p_priv) && machine.get_clearence().has(p_class) && !machine.get_privCertRole().has(new Pair<Integer,Integer>(p_ce,p_priv)) && !machine.get_privCertRole().domain().has(p_ce) && !machine.get_privCertClearence().has(new Pair<Integer,Integer>(p_ce,p_class)) && !machine.get_privCertClearence().domain().has(p_ce) && machine.get_tokenID().difference(machine.get_attcert_tokenID().range()).has(p_tid) && !machine.get_attcert_tokenID().domain().has(p_ce)); @*/
	public boolean guard_addPrivCertificate( Integer p_id_cert, Integer p_priv, Integer p_ce, Integer p_tid, Integer p_serial, BSet<Integer> p_issuer, Integer p_period, Integer p_pubkey, Integer p_class) {
		return (machine.CERTIFICATES.difference(machine.get_certificates()).has(p_ce) && machine.SERIAL_NUMBER.difference(machine.get_serial()).has(p_serial) && machine.get_issuer().has(p_issuer) && machine.get_publicKeys().has(p_pubkey) && NAT.instance.has(p_period) && !machine.get_isValidatedBy().has(new Pair<Integer,Integer>(p_ce,p_pubkey)) && !machine.get_validityPeriods().domain().has(p_ce) && !machine.get_isValidatedBy().domain().has(p_ce) && !machine.get_isValidatedBy().range().has(p_pubkey) && !machine.get_attCert().has(p_ce) && !machine.get_IDCert().has(p_ce) && machine.get_IDCert().has(p_id_cert) && machine.get_privilege().has(p_priv) && machine.get_clearence().has(p_class) && !machine.get_privCertRole().has(new Pair<Integer,Integer>(p_ce,p_priv)) && !machine.get_privCertRole().domain().has(p_ce) && !machine.get_privCertClearence().has(new Pair<Integer,Integer>(p_ce,p_class)) && !machine.get_privCertClearence().domain().has(p_ce) && machine.get_tokenID().difference(machine.get_attcert_tokenID().range()).has(p_tid) && !machine.get_attcert_tokenID().domain().has(p_ce));
	}

	/*@ requires guard_addPrivCertificate(p_id_cert,p_priv,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey,p_class);
		assignable machine.certificates, machine.serial, machine.certificateIssuer, machine.certificateID, machine.validityPeriods, machine.isValidatedBy, machine.attCert, machine.attcert_baseCertID, machine.privCert, machine.privCertRole, machine.privCertClearence, machine.attcert_tokenID;
		ensures guard_addPrivCertificate(p_id_cert,p_priv,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey,p_class) &&  machine.get_certificates().equals(\old((machine.get_certificates().union(new BSet<Integer>(p_ce))))) &&  machine.get_serial().equals(\old((machine.get_serial().union(new BSet<Integer>(p_serial))))) &&  machine.get_certificateIssuer().equals(\old((machine.get_certificateIssuer().union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(p_ce,p_issuer)))))) &&  machine.get_certificateID().equals(\old((machine.get_certificateID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_serial)))))) &&  machine.get_validityPeriods().equals(\old((machine.get_validityPeriods().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_period)))))) &&  machine.get_isValidatedBy().equals(\old((machine.get_isValidatedBy().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey)))))) &&  machine.get_attCert().equals(\old((machine.get_attCert().union(new BSet<Integer>(p_ce))))) &&  machine.get_attcert_baseCertID().equals(\old((machine.get_attcert_baseCertID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_serial,machine.get_certificateID().apply(p_id_cert))))))) &&  machine.get_privCert().equals(\old((machine.get_privCert().union(new BSet<Integer>(p_ce))))) &&  machine.get_privCertRole().equals(\old((machine.get_privCertRole().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_priv)))))) &&  machine.get_privCertClearence().equals(\old((machine.get_privCertClearence().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_class)))))) &&  machine.get_attcert_tokenID().equals(\old((machine.get_attcert_tokenID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_tid)))))); 
	 also
		requires !guard_addPrivCertificate(p_id_cert,p_priv,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey,p_class);
		assignable \nothing;
		ensures true; @*/
	public void run_addPrivCertificate( Integer p_id_cert, Integer p_priv, Integer p_ce, Integer p_tid, Integer p_serial, BSet<Integer> p_issuer, Integer p_period, Integer p_pubkey, Integer p_class){
		if(guard_addPrivCertificate(p_id_cert,p_priv,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey,p_class)) {
			BSet<Integer> certificates_tmp = machine.get_certificates();
			BSet<Integer> serial_tmp = machine.get_serial();
			BRelation<Integer,BSet<Integer>> certificateIssuer_tmp = machine.get_certificateIssuer();
			BRelation<Integer,Integer> certificateID_tmp = machine.get_certificateID();
			BRelation<Integer,Integer> validityPeriods_tmp = machine.get_validityPeriods();
			BRelation<Integer,Integer> isValidatedBy_tmp = machine.get_isValidatedBy();
			BSet<Integer> attCert_tmp = machine.get_attCert();
			BRelation<Integer,Integer> attcert_baseCertID_tmp = machine.get_attcert_baseCertID();
			BSet<Integer> privCert_tmp = machine.get_privCert();
			BRelation<Integer,Integer> privCertRole_tmp = machine.get_privCertRole();
			BRelation<Integer,Integer> privCertClearence_tmp = machine.get_privCertClearence();
			BRelation<Integer,Integer> attcert_tokenID_tmp = machine.get_attcert_tokenID();

			machine.set_certificates((certificates_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_serial((serial_tmp.union(new BSet<Integer>(p_serial))));
			machine.set_certificateIssuer((certificateIssuer_tmp.union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(p_ce,p_issuer)))));
			machine.set_certificateID((certificateID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_serial)))));
			machine.set_validityPeriods((validityPeriods_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_period)))));
			machine.set_isValidatedBy((isValidatedBy_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey)))));
			machine.set_attCert((attCert_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_attcert_baseCertID((attcert_baseCertID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_serial,certificateID_tmp.apply(p_id_cert))))));
			machine.set_privCert((privCert_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_privCertRole((privCertRole_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_priv)))));
			machine.set_privCertClearence((privCertClearence_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_class)))));
			machine.set_attcert_tokenID((attcert_tokenID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_tid)))));

			System.out.println("addPrivCertificate executed p_id_cert: " + p_id_cert + " p_priv: " + p_priv + " p_tid: " + p_tid + " p_ce: " + p_ce + " p_serial: " + p_serial + " p_pubkey: " + p_pubkey + " p_period: " + p_period + " p_issuer: " + p_issuer + " p_class: " + p_class + " ");
		}
	}

}
