package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ValidateFingerFail{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ValidateFingerFail(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_entry_status1().equals(machine.gotFinger) && machine.get_userTokenPresence().equals(machine.present)); @*/
	public boolean guard_ValidateFingerFail() {
		return (
				machine.get_entry_status1().equals(machine.gotFinger) && 
				machine.get_userTokenPresence().equals(machine.present)
			);
	}

	/*@ requires guard_ValidateFingerFail();
		assignable machine.entry_status1, machine.displayMessage1;
		ensures guard_ValidateFingerFail() &&  machine.get_entry_status1() == \old(machine.waitingRemoveTokenFail) &&  machine.get_displayMessage1() == \old(machine.removeToken); 
	 also
		requires !guard_ValidateFingerFail();
		assignable \nothing;
		ensures true; @*/
	public void run_ValidateFingerFail(){
		if(guard_ValidateFingerFail()) {
			Integer entry_status1_tmp = machine.get_entry_status1();
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_entry_status1(machine.waitingRemoveTokenFail);
			machine.set_entry_status2(machine.waitingRemoveTokenFail);
			machine.set_displayMessage1(machine.removeToken);
			machine.set_displayMessage2(machine.removeToken);
			machine.set_displayMessage3(machine.removeToken);

			System.out.println("ValidateFingerFail executed ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
