package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class BadAdminLogout{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public BadAdminLogout(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_adminTokenPresence().equals(machine.absent) && new BSet<Integer>(machine.gotAdminToken,machine.waitingStartAdminOp,machine.waitingFinishAdminOp).has(machine.get_enclaveStatus2()) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole)); @*/
	public boolean guard_BadAdminLogout() {
		return (
				machine.get_adminTokenPresence().equals(machine.absent) && 
				new BSet<Integer>(machine.gotAdminToken,machine.waitingStartAdminOp,machine.waitingFinishAdminOp).has(machine.get_enclaveStatus2()) && 
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				!machine.get_rolePresent().equals(machine.NoRole)
			);
	}

	/*@ requires guard_BadAdminLogout();
		assignable machine.enclaveStatus2, machine.rolePresent, machine.currentAdminOp, machine.availableOps;
		ensures guard_BadAdminLogout() &&  machine.get_enclaveStatus2() == \old(machine.enclaveQuiescent) &&  machine.get_rolePresent().equals(\old((machine.get_rolePresent().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoRole)))))) &&  machine.get_currentAdminOp().equals(\old((machine.get_currentAdminOp().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoOp)))))) &&  machine.get_availableOps().equals(\old((machine.get_availableOps().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoOp)))))); 
	 also
		requires !guard_BadAdminLogout();
		assignable \nothing;
		ensures true; @*/
	public void run_BadAdminLogout(){
		if(guard_BadAdminLogout()) {
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();
			Integer rolePresent_tmp = machine.get_rolePresent();
			Integer currentAdminOp_tmp = machine.get_currentAdminOp();
			
			machine.set_enclaveStatus1(machine.enclaveQuiescent);
			machine.set_enclaveStatus2(machine.enclaveQuiescent);
			machine.set_rolePresent(machine.NoRole);
			machine.set_currentAdminOp(machine.NoOp);
			
			System.out.println("BadAdminLogout executed ");
		}
	}

}
