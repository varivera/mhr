package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ReadUserToken{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ReadUserToken(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_tokenID().has(token_user_to_read) && machine.get_entry_status1().equals(machine.quiescent) && machine.get_userTokenPresence().equals(machine.present) && new BSet<Integer>(machine.enclaveQuiescent,machine.waitingRemoveAdminTokenFail).has(machine.get_enclaveStatus1())); @*/
	public boolean guard_ReadUserToken( Integer token_user_to_read) {
		return (
				machine.get_tokenID().has(token_user_to_read) && 
				machine.get_entry_status1().equals(machine.quiescent) && 
				machine.get_userTokenPresence().equals(machine.present) && 
				new BSet<Integer>(machine.enclaveQuiescent,machine.waitingRemoveAdminTokenFail).has(machine.get_enclaveStatus1())
				
				);
	}

	/*@ requires guard_ReadUserToken(token_user_to_read);
		assignable machine.entry_status1, machine.currentToken, machine.displayMessage1;
		ensures guard_ReadUserToken(token_user_to_read) &&  machine.get_entry_status1() == \old(machine.gotUserToken) &&  machine.get_currentToken() == \old(token_user_to_read) &&  machine.get_displayMessage1() == \old(machine.wait); 
	 also
		requires !guard_ReadUserToken(token_user_to_read);
		assignable \nothing;
		ensures true; @*/
	public void run_ReadUserToken( Integer token_user_to_read){
		if(guard_ReadUserToken(token_user_to_read)) {
			Integer entry_status1_tmp = machine.get_entry_status1();
			Integer currentToken_tmp = machine.get_currentToken();
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_entry_status1(machine.gotUserToken);
			machine.set_entry_status2(machine.gotUserToken);
			machine.set_currentToken(token_user_to_read);
			machine.set_displayMessage1(machine.wait);
			machine.set_displayMessage2(machine.wait);
			machine.set_displayMessage3(machine.wait);

			System.out.println("ReadUserToken executed token_user_to_read: " + token_user_to_read + " ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
