package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class EntryNotAllowed{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public EntryNotAllowed(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_entry_status1().equals(machine.waitingEntry) && machine.get_userTokenPresence().equals(machine.present) && NAT.instance.has(currentTime) && !(machine.get_tokenID().has(machine.get_currentToken()) && machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT) && machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && machine.get_tokenPrivCert().domain().has(machine.get_currentToken()) && machine.get_tokenIandaCert().domain().has(machine.get_currentToken()) && machine.get_attcert_baseCertID().domain().has(machine.get_certificateID().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken()))) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenIandaCert().apply(machine.get_currentToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && machine.get_tokenPrivCert().domain().has(machine.get_currentToken()) && machine.get_entryPeriod().apply(machine.get_privCertRole().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken()))).apply(machine.get_privCertClearence().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken()))).has(currentTime) || machine.get_tokenID().has(machine.get_currentToken()) && machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT) && machine.get_tokenID().has(machine.get_currentToken()) && machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT) && machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenAuthCert().apply(machine.get_currentToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && machine.get_validityPeriods().image(new BSet<Integer>(machine.get_tokenAuthCert().apply(machine.get_currentToken()))).has(currentTime) && machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && machine.get_issuer().has(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(machine.get_currentToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && machine.get_entryPeriod().apply(machine.get_authCertRole().apply(machine.get_tokenAuthCert().apply(machine.get_currentToken()))).apply(machine.get_authCertClearence().apply(machine.get_tokenAuthCert().apply(machine.get_currentToken()))).has(currentTime))); @*/
	public boolean guard_EntryNotAllowed( Integer currentTime) {
		return (
				machine.get_entry_status1().equals(machine.waitingEntry) && 
				machine.get_userTokenPresence().equals(machine.present) && 
				NAT.instance.has(currentTime) && 
				!(machine.get_tokenID().has(machine.get_currentToken()) && 
						machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT) && 
						machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && 
						machine.get_tokenPrivCert().domain().has(machine.get_currentToken()) && 
						machine.get_tokenIandaCert().domain().has(machine.get_currentToken()) && 
						machine.get_attcert_baseCertID().domain().has(machine.get_certificateID().apply(
								machine.get_tokenPrivCert().apply(machine.get_currentToken()))) && 
						machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
								machine.get_tokenPrivCert().apply(machine.get_currentToken()))).equals(
								machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
								machine.get_currentToken()))) && 
						machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
								machine.get_tokenIandaCert().apply(machine.get_currentToken()))).equals(
								machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
								machine.get_currentToken()))) && 
						machine.get_tokenPrivCert().domain().has(machine.get_currentToken()) && 
						machine.get_entryPeriod().apply(machine.get_privCertRole().apply(
								machine.get_tokenPrivCert().apply(machine.get_currentToken()))).apply(
								machine.get_privCertClearence().apply(machine.get_tokenPrivCert().apply(
								machine.get_currentToken()))).has(currentTime) || 
								machine.get_tokenID().has(machine.get_currentToken()) && 
						machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT) && 
						machine.get_tokenID().has(machine.get_currentToken()) && 
						machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT) && 
						machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && 
						machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && 
						machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
								machine.get_tokenAuthCert().apply(machine.get_currentToken()))).equals(
								machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
								machine.get_currentToken()))) && 
						machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && 
						machine.get_validityPeriods().image(new BSet<Integer>(
								machine.get_tokenAuthCert().apply(machine.get_currentToken()))).has(currentTime) && 
						machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && 
						machine.get_issuer().has(machine.get_certificateIssuer().apply(
								machine.get_tokenIDCert().apply(machine.get_currentToken()))) && 
						machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(
								machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(
								machine.get_currentToken())))) && 
						machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && 
						machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(
								machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(
								machine.get_currentToken())))) && 
						machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && 
						machine.get_entryPeriod().apply(machine.get_authCertRole().apply(
								machine.get_tokenAuthCert().apply(machine.get_currentToken()))).apply(
								machine.get_authCertClearence().apply(machine.get_tokenAuthCert().apply(
								machine.get_currentToken()))).has(currentTime))
			);
	}

	/*@ requires guard_EntryNotAllowed(currentTime);
		assignable machine.entry_status1, machine.displayMessage1;
		ensures guard_EntryNotAllowed(currentTime) &&  machine.get_entry_status1() == \old(machine.waitingRemoveTokenFail) &&  machine.get_displayMessage1() == \old(machine.removeToken); 
	 also
		requires !guard_EntryNotAllowed(currentTime);
		assignable \nothing;
		ensures true; @*/
	public void run_EntryNotAllowed( Integer currentTime){
		if(guard_EntryNotAllowed(currentTime)) {
			Integer entry_status1_tmp = machine.get_entry_status1();
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_entry_status1(machine.waitingRemoveTokenFail);
			machine.set_entry_status2(machine.waitingRemoveTokenFail);
			machine.set_displayMessage1(machine.removeToken);
			machine.set_displayMessage2(machine.removeToken);
			machine.set_displayMessage3(machine.removeToken);

			System.out.println("EntryNotAllowed executed currentTime: " + currentTime + " ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
