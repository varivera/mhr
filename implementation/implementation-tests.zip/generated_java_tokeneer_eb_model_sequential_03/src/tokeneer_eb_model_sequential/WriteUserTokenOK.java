package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class WriteUserTokenOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public WriteUserTokenOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.CERTIFICATES.difference(machine.get_certificates()).has(p_ce) && machine.SERIAL_NUMBER.difference(machine.get_serial()).has(p_serial) && machine.get_issuer().has(p_issuer) && machine.get_publicKeys().has(p_pubkey) && NAT.instance.has(p_period) && !machine.get_isValidatedBy().has(new Pair<Integer,Integer>(p_ce,p_pubkey)) && !machine.get_validityPeriods().domain().has(p_ce) && !machine.get_isValidatedBy().domain().has(p_ce) && !machine.get_isValidatedBy().range().has(p_pubkey) && !machine.get_attCert().has(p_ce) && !machine.get_IDCert().has(p_ce) && machine.get_IDCert().has(p_id_cert) && machine.get_privilege().has(p_priv) && machine.get_clearence().has(p_class) && !machine.get_authCertRole().has(new Pair<Integer,Integer>(p_ce,p_priv)) && !machine.get_authCertRole().domain().has(p_ce) && !machine.get_authCertClearence().has(new Pair<Integer,Integer>(p_ce,p_class)) && !machine.get_authCertClearence().domain().has(p_ce) && machine.get_tokenID().has(p_tid) && !machine.get_tokenAuthCert().range().has(p_ce) && !machine.get_attcert_tokenID().has(new Pair<Integer,Integer>(p_ce,p_tid)) && !machine.get_tokenAuthCert().domain().has(p_tid) && !machine.get_tokenAuthCert().has(new Pair<Integer,Integer>(p_tid,p_ce)) && machine.get_entry_status1().equals(machine.waitingUpdateToken) && machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && machine.get_tokenPrivCert().domain().has(machine.get_currentToken()) && machine.get_tokenIandaCert().domain().has(machine.get_currentToken()) && machine.get_attcert_baseCertID().domain().has(machine.get_certificateID().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken()))) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenIandaCert().apply(machine.get_currentToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && p_issuer.equals(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && p_id_cert.equals(machine.get_tokenIDCert().apply(machine.get_currentToken())) && p_tid.equals(machine.get_currentToken()) && p_priv.equals(machine.get_privCertRole().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken()))) && p_pubkey.equals(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentToken())))) && machine.get_userTokenPresence().equals(machine.present) && machine.get_tokenID().has(machine.get_currentToken()) && machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT) && p_period.equals(machine.get_authPeriod().apply(machine.get_privCertRole().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken())))) && p_class.equals(machine.get_minClearance().apply(new Pair<Integer,Integer>(machine.unmarked,machine.get_privCertClearence().apply(machine.get_tokenPrivCert().apply(machine.get_currentToken())))))); @*/
	public boolean guard_WriteUserTokenOK( Integer p_id_cert, Integer p_priv, Integer p_ce, Integer p_tid, Integer p_serial, BSet<Integer> p_issuer, Integer p_period, Integer p_pubkey, Integer p_class) {
		return (
				machine.CERTIFICATES.difference(machine.get_certificates()).has(p_ce) && 
				machine.SERIAL_NUMBER.difference(machine.get_serial()).has(p_serial) && 
				machine.get_issuer().has(p_issuer) && 
				machine.get_publicKeys().has(p_pubkey) && 
				NAT.instance.has(p_period) && 
				!machine.get_isValidatedBy().has(new Pair<Integer,Integer>(p_ce,p_pubkey)) && 
				!machine.get_validityPeriods().domain().has(p_ce) && 
				!machine.get_isValidatedBy().domain().has(p_ce) && 
				//TODO to check !machine.get_isValidatedBy().range().has(p_pubkey) && 
				!machine.get_attCert().has(p_ce) && 
				!machine.get_IDCert().has(p_ce) && 
				machine.get_IDCert().has(p_id_cert) && 
				machine.get_privilege().has(p_priv) && 
				machine.get_clearence().has(p_class) && 
				!machine.get_authCertRole().has(new Pair<Integer,Integer>(p_ce,p_priv)) && 
				!machine.get_authCertRole().domain().has(p_ce) && 
				!machine.get_authCertClearence().has(new Pair<Integer,Integer>(p_ce,p_class)) && 
				!machine.get_authCertClearence().domain().has(p_ce) && 
				machine.get_tokenID().has(p_tid) && 
				!machine.get_tokenAuthCert().range().has(p_ce) && 
				!machine.get_attcert_tokenID().has(new Pair<Integer,Integer>(p_ce,p_tid)) && 
				!machine.get_tokenAuthCert().domain().has(p_tid) && 
				!machine.get_tokenAuthCert().has(new Pair<Integer,Integer>(p_tid,p_ce)) && 
				machine.get_entry_status1().equals(machine.waitingUpdateToken) && 
				machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && 
				machine.get_tokenPrivCert().domain().has(machine.get_currentToken()) && 
				machine.get_tokenIandaCert().domain().has(machine.get_currentToken()) && 
				machine.get_attcert_baseCertID().domain().has(machine.get_certificateID().apply(
						machine.get_tokenPrivCert().apply(machine.get_currentToken()))) && 
				machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
						machine.get_tokenPrivCert().apply(machine.get_currentToken()))).equals(
						machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
						machine.get_currentToken()))) && 
				machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
						machine.get_tokenIandaCert().apply(machine.get_currentToken()))).equals(
						machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
						machine.get_currentToken()))) && 
				p_issuer.equals(machine.get_certificateIssuer().apply(machine.get_tokenPrivCert().apply(
						machine.get_currentToken()))) && 
				p_id_cert.equals(machine.get_tokenIDCert().apply(machine.get_currentToken())) && 
				p_tid.equals(machine.get_currentToken()) && 
				p_priv.equals(machine.get_privCertRole().apply(machine.get_tokenPrivCert().apply(
						machine.get_currentToken()))) && 
				p_pubkey.equals(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(
						machine.get_tokenIDCert().apply(machine.get_currentToken())))) && 
				machine.get_userTokenPresence().equals(machine.present) && 
				machine.get_tokenID().has(machine.get_currentToken()) && 
				machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT) && 
				p_period.equals(machine.get_authPeriod().apply(machine.get_privCertRole().apply(
						machine.get_tokenPrivCert().apply(machine.get_currentToken())))) && 
				p_class.equals(machine.get_minClearance().apply(new Pair<Integer,Integer>(
						machine.unmarked,machine.get_privCertClearence().apply(machine.get_tokenPrivCert().
						apply(machine.get_currentToken())))))
			);
	}

	/*@ requires guard_WriteUserTokenOK(p_id_cert,p_priv,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey,p_class);
		assignable machine.certificates, machine.serial, machine.certificateIssuer, machine.certificateID, machine.validityPeriods, machine.isValidatedBy, machine.attCert, machine.attcert_baseCertID, machine.authCert, machine.authCertRole, machine.authCertClearence, machine.attcert_tokenID, machine.entry_status1, machine.tokenAuthCert, machine.displayMessage1;
		ensures guard_WriteUserTokenOK(p_id_cert,p_priv,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey,p_class) &&  machine.get_certificates().equals(\old((machine.get_certificates().union(new BSet<Integer>(p_ce))))) &&  machine.get_serial().equals(\old((machine.get_serial().union(new BSet<Integer>(p_serial))))) &&  machine.get_certificateIssuer().equals(\old((machine.get_certificateIssuer().union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(p_ce,p_issuer)))))) &&  machine.get_certificateID().equals(\old((machine.get_certificateID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_serial)))))) &&  machine.get_validityPeriods().equals(\old((machine.get_validityPeriods().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_period)))))) &&  machine.get_isValidatedBy().equals(\old((machine.get_isValidatedBy().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey)))))) &&  machine.get_attCert().equals(\old((machine.get_attCert().union(new BSet<Integer>(p_ce))))) &&  machine.get_attcert_baseCertID().equals(\old((machine.get_attcert_baseCertID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_serial,machine.get_certificateID().apply(p_id_cert))))))) &&  machine.get_authCert().equals(\old((machine.get_authCert().union(new BSet<Integer>(p_ce))))) &&  machine.get_authCertRole().equals(\old((machine.get_authCertRole().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_priv)))))) &&  machine.get_authCertClearence().equals(\old((machine.get_authCertClearence().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_class)))))) &&  machine.get_attcert_tokenID().equals(\old((machine.get_attcert_tokenID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_tid)))))) &&  machine.get_entry_status1() == \old(machine.waitingEntry) &&  machine.get_tokenAuthCert().equals(\old((machine.get_tokenAuthCert().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_tid,p_ce)))))) &&  machine.get_displayMessage1() == \old(machine.wait); 
	 also
		requires !guard_WriteUserTokenOK(p_id_cert,p_priv,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey,p_class);
		assignable \nothing;
		ensures true; @*/
	public void run_WriteUserTokenOK( Integer p_id_cert, Integer p_priv, Integer p_ce, Integer p_tid, Integer p_serial, BSet<Integer> p_issuer, Integer p_period, Integer p_pubkey, Integer p_class){
		if(guard_WriteUserTokenOK(p_id_cert,p_priv,p_ce,p_tid,p_serial,p_issuer,p_period,p_pubkey,p_class)) {
			BSet<Integer> certificates_tmp = machine.get_certificates();
			BSet<Integer> serial_tmp = machine.get_serial();
			BRelation<Integer,BSet<Integer>> certificateIssuer_tmp = machine.get_certificateIssuer();
			BRelation<Integer,Integer> certificateID_tmp = machine.get_certificateID();
			BRelation<Integer,Integer> validityPeriods_tmp = machine.get_validityPeriods();
			BRelation<Integer,Integer> isValidatedBy_tmp = machine.get_isValidatedBy();
			BSet<Integer> attCert_tmp = machine.get_attCert();
			BRelation<Integer,Integer> attcert_baseCertID_tmp = machine.get_attcert_baseCertID();
			BSet<Integer> authCert_tmp = machine.get_authCert();
			BRelation<Integer,Integer> authCertRole_tmp = machine.get_authCertRole();
			BRelation<Integer,Integer> authCertClearence_tmp = machine.get_authCertClearence();
			BRelation<Integer,Integer> attcert_tokenID_tmp = machine.get_attcert_tokenID();
			Integer entry_status1_tmp = machine.get_entry_status1();
			BRelation<Integer,Integer> tokenAuthCert_tmp = machine.get_tokenAuthCert();
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_certificates((certificates_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_serial((serial_tmp.union(new BSet<Integer>(p_serial))));
			machine.set_certificateIssuer((certificateIssuer_tmp.union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(p_ce,p_issuer)))));
			machine.set_certificateID((certificateID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_serial)))));
			machine.set_validityPeriods((validityPeriods_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_period)))));
			machine.set_isValidatedBy((isValidatedBy_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey)))));
			machine.set_attCert((attCert_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_attcert_baseCertID((attcert_baseCertID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_serial,certificateID_tmp.apply(p_id_cert))))));
			machine.set_authCert((authCert_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_authCertRole((authCertRole_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_priv)))));
			machine.set_authCertClearence((authCertClearence_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_class)))));
			machine.set_attcert_tokenID((attcert_tokenID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_tid)))));
			machine.set_entry_status1(machine.waitingEntry);
			machine.set_entry_status2(machine.waitingEntry);
			machine.set_tokenAuthCert((tokenAuthCert_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_tid,p_ce)))));
			machine.set_displayMessage1(machine.wait);
			machine.set_displayMessage2(machine.wait);
			machine.set_displayMessage3(machine.wait);

			System.out.println("WriteUserTokenOK executed p_id_cert: " + p_id_cert + " p_priv: " + p_priv + " p_tid: " + p_tid + " p_ce: " + p_ce + " p_serial: " + p_serial + " p_pubkey: " + p_pubkey + " p_period: " + p_period + " p_issuer: " + p_issuer + " p_class: " + p_class + " ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
