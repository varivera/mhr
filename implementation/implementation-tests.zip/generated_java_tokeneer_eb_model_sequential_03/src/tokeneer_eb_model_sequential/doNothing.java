package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class doNothing{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public doNothing(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> machine.get_entry_status1().equals(machine.waitingRemoveTokenSuccess) || machine.get_entry_status1().equals(machine.waitingRemoveTokenFail) || machine.get_entry_status1().equals(machine.gotFinger); @*/
	public boolean guard_doNothing() {
		return machine.get_entry_status1().equals(machine.waitingRemoveTokenSuccess) || machine.get_entry_status1().equals(machine.waitingRemoveTokenFail) || machine.get_entry_status1().equals(machine.gotFinger);
	}

	/*@ requires guard_doNothing();
		assignable machine.displayMessage1;
		ensures guard_doNothing() &&  machine.get_displayMessage1() == \old(machine.blank); 
	 also
		requires !guard_doNothing();
		assignable \nothing;
		ensures true; @*/
	public void run_doNothing(){
		if(guard_doNothing()) {
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_displayMessage1(machine.blank);
			machine.set_displayMessage2(machine.blank);
			machine.set_displayMessage3(machine.blank);

			System.out.println("doNothing executed ");
		}
	}

}
