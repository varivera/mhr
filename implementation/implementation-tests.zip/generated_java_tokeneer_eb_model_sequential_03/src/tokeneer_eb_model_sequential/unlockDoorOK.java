package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class unlockDoorOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public unlockDoorOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_entry_status1().equals(machine.waitingRemoveTokenSuccess) && NAT.instance.has(currentTime) && machine.get_userTokenPresence().equals(machine.absent) && currentTime <= machine.MAXTIME && currentTime <= (machine.get_latchTimeout1() - machine.get_latchUnlockDuration()) && currentTime >= machine.get_latchTimeout1() && (currentTime + machine.get_latchUnlockDuration()) <= machine.MAXTIME); @*/
	public boolean guard_unlockDoorOK( Integer currentTime) {
		return (
				machine.get_entry_status1().equals(machine.waitingRemoveTokenSuccess) && 
				NAT.instance.has(currentTime) && 
				machine.get_userTokenPresence().equals(machine.absent) && 
				currentTime <= machine.MAXTIME && 
				currentTime <= (machine.get_latchTimeout1() - machine.get_latchUnlockDuration()) && 
				//currentTime >= machine.get_latchTimeout1() && 
				(currentTime + machine.get_latchUnlockDuration()) <= machine.MAXTIME
				
				);
	}

	/*@ requires guard_unlockDoorOK(currentTime);
		assignable machine.entry_status1, machine.displayMessage1, machine.latchTimeout1, machine.alarmTimeout1;
		ensures guard_unlockDoorOK(currentTime) &&  machine.get_entry_status1() == \old(machine.quiescent) &&  machine.get_displayMessage1() == \old(machine.doorUnlocked) &&  machine.get_latchTimeout1() == \old((currentTime + machine.get_latchUnlockDuration())) &&  machine.get_alarmTimeout1() == \old((currentTime + machine.get_latchUnlockDuration() + machine.get_alarmSilentDuration())); 
	 also
		requires !guard_unlockDoorOK(currentTime);
		assignable \nothing;
		ensures true; @*/
	public void run_unlockDoorOK( Integer currentTime){
		if(guard_unlockDoorOK(currentTime)) {
			Integer entry_status1_tmp = machine.get_entry_status1();
			Integer displayMessage1_tmp = machine.get_displayMessage1();
			Integer latchTimeout1_tmp = machine.get_latchTimeout1();
			Integer alarmTimeout1_tmp = machine.get_alarmTimeout1();

			machine.set_entry_status1(machine.quiescent);
			machine.set_entry_status2(machine.quiescent);
			machine.set_displayMessage1(machine.doorUnlocked);
			machine.set_displayMessage2(machine.doorUnlocked);
			machine.set_displayMessage3(machine.doorUnlocked);
			machine.set_latchTimeout1((currentTime + machine.get_latchUnlockDuration()));
			machine.set_latchTimeout2((currentTime + machine.get_latchUnlockDuration()));
			machine.set_alarmTimeout1((currentTime + machine.get_latchUnlockDuration() + machine.get_alarmSilentDuration()));
			machine.set_alarmTimeout2((currentTime + machine.get_latchUnlockDuration() + machine.get_alarmSilentDuration()));
			
			System.out.println("unlockDoorOK executed currentTime: " + currentTime + " ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
