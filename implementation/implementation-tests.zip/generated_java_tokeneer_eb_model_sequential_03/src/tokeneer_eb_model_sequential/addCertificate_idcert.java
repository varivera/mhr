package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class addCertificate_idcert{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public addCertificate_idcert(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.CERTIFICATES.difference(machine.get_certificates()).has(p_ce) && machine.SERIAL_NUMBER.difference(machine.get_serial()).has(p_serial) && machine.get_issuer().has(p_issuer) && machine.get_publicKeys().has(p_pubkey) && NAT.instance.has(p_period) && !machine.get_isValidatedBy().has(new Pair<Integer,Integer>(p_ce,p_pubkey)) && !machine.get_validityPeriods().domain().has(p_ce) && !machine.get_isValidatedBy().domain().has(p_ce) && !machine.get_isValidatedBy().range().has(p_pubkey) && !machine.get_attCert().has(p_ce) && !machine.get_IDCert().has(p_ce) && machine.get_users().has(p_user) && !machine.get_idcert_subject().range().has(p_user) && machine.get_publicKeys().has(p_pubkey_user) && !machine.get_idcert_subjectPubK().range().has(p_pubkey_user)); @*/
	public boolean guard_addCertificate_idcert( Integer p_pubkey_user, Integer p_ce, Integer p_serial, Integer p_user, BSet<Integer> p_issuer, Integer p_period, Integer p_pubkey) {
		return (machine.CERTIFICATES.difference(machine.get_certificates()).has(p_ce) && machine.SERIAL_NUMBER.difference(machine.get_serial()).has(p_serial) && machine.get_issuer().has(p_issuer) && machine.get_publicKeys().has(p_pubkey) && NAT.instance.has(p_period) && !machine.get_isValidatedBy().has(new Pair<Integer,Integer>(p_ce,p_pubkey)) && !machine.get_validityPeriods().domain().has(p_ce) && !machine.get_isValidatedBy().domain().has(p_ce) && !machine.get_isValidatedBy().range().has(p_pubkey) && !machine.get_attCert().has(p_ce) && !machine.get_IDCert().has(p_ce) && machine.get_users().has(p_user) && !machine.get_idcert_subject().range().has(p_user) && machine.get_publicKeys().has(p_pubkey_user) && !machine.get_idcert_subjectPubK().range().has(p_pubkey_user));
	}

	/*@ requires guard_addCertificate_idcert(p_pubkey_user,p_ce,p_serial,p_user,p_issuer,p_period,p_pubkey);
		assignable machine.certificates, machine.serial, machine.certificateIssuer, machine.certificateID, machine.validityPeriods, machine.isValidatedBy, machine.IDCert, machine.idcert_subject, machine.idcert_subjectPubK;
		ensures guard_addCertificate_idcert(p_pubkey_user,p_ce,p_serial,p_user,p_issuer,p_period,p_pubkey) &&  machine.get_certificates().equals(\old((machine.get_certificates().union(new BSet<Integer>(p_ce))))) &&  machine.get_serial().equals(\old((machine.get_serial().union(new BSet<Integer>(p_serial))))) &&  machine.get_certificateIssuer().equals(\old((machine.get_certificateIssuer().union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(p_ce,p_issuer)))))) &&  machine.get_certificateID().equals(\old((machine.get_certificateID().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_serial)))))) &&  machine.get_validityPeriods().equals(\old((machine.get_validityPeriods().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_period)))))) &&  machine.get_isValidatedBy().equals(\old((machine.get_isValidatedBy().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey)))))) &&  machine.get_IDCert().equals(\old((machine.get_IDCert().union(new BSet<Integer>(p_ce))))) &&  machine.get_idcert_subject().equals(\old((machine.get_idcert_subject().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_user)))))) &&  machine.get_idcert_subjectPubK().equals(\old((machine.get_idcert_subjectPubK().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey_user)))))); 
	 also
		requires !guard_addCertificate_idcert(p_pubkey_user,p_ce,p_serial,p_user,p_issuer,p_period,p_pubkey);
		assignable \nothing;
		ensures true; @*/
	public void run_addCertificate_idcert( Integer p_pubkey_user, Integer p_ce, Integer p_serial, Integer p_user, BSet<Integer> p_issuer, Integer p_period, Integer p_pubkey){
		if(guard_addCertificate_idcert(p_pubkey_user,p_ce,p_serial,p_user,p_issuer,p_period,p_pubkey)) {
			BSet<Integer> certificates_tmp = machine.get_certificates();
			BSet<Integer> serial_tmp = machine.get_serial();
			BRelation<Integer,BSet<Integer>> certificateIssuer_tmp = machine.get_certificateIssuer();
			BRelation<Integer,Integer> certificateID_tmp = machine.get_certificateID();
			BRelation<Integer,Integer> validityPeriods_tmp = machine.get_validityPeriods();
			BRelation<Integer,Integer> isValidatedBy_tmp = machine.get_isValidatedBy();
			BSet<Integer> IDCert_tmp = machine.get_IDCert();
			BRelation<Integer,Integer> idcert_subject_tmp = machine.get_idcert_subject();
			BRelation<Integer,Integer> idcert_subjectPubK_tmp = machine.get_idcert_subjectPubK();

			machine.set_certificates((certificates_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_serial((serial_tmp.union(new BSet<Integer>(p_serial))));
			machine.set_certificateIssuer((certificateIssuer_tmp.union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(p_ce,p_issuer)))));
			machine.set_certificateID((certificateID_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_serial)))));
			machine.set_validityPeriods((validityPeriods_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_period)))));
			machine.set_isValidatedBy((isValidatedBy_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey)))));
			machine.set_IDCert((IDCert_tmp.union(new BSet<Integer>(p_ce))));
			machine.set_idcert_subject((idcert_subject_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_user)))));
			machine.set_idcert_subjectPubK((idcert_subjectPubK_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(p_ce,p_pubkey_user)))));

			System.out.println("addCertificate_idcert executed p_pubkey_user: " + p_pubkey_user + " p_ce: " + p_ce + " p_serial: " + p_serial + " p_user: " + p_user + " p_pubkey: " + p_pubkey + " p_period: " + p_period + " p_issuer: " + p_issuer + " ");
		}
	}

}
