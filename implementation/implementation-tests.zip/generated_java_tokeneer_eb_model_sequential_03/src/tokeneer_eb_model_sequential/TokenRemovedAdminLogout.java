package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class TokenRemovedAdminLogout{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public TokenRemovedAdminLogout(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_adminTokenPresence().equals(machine.absent) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && machine.get_enclaveStatus2().equals(machine.enclaveQuiescent)); @*/
	public boolean guard_TokenRemovedAdminLogout() {
		return (
				machine.get_adminTokenPresence().equals(machine.absent) && 
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				!machine.get_rolePresent().equals(machine.NoRole) && 
				machine.get_enclaveStatus2().equals(machine.enclaveQuiescent)
				
				);
	}

	/*@ requires guard_TokenRemovedAdminLogout();
		assignable machine.enclaveStatus2, machine.rolePresent, machine.currentAdminOp, machine.availableOps;
		ensures guard_TokenRemovedAdminLogout() &&  machine.get_enclaveStatus2() == \old(machine.enclaveQuiescent) &&  machine.get_rolePresent().equals(\old((machine.get_rolePresent().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoRole)))))) &&  machine.get_currentAdminOp().equals(\old((machine.get_currentAdminOp().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoOp)))))) &&  machine.get_availableOps().equals(\old((machine.get_availableOps().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoOp)))))); 
	 also
		requires !guard_TokenRemovedAdminLogout();
		assignable \nothing;
		ensures true; @*/
	public void run_TokenRemovedAdminLogout(){
		if(guard_TokenRemovedAdminLogout()) {
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();
			Integer rolePresent_tmp = machine.get_rolePresent();
			Integer currentAdminOp_tmp = machine.get_currentAdminOp();
			
			machine.set_enclaveStatus1(machine.enclaveQuiescent);
			machine.set_enclaveStatus2(machine.enclaveQuiescent);
			machine.set_rolePresent(machine.NoRole);
			machine.set_currentAdminOp(machine.NoOp);
			
			System.out.println("TokenRemovedAdminLogout executed ");
		}
	}

}
