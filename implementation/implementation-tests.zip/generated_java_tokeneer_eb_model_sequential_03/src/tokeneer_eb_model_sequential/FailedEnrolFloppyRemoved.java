package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class FailedEnrolFloppyRemoved{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public FailedEnrolFloppyRemoved(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus1().equals(machine.waitingEndEnrol) && machine.get_floppyPresence().equals(machine.absent)); @*/
	public boolean guard_FailedEnrolFloppyRemoved() {
		return (machine.get_enclaveStatus1().equals(machine.waitingEndEnrol) && machine.get_floppyPresence().equals(machine.absent));
	}

	/*@ requires guard_FailedEnrolFloppyRemoved();
		assignable machine.screenMsg1, machine.enclaveStatus1, machine.displayMessage2;
		ensures guard_FailedEnrolFloppyRemoved() &&  machine.get_screenMsg1() == \old(machine.insertEnrolmentData) &&  machine.get_enclaveStatus1() == \old(machine.notEnrolled) &&  machine.get_displayMessage2() == \old(machine.blank); 
	 also
		requires !guard_FailedEnrolFloppyRemoved();
		assignable \nothing;
		ensures true; @*/
	public void run_FailedEnrolFloppyRemoved(){
		if(guard_FailedEnrolFloppyRemoved()) {
			Integer screenMsg1_tmp = machine.get_screenMsg1();
			Integer enclaveStatus1_tmp = machine.get_enclaveStatus1();
			Integer displayMessage2_tmp = machine.get_displayMessage2();

			machine.set_screenMsg1(machine.insertEnrolmentData);
			machine.set_screenMsg2(machine.insertEnrolmentData);
			machine.set_enclaveStatus1(machine.notEnrolled);
			machine.set_enclaveStatus2(machine.notEnrolled);
			machine.set_displayMessage1(machine.blank);
			machine.set_displayMessage2(machine.blank);
			machine.set_displayMessage3(machine.blank);

			System.out.println("FailedEnrolFloppyRemoved executed ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg1()));
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage2()));
		}
	}

}
