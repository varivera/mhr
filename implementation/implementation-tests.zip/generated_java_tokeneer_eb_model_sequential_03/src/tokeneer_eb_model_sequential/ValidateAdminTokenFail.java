package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ValidateAdminTokenFail{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ValidateAdminTokenFail(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus2().equals(machine.gotAdminToken) && machine.get_adminTokenPresence().equals(machine.present) && NAT.instance.has(currentTime) && !(machine.get_tokenID().has(machine.get_currentAdminToken()) && machine.get_goodTok().apply(machine.get_currentAdminToken()).equals(machine.goodT) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken()))) && machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.AdminPrivilege.has(machine.get_authCertRole().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_validityPeriods().image(new BSet<Integer>(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).has(currentTime))); @*/
	public boolean guard_ValidateAdminTokenFail( Integer currentTime) {
		return (
				machine.get_enclaveStatus2().equals(machine.gotAdminToken) && 
				machine.get_adminTokenPresence().equals(machine.present) && 
				NAT.instance.has(currentTime) && 
				!(machine.get_tokenID().has(machine.get_currentAdminToken()) && 
						machine.get_goodTok().apply(machine.get_currentAdminToken()).equals(machine.goodT) && 
						machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
						machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && 
						machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
								machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).equals(
										machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
												machine.get_currentAdminToken()))) && 
						machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && 
						machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(
								machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(
										machine.get_currentAdminToken())))) && 
						machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
						machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(
								machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(
										machine.get_currentAdminToken())))) && 
						machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
						machine.AdminPrivilege.has(machine.get_authCertRole().apply(
								machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))) && 
						machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
						machine.get_validityPeriods().image(new BSet<Integer>(machine.get_tokenAuthCert().apply(
								machine.get_currentAdminToken()))).has(currentTime)
				)
			);
	}

	/*@ requires guard_ValidateAdminTokenFail(currentTime);
		assignable machine.screenMsg2, machine.enclaveStatus2;
		ensures guard_ValidateAdminTokenFail(currentTime) &&  machine.get_screenMsg2() == \old(machine.removeAdminToken) &&  machine.get_enclaveStatus2() == \old(machine.waitingRemoveAdminTokenFail); 
	 also
		requires !guard_ValidateAdminTokenFail(currentTime);
		assignable \nothing;
		ensures true; @*/
	public void run_ValidateAdminTokenFail( Integer currentTime){
		if(guard_ValidateAdminTokenFail(currentTime)) {
			Integer screenMsg2_tmp = machine.get_screenMsg2();
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();

			machine.set_screenMsg1(machine.removeAdminToken);
			machine.set_screenMsg2(machine.removeAdminToken);
			machine.set_enclaveStatus1(machine.waitingRemoveAdminTokenFail);
			machine.set_enclaveStatus2(machine.waitingRemoveAdminTokenFail);

			System.out.println("ValidateAdminTokenFail executed currentTime: " + currentTime + " ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
