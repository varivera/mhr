package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ValidateAdminTokenOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ValidateAdminTokenOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus2().equals(machine.gotAdminToken) && machine.get_adminTokenPresence().equals(machine.present) && NAT.instance.has(currentTime) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && machine.get_availableOps().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoOp) && machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && machine.get_tokenPrivCert().domain().has(machine.get_currentAdminToken()) && machine.get_tokenIandaCert().domain().has(machine.get_currentAdminToken()) && machine.get_attcert_baseCertID().domain().has(machine.get_certificateID().apply(machine.get_tokenPrivCert().apply(machine.get_currentAdminToken()))) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenPrivCert().apply(machine.get_currentAdminToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken()))) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenIandaCert().apply(machine.get_currentAdminToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken()))) && machine.get_tokenID().has(machine.get_currentAdminToken()) && machine.get_goodTok().apply(machine.get_currentAdminToken()).equals(machine.goodT) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken()))) && machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentAdminToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.AdminPrivilege.has(machine.get_authCertRole().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))) && machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && machine.get_validityPeriods().image(new BSet<Integer>(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).has(currentTime) && machine.AdminPrivilege.has(machine.get_authCertRole().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken())))); @*/
	public boolean guard_ValidateAdminTokenOK( Integer currentTime) {
		return (machine.get_enclaveStatus2().equals(machine.gotAdminToken) && 
				machine.get_adminTokenPresence().equals(machine.present) && 
				NAT.instance.has(currentTime) && 
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				machine.get_rolePresent().equals(machine.NoRole) && 
				machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_tokenPrivCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_tokenIandaCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_attcert_baseCertID().domain().has(machine.get_certificateID().apply(
						machine.get_tokenPrivCert().apply(machine.get_currentAdminToken()))) && 
				machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
						machine.get_tokenPrivCert().apply(machine.get_currentAdminToken()))).equals(
						machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
						machine.get_currentAdminToken()))) && 
				machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
						machine.get_tokenIandaCert().apply(machine.get_currentAdminToken()))).equals(
						machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
						machine.get_currentAdminToken()))) && 
				machine.get_tokenID().has(machine.get_currentAdminToken()) && 
				machine.get_goodTok().apply(machine.get_currentAdminToken()).equals(machine.goodT) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
						machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).equals(
						machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
						machine.get_currentAdminToken()))) && 
				machine.get_tokenIDCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(
						machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(
						machine.get_currentAdminToken())))) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(
						machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(
						machine.get_currentAdminToken())))) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.AdminPrivilege.has(machine.get_authCertRole().apply(
						machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentAdminToken()) && 
				machine.get_validityPeriods().image(new BSet<Integer>(
						machine.get_tokenAuthCert().apply(machine.get_currentAdminToken()))).has(currentTime) && 
				machine.AdminPrivilege.has(machine.get_authCertRole().apply(
						machine.get_tokenAuthCert().apply(machine.get_currentAdminToken())))
		);
	}

	/*@ requires guard_ValidateAdminTokenOK(currentTime);
		assignable machine.screenMsg2, machine.enclaveStatus2, machine.currentAdminOp;
		ensures guard_ValidateAdminTokenOK(currentTime) &&  machine.get_screenMsg2() == \old(machine.requestAdminOp) &&  machine.get_enclaveStatus2() == \old(machine.enclaveQuiescent) &&  machine.get_currentAdminOp().equals(\old((machine.get_currentAdminOp().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoOp)))))); 
	 also
		requires !guard_ValidateAdminTokenOK(currentTime);
		assignable \nothing;
		ensures true; @*/
	public void run_ValidateAdminTokenOK( Integer currentTime){
		if(guard_ValidateAdminTokenOK(currentTime)) {
			Integer screenMsg2_tmp = machine.get_screenMsg2();
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();
			Integer currentAdminOp_tmp = machine.get_currentAdminOp();
			Integer rolePresent_tmp = machine.get_rolePresent();
			
			machine.set_screenMsg1(machine.requestAdminOp);
			machine.set_screenMsg2(machine.requestAdminOp);
			machine.set_enclaveStatus1(machine.enclaveQuiescent);
			machine.set_enclaveStatus2(machine.enclaveQuiescent);
			machine.set_currentAdminOp(machine.NoOp);
			machine.set_rolePresent(machine.get_authCertRole().apply(machine.get_tokenAuthCert().apply(machine.get_currentAdminToken())));
			
			System.out.println("ValidateAdminTokenOK executed currentTime: " + currentTime + " ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
