package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ValidateOpRequestOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ValidateOpRequestOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus2().equals(machine.enclaveQuiescent) && machine.get_adminTokenPresence().equals(machine.present) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && new BSet<Integer>(machine.quiescent,machine.waitingRemoveTokenFail).has(machine.get_entry_status2()) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoOp) && machine.get_keyedOps().inverse().domain().has(p_currentKeyedData) && machine.get_keyedDataPresence().equals(machine.present)); @*/
	public boolean guard_ValidateOpRequestOK( Integer p_currentKeyedData) {
		return (
				machine.get_enclaveStatus2().equals(machine.enclaveQuiescent) && 
				machine.get_adminTokenPresence().equals(machine.present) && 
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				!machine.get_rolePresent().equals(machine.NoRole) &&
				new BSet<Integer>(machine.quiescent,machine.waitingRemoveTokenFail).has(machine.get_entry_status2()) && 
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				machine.get_currentAdminOp().equals(machine.NoOp) && 
				machine.get_keyedOps().inverse().domain().has(p_currentKeyedData) && 
				machine.get_keyedDataPresence().equals(machine.present) && 
				machine.get_keyedOps().inverse().image(new BSet<Integer>(p_currentKeyedData)).isSubset(machine.availableOps.inverse().image(new BSet<Integer>(machine.get_rolePresent())))
		);
	}

	/*@ requires guard_ValidateOpRequestOK(p_currentKeyedData);
		assignable machine.currentAdminOp, machine.screenMsg2, machine.enclaveStatus2;
		ensures guard_ValidateOpRequestOK(p_currentKeyedData) &&  machine.get_currentAdminOp().equals(\old((machine.get_currentAdminOp().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.get_keyedOps().inverse().apply(p_currentKeyedData))))))) &&  machine.get_screenMsg2() == \old(machine.doingOp) &&  machine.get_enclaveStatus2() == \old(machine.waitingStartAdminOp); 
	 also
		requires !guard_ValidateOpRequestOK(p_currentKeyedData);
		assignable \nothing;
		ensures true; @*/
	public void run_ValidateOpRequestOK( Integer p_currentKeyedData){
		if(guard_ValidateOpRequestOK(p_currentKeyedData)) {
			Integer currentAdminOp_tmp = machine.get_currentAdminOp();
			Integer screenMsg2_tmp = machine.get_screenMsg2();
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();

			machine.set_currentAdminOp(machine.get_keyedOps().inverse().apply(p_currentKeyedData));
			machine.set_screenMsg2(machine.doingOp);
			machine.set_screenMsg2(machine.doingOp);
			machine.set_enclaveStatus2(machine.waitingStartAdminOp);
			machine.set_enclaveStatus1(machine.waitingStartAdminOp);

			System.out.println("ValidateOpRequestOK executed p_currentKeyedData: " + p_currentKeyedData + " ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
