package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class FinishUpdateConfigDataFail{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public FinishUpdateConfigDataFail(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && !machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoOp) && machine.get_enclaveStatus2().equals(machine.waitingFinishAdminOp) && machine.get_adminTokenPresence().equals(machine.present) && machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.updateConfigData) && machine.FLOPPY.has(p_currentFloppy) && !machine.get_configFile().range().has(p_currentFloppy)); @*/
	public boolean guard_FinishUpdateConfigDataFail( Integer p_currentFloppy) {
		return (
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				!machine.get_rolePresent().equals(machine.NoRole) &&  
				!machine.get_currentAdminOp().equals(machine.NoOp) && 
				machine.get_enclaveStatus2().equals(machine.waitingFinishAdminOp) && 
				machine.get_adminTokenPresence().equals(machine.present) && 
				machine.get_currentAdminOp().equals(machine.updateConfigData) && 
				machine.FLOPPY.has(p_currentFloppy) && 
				!machine.get_configFile().range().has(p_currentFloppy));
	}

	/*@ requires guard_FinishUpdateConfigDataFail(p_currentFloppy);
		assignable machine.enclaveStatus2, machine.screenMsg2;
		ensures guard_FinishUpdateConfigDataFail(p_currentFloppy) &&  machine.get_enclaveStatus2() == \old(machine.enclaveQuiescent) &&  machine.get_screenMsg2() == \old(machine.invalidData); 
	 also
		requires !guard_FinishUpdateConfigDataFail(p_currentFloppy);
		assignable \nothing;
		ensures true; @*/
	public void run_FinishUpdateConfigDataFail( Integer p_currentFloppy){
		if(guard_FinishUpdateConfigDataFail(p_currentFloppy)) {
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();
			Integer screenMsg2_tmp = machine.get_screenMsg2();

			machine.set_enclaveStatus1(machine.enclaveQuiescent);
			machine.set_enclaveStatus2(machine.enclaveQuiescent);
			machine.set_screenMsg1(machine.invalidData);
			machine.set_screenMsg2(machine.invalidData);

			System.out.println("FinishUpdateConfigDataFail executed p_currentFloppy: " + p_currentFloppy + " ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
