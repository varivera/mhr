package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ValidateOpRequestFail{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ValidateOpRequestFail(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus2().equals(machine.enclaveQuiescent) && machine.get_adminTokenPresence().equals(machine.present) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && new BSet<Integer>(machine.quiescent,machine.waitingRemoveTokenFail).has(machine.get_entry_status2()) && machine.get_keyedDataPresence().equals(machine.present) && !machine.get_keyedOps().inverse().domain().has(p_currentKeyedData)); @*/
	public boolean guard_ValidateOpRequestFail( Integer p_currentKeyedData) {
		return (
				machine.get_enclaveStatus2().equals(machine.enclaveQuiescent) && 
				machine.get_adminTokenPresence().equals(machine.present) &&
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) &&
				!machine.get_rolePresent().equals(machine.NoRole) &&
				new BSet<Integer>(machine.quiescent,machine.waitingRemoveTokenFail).has(machine.get_entry_status2()) &&
				machine.get_keyedDataPresence().equals(machine.present) &&
				!machine.get_keyedOps().inverse().domain().has(p_currentKeyedData));
	}

	/*@ requires guard_ValidateOpRequestFail(p_currentKeyedData);
		assignable machine.screenMsg2;
		ensures guard_ValidateOpRequestFail(p_currentKeyedData) &&  machine.get_screenMsg2() == \old(machine.invalidRequest); 
	 also
		requires !guard_ValidateOpRequestFail(p_currentKeyedData);
		assignable \nothing;
		ensures true; @*/
	public void run_ValidateOpRequestFail( Integer p_currentKeyedData){
		if(guard_ValidateOpRequestFail(p_currentKeyedData)) {
			Integer screenMsg2_tmp = machine.get_screenMsg2();

			machine.set_screenMsg2(machine.invalidRequest);
			machine.set_screenMsg1(machine.invalidRequest);

			System.out.println("ValidateOpRequestFail executed p_currentKeyedData: " + p_currentKeyedData + " ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
