package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class FinishArchiveLogOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public FinishArchiveLogOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && !machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoOp) && machine.get_enclaveStatus2().equals(machine.waitingFinishAdminOp) && machine.get_adminTokenPresence().equals(machine.present) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.archiveLog) && machine.get_floppyPresence().equals(machine.present)); @*/
	public boolean guard_FinishArchiveLogOK() {
		return (
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				!machine.get_rolePresent().equals(machine.NoRole) && 
				!machine.get_currentAdminOp().equals(machine.NoOp) && 
				machine.get_enclaveStatus2().equals(machine.waitingFinishAdminOp) && 
				machine.get_adminTokenPresence().equals(machine.present) && 
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				machine.get_currentAdminOp().equals(machine.archiveLog) && 
				machine.get_floppyPresence().equals(machine.present));
	}

	/*@ requires guard_FinishArchiveLogOK();
		assignable machine.enclaveStatus2, machine.screenMsg2;
		ensures guard_FinishArchiveLogOK() &&  machine.get_enclaveStatus2() == \old(machine.enclaveQuiescent) &&  machine.get_screenMsg2() == \old(machine.requestAdminOp); 
	 also
		requires !guard_FinishArchiveLogOK();
		assignable \nothing;
		ensures true; @*/
	public void run_FinishArchiveLogOK(){
		if(guard_FinishArchiveLogOK()) {
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();
			Integer screenMsg2_tmp = machine.get_screenMsg2();

			machine.set_enclaveStatus1(machine.enclaveQuiescent);
			machine.set_enclaveStatus2(machine.enclaveQuiescent);
			machine.set_screenMsg1(machine.requestAdminOp);
			machine.set_screenMsg2(machine.requestAdminOp);

			System.out.println("FinishArchiveLogOK executed ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
