package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class BioCheckNotRequired{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public BioCheckNotRequired(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (NAT.instance.has(currentTime) && machine.get_entry_status1().equals(machine.gotUserToken) && machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(machine.get_tokenAuthCert().apply(machine.get_currentToken()))).equals(machine.get_certificateID().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && machine.get_validityPeriods().image(new BSet<Integer>(machine.get_tokenAuthCert().apply(machine.get_currentToken()))).has(currentTime) && machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && machine.get_issuer().has(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentToken()))) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(machine.get_currentToken())))) && machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(machine.get_currentToken())))) && machine.get_userTokenPresence().equals(machine.present) && machine.get_tokenID().has(machine.get_currentToken()) && machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT)); @*/
	public boolean guard_BioCheckNotRequired( Integer currentTime) {
		return (
				NAT.instance.has(currentTime) && 
				machine.get_entry_status1().equals(machine.gotUserToken) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && 
				machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && 
				machine.get_attcert_baseCertID().apply(machine.get_certificateID().apply(
						machine.get_tokenAuthCert().apply(machine.get_currentToken()))).equals(
						machine.get_certificateID().apply(machine.get_tokenIDCert().apply(
						machine.get_currentToken()))) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && 
				machine.get_validityPeriods().image(new BSet<Integer>(
						machine.get_tokenAuthCert().apply(machine.get_currentToken()))).has(currentTime) && 
				machine.get_tokenIDCert().domain().has(machine.get_currentToken()) && 
				machine.get_issuer().has(machine.get_certificateIssuer().apply(
						machine.get_tokenIDCert().apply(machine.get_currentToken()))) && 
				machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(
						machine.get_certificateIssuer().apply(machine.get_tokenIDCert().apply(
						machine.get_currentToken())))) && 
				machine.get_tokenAuthCert().domain().has(machine.get_currentToken()) && 
				machine.get_isValidatedBy().range().has(machine.get_issuerKey().apply(
						machine.get_certificateIssuer().apply(machine.get_tokenAuthCert().apply(
						machine.get_currentToken())))) && 
				machine.get_userTokenPresence().equals(machine.present) && 
				machine.get_tokenID().has(machine.get_currentToken()) && 
				machine.get_goodTok().apply(machine.get_currentToken()).equals(machine.goodT)
		);
	}

	/*@ requires guard_BioCheckNotRequired(currentTime);
		assignable machine.entry_status1, machine.displayMessage1;
		ensures guard_BioCheckNotRequired(currentTime) &&  machine.get_entry_status1() == \old(machine.waitingEntry) &&  machine.get_displayMessage1() == \old(machine.wait); 
	 also
		requires !guard_BioCheckNotRequired(currentTime);
		assignable \nothing;
		ensures true; @*/
	public void run_BioCheckNotRequired( Integer currentTime){
		if(guard_BioCheckNotRequired(currentTime)) {
			Integer entry_status1_tmp = machine.get_entry_status1();
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_entry_status1(machine.waitingEntry);
			machine.set_entry_status2(machine.waitingEntry);
			machine.set_displayMessage1(machine.wait);
			machine.set_displayMessage2(machine.wait);
			machine.set_displayMessage3(machine.wait);

			System.out.println("BioCheckNotRequired executed currentTime: " + currentTime + " ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
