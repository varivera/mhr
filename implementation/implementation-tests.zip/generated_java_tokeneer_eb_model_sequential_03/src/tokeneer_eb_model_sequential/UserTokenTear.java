package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class UserTokenTear{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public UserTokenTear(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (new BSet<Integer>(machine.gotUserToken,machine.waitingUpdateToken,machine.waitingFinger,machine.gotFinger,machine.waitingEntry).has(machine.get_entry_status1()) && machine.get_userTokenPresence().equals(machine.absent)); @*/
	public boolean guard_UserTokenTear() {
		return (
				new BSet<Integer>(machine.gotUserToken,machine.waitingUpdateToken,machine.waitingFinger,machine.gotFinger,machine.waitingEntry).has(machine.get_entry_status1()) && 
				machine.get_userTokenPresence().equals(machine.absent)
				);
	}

	/*@ requires guard_UserTokenTear();
		assignable machine.entry_status1, machine.displayMessage1;
		ensures guard_UserTokenTear() &&  machine.get_entry_status1() == \old(machine.quiescent) &&  machine.get_displayMessage1() == \old(machine.welcome); 
	 also
		requires !guard_UserTokenTear();
		assignable \nothing;
		ensures true; @*/
	public void run_UserTokenTear(){
		if(guard_UserTokenTear()) {
			Integer entry_status1_tmp = machine.get_entry_status1();
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_entry_status1(machine.quiescent);
			machine.set_entry_status2(machine.quiescent);
			machine.set_displayMessage1(machine.welcome);
			machine.set_displayMessage2(machine.welcome);
			machine.set_displayMessage3(machine.welcome);

			System.out.println("UserTokenTear executed ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
