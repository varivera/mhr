package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class readAdminToken{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public readAdminToken(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_tokenID().has(token_admin_to_read) && new BSet<Integer>(machine.quiescent,machine.waitingRemoveTokenFail).has(machine.get_entry_status2()) && machine.get_enclaveStatus2().equals(machine.enclaveQuiescent) && machine.get_adminToken().inverse().domain().has(token_admin_to_read) && machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(token_admin_to_read)).equals(machine.NoRole) && machine.get_adminTokenPresence().equals(machine.present)); @*/
	public boolean guard_readAdminToken( Integer token_admin_to_read) {
		return (
				machine.get_tokenID().has(token_admin_to_read) &&
				new BSet<Integer>(machine.quiescent,machine.waitingRemoveTokenFail).has(machine.get_entry_status2()) &&
				machine.get_enclaveStatus2().equals(machine.enclaveQuiescent) &&
				machine.get_adminToken().inverse().domain().has(token_admin_to_read) &&
				machine.get_rolePresent().equals(machine.NoRole) &&
				machine.get_adminTokenPresence().equals(machine.present)
				);
	}

	/*@ requires guard_readAdminToken(token_admin_to_read);
		assignable machine.enclaveStatus2, machine.currentAdminToken;
		ensures guard_readAdminToken(token_admin_to_read) &&  machine.get_enclaveStatus2() == \old(machine.gotAdminToken) &&  machine.get_currentAdminToken() == \old(token_admin_to_read); 
	 also
		requires !guard_readAdminToken(token_admin_to_read);
		assignable \nothing;
		ensures true; @*/
	public void run_readAdminToken( Integer token_admin_to_read){
		if(guard_readAdminToken(token_admin_to_read)) {
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();
			Integer currentAdminToken_tmp = machine.get_currentAdminToken();

			machine.set_enclaveStatus1(machine.gotAdminToken);
			machine.set_enclaveStatus2(machine.gotAdminToken);
			machine.set_currentAdminToken(token_admin_to_read);

			System.out.println("readAdminToken executed token_admin_to_read: " + token_admin_to_read + " ");
		}
	}

}
