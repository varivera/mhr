package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class StartArchiveLogWaitingFloppy{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public StartArchiveLogWaitingFloppy(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus2().equals(machine.waitingStartAdminOp) && machine.get_adminTokenPresence().equals(machine.present) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.archiveLog) && machine.get_floppyPresence().equals(machine.absent)); @*/
	public boolean guard_StartArchiveLogWaitingFloppy() {
		return (
				machine.get_enclaveStatus2().equals(machine.waitingStartAdminOp) &&
				machine.get_adminTokenPresence().equals(machine.present) &&
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) &&
				machine.get_currentAdminOp().equals(machine.archiveLog) &&
				machine.get_floppyPresence().equals(machine.absent));
	}

	/*@ requires guard_StartArchiveLogWaitingFloppy();
		assignable machine.screenMsg2;
		ensures guard_StartArchiveLogWaitingFloppy() &&  machine.get_screenMsg2() == \old(machine.insertBlankFloppy); 
	 also
		requires !guard_StartArchiveLogWaitingFloppy();
		assignable \nothing;
		ensures true; @*/
	public void run_StartArchiveLogWaitingFloppy(){
		if(guard_StartArchiveLogWaitingFloppy()) {
			Integer screenMsg2_tmp = machine.get_screenMsg2();

			machine.set_screenMsg1(machine.insertBlankFloppy);
			machine.set_screenMsg2(machine.insertBlankFloppy);

			System.out.println("StartArchiveLogWaitingFloppy executed ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
