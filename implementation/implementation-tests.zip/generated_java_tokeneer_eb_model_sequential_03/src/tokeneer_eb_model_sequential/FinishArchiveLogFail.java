package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class FinishArchiveLogFail{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public FinishArchiveLogFail(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && !machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoOp) && machine.get_enclaveStatus2().equals(machine.waitingFinishAdminOp) && machine.get_adminTokenPresence().equals(machine.present) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.archiveLog) && machine.get_floppyPresence().equals(machine.absent) || machine.get_floppyPresence().equals(machine.present)); @*/
	public boolean guard_FinishArchiveLogFail() {
		return (
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				!machine.get_rolePresent().equals(machine.NoRole) && 
				!machine.get_currentAdminOp().equals(machine.NoOp) && 
				machine.get_enclaveStatus2().equals(machine.waitingFinishAdminOp) && 
				machine.get_adminTokenPresence().equals(machine.present) && 
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				machine.get_currentAdminOp().equals(machine.archiveLog) && 
				machine.get_floppyPresence().equals(machine.absent) || machine.get_floppyPresence().equals(machine.present));
	}

	/*@ requires guard_FinishArchiveLogFail();
		assignable machine.enclaveStatus2, machine.screenMsg2;
		ensures guard_FinishArchiveLogFail() &&  machine.get_enclaveStatus2() == \old(machine.enclaveQuiescent) &&  machine.get_screenMsg2() == \old(machine.archiveFailed); 
	 also
		requires !guard_FinishArchiveLogFail();
		assignable \nothing;
		ensures true; @*/
	public void run_FinishArchiveLogFail(){
		if(guard_FinishArchiveLogFail()) {
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();
			Integer screenMsg2_tmp = machine.get_screenMsg2();

			machine.set_enclaveStatus1(machine.enclaveQuiescent);
			machine.set_enclaveStatus2(machine.enclaveQuiescent);
			machine.set_screenMsg1(machine.archiveFailed);
			machine.set_screenMsg2(machine.archiveFailed);

			System.out.println("FinishArchiveLogFail executed ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
