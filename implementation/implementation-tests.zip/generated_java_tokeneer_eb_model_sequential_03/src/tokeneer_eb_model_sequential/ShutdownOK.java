package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ShutdownOK{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ShutdownOK(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && !machine.get_rolePresent().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.NoRole) && machine.get_enclaveStatus2().equals(machine.waitingStartAdminOp) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.shutdownOp) && machine.get_currentDoor().equals(machine.closed) && NAT.instance.has(currentTime)); @*/
	public boolean guard_ShutdownOK( Integer currentTime) {
		return (
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
				!machine.get_rolePresent().equals(machine.NoRole) &&
				machine.get_enclaveStatus2().equals(machine.waitingStartAdminOp) &&
				machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) &&
				machine.get_currentAdminOp().equals(machine.shutdownOp) &&
				machine.get_currentDoor().equals(machine.closed) &&
				NAT.instance.has(currentTime));
	}

	/*@ requires guard_ShutdownOK(currentTime);
		assignable machine.latchTimeout2, machine.alarmTimeout2, machine.rolePresent, machine.currentAdminOp, machine.availableOps, machine.screenMsg2, machine.enclaveStatus2, machine.displayMessage3;
		ensures guard_ShutdownOK(currentTime) &&  machine.get_latchTimeout2() == \old(currentTime) &&  machine.get_alarmTimeout2() == \old(currentTime) &&  machine.get_rolePresent().equals(\old((machine.get_rolePresent().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoRole)))))) &&  machine.get_currentAdminOp().equals(\old((machine.get_currentAdminOp().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoOp)))))) &&  machine.get_availableOps().equals(\old((machine.get_availableOps().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken()),machine.NoOp)))))) &&  machine.get_screenMsg2() == \old(machine.clear) &&  machine.get_enclaveStatus2() == \old(machine.shutdown) &&  machine.get_displayMessage3() == \old(machine.blank); 
	 also
		requires !guard_ShutdownOK(currentTime);
		assignable \nothing;
		ensures true; @*/
	public void run_ShutdownOK( Integer currentTime){
		if(guard_ShutdownOK(currentTime)) {
			Integer latchTimeout2_tmp = machine.get_latchTimeout2();
			Integer alarmTimeout2_tmp = machine.get_alarmTimeout2();
			Integer rolePresent_tmp = machine.get_rolePresent();
			Integer currentAdminOp_tmp = machine.get_currentAdminOp();
			Integer screenMsg2_tmp = machine.get_screenMsg2();
			Integer enclaveStatus2_tmp = machine.get_enclaveStatus2();
			Integer displayMessage3_tmp = machine.get_displayMessage3();

			machine.set_latchTimeout1(currentTime);
			machine.set_latchTimeout2(currentTime);
			machine.set_alarmTimeout1(currentTime);
			machine.set_alarmTimeout2(currentTime);
			machine.set_rolePresent(machine.NoRole);
			machine.set_currentAdminOp(machine.NoOp);
			machine.set_screenMsg1(machine.clear);
			machine.set_screenMsg2(machine.clear);
			machine.set_enclaveStatus1(machine.shutdown);
			machine.set_enclaveStatus2(machine.shutdown);
			machine.set_displayMessage1(machine.blank);
			machine.set_displayMessage2(machine.blank);
			machine.set_displayMessage3(machine.blank);

			System.out.println("ShutdownOK executed currentTime: " + currentTime + " ");
			System.out.println("Screen Messsage: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
			System.out.println("Display Messsage: " + Test_ref6_admin.print_display_message(machine.get_displayMessage3()));
		}
	}

}
