package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class FailedAccessTokenRemoved{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public FailedAccessTokenRemoved(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_entry_status1().equals(machine.waitingRemoveTokenFail) && machine.get_userTokenPresence().equals(machine.absent)); @*/
	public boolean guard_FailedAccessTokenRemoved() {
		return (
				machine.get_entry_status1().equals(machine.waitingRemoveTokenFail) && 
				machine.get_userTokenPresence().equals(machine.absent)
				);
	}

	/*@ requires guard_FailedAccessTokenRemoved();
		assignable machine.entry_status1, machine.displayMessage1;
		ensures guard_FailedAccessTokenRemoved() &&  machine.get_entry_status1() == \old(machine.quiescent) &&  machine.get_displayMessage1() == \old(machine.welcome); 
	 also
		requires !guard_FailedAccessTokenRemoved();
		assignable \nothing;
		ensures true; @*/
	public void run_FailedAccessTokenRemoved(){
		if(guard_FailedAccessTokenRemoved()) {
			Integer entry_status1_tmp = machine.get_entry_status1();
			Integer displayMessage1_tmp = machine.get_displayMessage1();

			machine.set_entry_status1(machine.quiescent);
			machine.set_entry_status2(machine.quiescent);
			machine.set_displayMessage1(machine.welcome);
			machine.set_displayMessage2(machine.welcome);
			machine.set_displayMessage3(machine.welcome);

			System.out.println("FailedAccessTokenRemoved executed ");
			System.out.println("Display Message: " + Test_ref6_admin.print_display_message(machine.get_displayMessage1()));
		}
	}

}
