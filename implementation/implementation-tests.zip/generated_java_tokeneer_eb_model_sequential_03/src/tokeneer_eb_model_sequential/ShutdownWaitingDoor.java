package tokeneer_eb_model_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ShutdownWaitingDoor{
	private ref6_admin machine; // reference to the machine 

	/*@ requires true;
		assignable \everything;
		ensures machine == m; */
	public ShutdownWaitingDoor(ref6_admin m) {
		machine = m;
	}

	/*@ requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_enclaveStatus2().equals(machine.waitingStartAdminOp) && machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && machine.get_currentAdminOp().apply(machine.get_adminToken().inverse().apply(machine.get_currentAdminToken())).equals(machine.shutdownOp) && machine.get_currentDoor().equals(machine.open)); @*/
	public boolean guard_ShutdownWaitingDoor() {
		return (
			machine.get_enclaveStatus2().equals(machine.waitingStartAdminOp) && 
			machine.get_adminToken().inverse().domain().has(machine.get_currentAdminToken()) && 
			machine.get_currentAdminOp().equals(machine.shutdownOp) &&
			machine.get_currentDoor().equals(machine.open));
	}

	/*@ requires guard_ShutdownWaitingDoor();
		assignable machine.screenMsg2;
		ensures guard_ShutdownWaitingDoor() &&  machine.get_screenMsg2() == \old(machine.closeDoor); 
	 also
		requires !guard_ShutdownWaitingDoor();
		assignable \nothing;
		ensures true; @*/
	public void run_ShutdownWaitingDoor(){
		if(guard_ShutdownWaitingDoor()) {
			Integer screenMsg2_tmp = machine.get_screenMsg2();

			machine.set_screenMsg1(machine.closeDoor);
			machine.set_screenMsg2(machine.closeDoor);

			System.out.println("ShutdownWaitingDoor executed ");
			System.out.println("Screen Message: " + Test_ref6_admin.print_screen_message(machine.get_screenMsg2()));
		}
	}

}
