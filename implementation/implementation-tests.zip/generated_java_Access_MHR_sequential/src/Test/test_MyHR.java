package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Access_MHR_sequential.ref3_authorised_reps;
import eventb_prelude.BRelation;
import eventb_prelude.BSet;
import eventb_prelude.Pair;

class test_MyHR {

	ref3_authorised_reps machine; 
	
	Integer so = 0;
	Integer u1 = 1;
	Integer u2 = 2;
	Integer mhr1 = 3;
	Integer mhr2 = 4;
	Integer r1 = 5;
	Integer r2 = 6;
	Integer r3 = 7;
	Integer r4 = 8;
	Integer r5 = 9;
	Integer r6 = 10;
	Integer r7 = 11;
	Integer nom1 = 12;
	Integer nom2 = 13;
	Integer nom3 = 14;
	Integer mhr_nom1 = 18;
	Integer mhr_nom2 = 19;
	Integer mhr_nom3 = 20;
	Integer sp1 = 15;
	Integer sp2 = 16;
	Integer sp3 = 17;
	Integer auth = 21;
	Integer mhr_auth = 22;

	@BeforeEach
	void setUp() {
		machine = new ref3_authorised_reps();
		machine.set_system_operator(new BSet<Integer>(so));

		// setting MyHR for reps
		machine.set_my_health_record_DB (new BSet<Integer>(mhr_nom1, mhr_nom2, mhr_nom3, mhr_auth));
		machine.set_consumer (new BSet<Integer>(nom1, nom2, nom3, auth));
		machine.set_MyHR (new BRelation<Integer,Integer>(
				new Pair<Integer, Integer>(nom1,mhr_nom1),
				new Pair<Integer, Integer>(nom2,mhr_nom2),
				new Pair<Integer, Integer>(nom3,mhr_nom3),
				new Pair<Integer, Integer>(auth,mhr_auth)
				));

		// seting service provicers (Init)
		machine.set_service_providers (new BSet<Integer>(sp1, sp2, sp3));
		// Setting up MyHR for U1 according to figure in https://github.com/varivera/mhr/blob/master/implementation/initTests.png
		//-> records
		assertTrue(machine.evt_opt_in.guard_opt_in(u1, mhr1, so), "Problem to opt-in u1");
		machine.evt_opt_in.run_opt_in(u1, mhr1, so);

		assertTrue(machine.evt_upload_general_record_owner.guard_upload_general_record_owner(u1, r1), "Problem executing guard_view_record_owner");
		machine.evt_upload_general_record_owner.run_upload_general_record_owner(u1, r1);

		assertTrue(machine.evt_upload_general_record_owner.guard_upload_general_record_owner(u1, r2), "Problem executing guard_view_record_owner");
		machine.evt_upload_general_record_owner.run_upload_general_record_owner(u1, r2);

		assertTrue(machine.evt_upload_restricted_record_owner.guard_upload_restricted_record_owner(u1, r3), "Problem executing guard_upload_restricted_record_owner");
		machine.evt_upload_restricted_record_owner.run_upload_restricted_record_owner(u1, r3);

		assertTrue(machine.evt_upload_general_record_owner.guard_upload_general_record_owner(u1, r4), "Problem executing guard_view_record_owner");
		machine.evt_upload_general_record_owner.run_upload_general_record_owner(u1, r4);

		assertTrue(machine.evt_hide_record.guard_hide_record(u1, r1), "Problem executing guard_hide_record");
		machine.evt_hide_record.run_hide_record(u1, r1);

		// -> service providers
		assertTrue(machine.evt_add_consumer_sp.guard_add_consumer_sp(u1, sp1), "Problem executing guard_add_consumer_sp");
		machine.evt_add_consumer_sp.run_add_consumer_sp(u1, sp1);

		assertTrue(machine.evt_add_consumer_sp.guard_add_consumer_sp(u1, sp2), "Problem executing guard_add_consumer_sp");
		machine.evt_add_consumer_sp.run_add_consumer_sp(u1, sp2);

		assertTrue(machine.evt_add_consumer_sp.guard_add_consumer_sp(u1, sp3), "Problem executing guard_add_consumer_sp");
		machine.evt_add_consumer_sp.run_add_consumer_sp(u1, sp3);

		assertTrue(machine.evt_give_restricted_access_sp.guard_give_restricted_access_sp(u1, mhr1, sp2), "Problem executing guard_give_restricted_access_sp");
		machine.evt_give_restricted_access_sp.run_give_restricted_access_sp(u1, mhr1, sp2);

		assertTrue(machine.evt_revoke_access_sp.guard_revoke_access_sp(u1, mhr1, sp3), "Problem executing guard_revoke_access_sp");
		machine.evt_revoke_access_sp.run_revoke_access_sp(u1, mhr1, sp3);

		// -> nominated representatives
		assertTrue(machine.evt_add_nominated.guard_add_nominated(u1, mhr1, nom1), "Problem executing guard_add_nominated");
		machine.evt_add_nominated.run_add_nominated(u1, mhr1, nom1);

		assertTrue(machine.evt_add_nominated.guard_add_nominated(u1, mhr1, nom2), "Problem executing guard_add_nominated");
		machine.evt_add_nominated.run_add_nominated(u1, mhr1, nom2);

		assertTrue(machine.evt_grant_restrict_access_to_general_nominated.guard_grant_restrict_access_to_general_nominated(u1, mhr1, nom1), "Problem executing guard_grant_restrict_access_to_general_nominated");
		machine.evt_grant_restrict_access_to_general_nominated.run_grant_restrict_access_to_general_nominated(u1, mhr1, nom1);

		assertTrue(machine.evt_grant_full_access_to_nominated.guard_grant_full_access_to_nominated(u1, mhr1, nom3), "Problem executing guard_grant_full_access_to_nominated");
		machine.evt_grant_full_access_to_nominated.run_grant_full_access_to_nominated(u1, mhr1, nom3);

		
		// Setting up MyHR for U2 according to figure in ???
		assertTrue(machine.evt_opt_in.guard_opt_in(u2, mhr2, so), "Problem to opt-in u2");
		machine.evt_opt_in.run_opt_in(u2, mhr2, so);
		
		//-> records
		assertTrue(machine.evt_upload_general_record_owner.guard_upload_general_record_owner(u2, r5), "Problem executing guard_view_record_owner");
		machine.evt_upload_general_record_owner.run_upload_general_record_owner(u2, r5);
		
		assertTrue(machine.evt_upload_general_record_owner.guard_upload_general_record_owner(u2, r7), "Problem executing guard_view_record_owner");
		machine.evt_upload_general_record_owner.run_upload_general_record_owner(u2, r7);

		assertTrue(machine.evt_upload_restricted_record_owner.guard_upload_restricted_record_owner(u2, r6), "Problem executing guard_upload_restricted_record_owner");
		machine.evt_upload_restricted_record_owner.run_upload_restricted_record_owner(u2, r6);
		
		assertTrue(machine.evt_hide_record.guard_hide_record(u2, r7), "Problem executing guard_hide_record");
		machine.evt_hide_record.run_hide_record(u2, r7);

		// -> service providers
		assertTrue(machine.evt_add_consumer_sp.guard_add_consumer_sp(u2, sp1), "Problem executing guard_add_consumer_sp");
		machine.evt_add_consumer_sp.run_add_consumer_sp(u2, sp1);

		assertTrue(machine.evt_add_consumer_sp.guard_add_consumer_sp(u2, sp3), "Problem executing guard_add_consumer_sp");
		machine.evt_add_consumer_sp.run_add_consumer_sp(u2, sp3);

		assertTrue(machine.evt_give_restricted_access_sp.guard_give_restricted_access_sp(u2, mhr2, sp1), "Problem executing guard_give_restricted_access_sp");
		machine.evt_give_restricted_access_sp.run_give_restricted_access_sp(u2, mhr2, sp1);

		assertTrue(machine.evt_revoke_access_sp.guard_revoke_access_sp(u2, mhr2, sp3), "Problem executing guard_revoke_access_sp");
		machine.evt_revoke_access_sp.run_revoke_access_sp(u2, mhr2, sp3);

		// -> authorised representative
		assertTrue(machine.evt_add_authorised.guard_add_authorised(auth, mhr2, so), "Problem executing guard_add_authorised");
		machine.evt_add_authorised.run_add_authorised(auth, mhr2, so);
	}

	@Test
	void test1_access() {
		/**
		 * Consumers have access to their own records, except for hidden records, that cannot
		 * 	be accessed by anyone. 
		 */
		assertFalse(machine.evt_view_record_owner.guard_view_record_owner(u1, r1), "Problem executing guard_view_record_owner");
		assertTrue(machine.evt_view_record_owner.guard_view_record_owner(u1, r2), "Problem executing guard_view_record_owner");
		assertTrue(machine.evt_view_record_owner.guard_view_record_owner(u1, r3), "Problem executing guard_view_record_owner");
		assertTrue(machine.evt_view_record_owner.guard_view_record_owner(u1, r4), "Problem executing guard_view_record_owner");
	}
	
	@Test
	void test2_access() {
		/**
		 * General Service providers (with the respective access to MyHR) have access
		 * 	only to records marked as 'general'.
		 */
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r2, sp1), "Problem executing guard_view_record_service_provider");
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r4, sp1), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r3, sp1), "Problem executing guard_view_record_service_provider");	
	}
	
	@Test
	void test3_access() {
		/**
		 * Restricted Service providers (with the respective access to MyHR) have access
		 * 	to records marked as both 'general' and 'restricted'.
		 */
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u2, r5, sp1), "Problem executing guard_view_record_service_provider");
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u2, r6, sp1), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u2, r7, sp1), "Problem executing guard_view_record_service_provider");	
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r3, sp2), "Problem executing guard_view_record_service_provider");
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r4, sp2), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r1, sp2), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test4_access() {
		/**
		 * Revoked Service providers (with the respective access to MyHR) have access
		 * 	to no records.
		 */
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r1, sp3), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r2, sp3), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r3, sp3), "Problem executing guard_view_record_service_provider");	
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r4, sp3), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u2, r5, sp3), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u2, r6, sp3), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u2, r7, sp3), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test5_access() {
		/**
		 * General Nominated Representative (with the respective access to MyHR) have access
		 * 	only to records marked as 'general'.
		 */
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r2, nom2), "Problem executing guard_view_record_nominated");
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r4, nom2), "Problem executing guard_view_record_nominated");
		assertFalse(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r3, nom2), "Problem executing guard_view_record_nominated");
			
	}
	
	@Test
	void test6_access() {
		/**
		 * Restricted Nominated Representatives (with the respective access to MyHR) have access
		 * 	to records marked as both 'general' and 'restricted'.
		 */
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r2, nom1), "Problem executing guard_view_record_nominated");
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r4, nom1), "Problem executing guard_view_record_nominated");
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r3, nom1), "Problem executing guard_view_record_nominated");
	}
	
	@Test
	void test7_access() {
		/**
		 * Nominated Representatives have the same access permission than restricted nominated
		 * representatives.
		 */
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r2, nom3), "Problem executing guard_view_record_nominated");
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r4, nom3), "Problem executing guard_view_record_nominated");
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r3, nom3), "Problem executing guard_view_record_nominated");
	}
	
	@Test
	void test8_access() {
		/**
		 * Authorised reps. have full access to records marked as 'general' and 'restricted'
		 */
		assertTrue(machine.evt_view_record_authorised_rep.guard_view_record_authorised_rep(u2, r5, auth), "Problem executing guard_view_record_authorised_rep");
		assertTrue(machine.evt_view_record_authorised_rep.guard_view_record_authorised_rep(u2, r6, auth), "Problem executing guard_view_record_authorised_rep");
	}
	
	@Test
	void test9_access() {
		/**
		 *  Owners have not access to records if there is an Authorised reps.
		 */
		assertFalse(machine.evt_view_record_owner.guard_view_record_owner(u2, r5), "Problem executing guard_view_record_authorised_rep");
		assertFalse(machine.evt_view_record_owner.guard_view_record_owner(u2, r6), "Problem executing guard_view_record_authorised_rep");
	}
	
	@Test
	void test10_access() {
		/**
		 *  No one can acces hidden records
		 */
		assertFalse(machine.evt_view_record_owner.guard_view_record_owner(u1, r1), "Problem executing guard_view_record_owner");
		assertFalse(machine.evt_view_record_owner.guard_view_record_owner(u2, r7), "Problem executing guard_view_record_owner");
		assertFalse(machine.evt_view_record_authorised_rep.guard_view_record_authorised_rep(u2, r7,auth), "Problem executing guard_view_record_authorised_rep");
		assertFalse(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r1, nom1), "Problem executing guard_view_record_nominated");
		assertFalse(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r1, nom2), "Problem executing guard_view_record_nominated");
		assertFalse(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r1, nom3), "Problem executing guard_view_record_nominated");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r1, sp1), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r1, sp2), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r1, sp3), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u2, r7, sp1), "Problem executing guard_view_record_service_provider");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u2, r7, sp3), "Problem executing guard_view_record_service_provider");
	} 
	
	@Test
	void test11_control() {
		Integer new_r = -1;
		assertTrue(machine.evt_upload_general_record_owner.guard_upload_general_record_owner(u1, new_r), "Problem executing guard_upload_general_record_owner");
		machine.evt_upload_general_record_owner.run_upload_general_record_owner(u1, new_r);
		
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, new_r, sp1), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test12_control() {
		assertFalse(machine.evt_delete_record_owner.guard_delete_record_owner(u1, r1), "Problem executing guard_delete_record_owner");
	}
	
	@Test
	void test13_control() {
		assertTrue(machine.evt_delete_record_owner.guard_delete_record_owner(u1, r2), "Problem executing guard_delete_record_owner");
		machine.evt_delete_record_owner.run_delete_record_owner(u1, r2);
		assertFalse(machine.evt_delete_record_owner.guard_delete_record_owner(u1, r2), "Problem executing guard_delete_record_owner");
	}
	
	@Test
	void test14_control() {
		Integer new_r = -1;
		assertTrue(machine.evt_upload_restricted_record_owner.guard_upload_restricted_record_owner(u1, new_r), "Problem executing guard_upload_restricted_record_owner");
		machine.evt_upload_restricted_record_owner.run_upload_restricted_record_owner(u1, new_r);
		
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, new_r, sp1), "Problem executing guard_view_record_service_provider");
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, new_r, sp2), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test15_control() {
		assertTrue(machine.evt_delete_record_owner.guard_delete_record_owner(u1, r3), "Problem executing guard_delete_record_owner");
		machine.evt_delete_record_owner.run_delete_record_owner(u1, r3);
		assertFalse(machine.evt_delete_record_owner.guard_delete_record_owner(u1, r3), "Problem executing guard_delete_record_owner");
	}
	
	@Test
	void test16_control() {
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r4, sp1), "Problem executing guard_view_record_service_provider");
		assertTrue(machine.evt_restrict_record.guard_restrict_record(u1, r4), "Problem executing guard_restrict_record");
		machine.evt_restrict_record.run_restrict_record(u1, r4);
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r4, sp1), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test17_control() {
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r3, sp1), "Problem executing guard_view_record_service_provider");
		assertTrue(machine.evt_general_record.guard_general_record(u1, r3), "Problem executing guard_general_record");
		machine.evt_general_record.run_general_record(u1, r3);
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r3, sp1), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test18_control() {
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r3, sp2), "Problem executing guard_view_record_service_provider");
		assertTrue(machine.evt_hide_record.guard_hide_record(u1, r3), "Problem executing guard_hide_record");
		machine.evt_hide_record.run_hide_record(u1, r3);
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, r3, sp2), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test19_control() {
		Integer new_r = -1;
		assertTrue(machine.evt_upload_general_record_SP.guard_upload_general_record_SP(u1, new_r, sp1), "Problem executing guard_upload_general_record_SP");
		machine.evt_upload_general_record_SP.run_upload_general_record_SP(u1, new_r, sp1);
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, new_r, sp1), "Problem executing guard_view_record_service_provider");
		assertTrue(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, new_r, sp2), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test20_control() {
		Integer new_r = -1;
		assertFalse(machine.evt_upload_restricted_record_SP.guard_upload_restricted_record_SP(u1, new_r, sp1), "Problem executing guard_upload_restricted_record_SP");
	}
	
	@Test
	void test21_control() {
		Integer new_r = -1;
		assertTrue(machine.evt_upload_restricted_record_SP.guard_upload_restricted_record_SP(u1, new_r, sp2), "Problem executing guard_upload_restricted_record_SP");
		machine.evt_upload_restricted_record_SP.run_upload_restricted_record_SP(u1, new_r, sp2);
		assertTrue(machine.evt_view_record_owner.guard_view_record_owner(u1, new_r), "Problem executing guard_view_record_owner");
		assertFalse(machine.evt_view_record_service_provider.guard_view_record_service_provider(u1, new_r, sp1), "Problem executing guard_view_record_service_provider");
	}
	
	@Test
	void test22_control() {
		Integer new_r = -1;
		assertFalse(machine.evt_upload_restricted_record_SP.guard_upload_restricted_record_SP(u1, new_r, sp3), "Problem executing guard_upload_restricted_record_SP");
		assertFalse(machine.evt_upload_general_record_SP.guard_upload_general_record_SP(u1, new_r, sp3), "Problem executing guard_upload_general_record_SP");
	}
	
	@Test
	void test23_control() {
		assertFalse(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r3, nom2), "Problem executing guard_view_record_nominated");
		assertTrue(machine.evt_grant_restrict_access_to_general_nominated.guard_grant_restrict_access_to_general_nominated(u1, mhr1, nom2), "Problem executing guard_grant_restrict_access_to_general_nominated");
		machine.evt_grant_restrict_access_to_general_nominated.run_grant_restrict_access_to_general_nominated(u1, mhr1, nom2);
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r3, nom2), "Problem executing guard_view_record_nominated");
	}
	
	@Test
	void test24_control() {
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r3, nom3), "Problem executing guard_view_record_nominated");
		assertTrue(machine.evt_grant_general_access_to_nominated.guard_grant_general_access_to_nominated(u1, mhr1, nom3), "Problem executing guard_grant_general_access_to_nominated");
		machine.evt_grant_general_access_to_nominated.run_grant_general_access_to_nominated(u1, mhr1, nom3);
		assertFalse(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r3, nom3), "Problem executing guard_view_record_nominated");
	}
	
	@Test
	void test25_control() {
		Integer new_r = -1;
		assertTrue(machine.evt_upload_general_record_nominated.guard_upload_general_record_nominated(u1, new_r, nom3), "Problem executing guard_upload_general_record_nominated");
		machine.evt_upload_general_record_nominated.run_upload_general_record_nominated(u1, new_r, nom3);
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, new_r, nom2), "Problem executing guard_view_record_nominated");
	}
	
	@Test
	void test26_control() {
		Integer new_r = -1;
		assertTrue(machine.evt_upload_restricted_record_nominated.guard_upload_restricted_record_nominated(u1, new_r, nom3), "Problem executing guard_upload_restricted_record_nominated");
		machine.evt_upload_restricted_record_nominated.run_upload_restricted_record_nominated(u1, new_r, nom3);
		assertFalse(machine.evt_view_record_nominated.guard_view_record_nominated(u1, new_r, nom2), "Problem executing guard_view_record_nominated");
	}
	
	@Test
	void test27_control() {
		test25_control();
		Integer new_r2 = -2;
		assertTrue(machine.evt_grant_restrict_access_to_full_access_nominated.guard_grant_restrict_access_to_full_access_nominated(u1, mhr1, nom3), "Problem executing guard_grant_restrict_access_to_full_access_nominated");
		machine.evt_grant_restrict_access_to_full_access_nominated.run_grant_restrict_access_to_full_access_nominated(u1, mhr1, nom3);
		assertTrue(machine.evt_view_record_nominated.guard_view_record_nominated(u1, r3, nom3), "Problem executing guard_view_record_nominated");
		assertFalse(machine.evt_upload_general_record_nominated.guard_upload_general_record_nominated(u1, new_r2, nom3), "Problem executing guard_upload_general_record_nominated");
	}
	
	@Test
	void test28_control() {
		Integer new_r = -1;
		assertFalse(machine.evt_view_record_owner.guard_view_record_owner(u2, r5));
		assertFalse(machine.evt_view_record_owner.guard_view_record_owner(u2, r6));
		assertFalse(machine.evt_delete_record_owner.guard_delete_record_owner(u2, r5));
		assertFalse(machine.evt_delete_record_owner.guard_delete_record_owner(u2, r6));
		assertFalse(machine.evt_upload_general_record_owner.guard_upload_general_record_owner(u2, new_r));
		assertFalse(machine.evt_upload_restricted_record_owner.guard_upload_restricted_record_owner(u2, new_r));
		assertFalse(machine.evt_restrict_record.guard_restrict_record(u2, r5));
		assertFalse(machine.evt_general_record.guard_general_record(u2, r6));
		assertFalse(machine.evt_hide_record.guard_hide_record(u2, r5));
		assertFalse(machine.evt_revoke_access_sp.guard_revoke_access_sp(u2, mhr2, sp1));
		assertFalse(machine.evt_give_restricted_access_sp.guard_give_restricted_access_sp(u2, mhr2, sp3));
		assertFalse(machine.evt_give_general_access_sp.guard_give_general_access_sp(u2, mhr2, sp3));
		assertFalse(machine.evt_add_nominated.guard_add_nominated(u2, mhr2, nom1));
		assertFalse(machine.evt_grant_full_access_to_nominated.guard_grant_full_access_to_nominated(u2, mhr2, nom2));
	}
	
	@Test
	void test29_control() {
		Integer new_r = -1;
		assertTrue(machine.evt_view_record_authorised_rep.guard_view_record_authorised_rep(u2, r5, auth));
		assertTrue(machine.evt_view_record_authorised_rep.guard_view_record_authorised_rep(u2, r6, auth));
		assertTrue(machine.evt_delete_record_authorised_rep.guard_delete_record_authorised_rep(u2, r5, auth));
		assertTrue(machine.evt_delete_record_authorised_rep.guard_delete_record_authorised_rep(u2, r6, auth));
		assertTrue(machine.evt_upload_general_record_authorised_rep.guard_upload_general_record_authorised_rep(u2, new_r, auth));
		assertTrue(machine.evt_upload_restricted_record_authorised_rep.guard_upload_restricted_record_authorised_rep(u2, new_r, auth));
		assertTrue(machine.evt_restrict_record_authorised_rep.guard_restrict_record_authorised_rep(u2, r5, auth));
		assertTrue(machine.evt_general_record_authorised_rep.guard_general_record_authorised_rep(u2, r6, auth));
		assertTrue(machine.evt_hide_record_authorised_rep.guard_hide_record_authorised_rep(u2, r5, auth));
		assertTrue(machine.evt_revoke_access_sp_authorised_rep.guard_revoke_access_sp_authorised_rep(u2, mhr2, sp1, auth));
		assertTrue(machine.evt_give_restricted_access_sp_authorised_rep.guard_give_restricted_access_sp_authorised_rep(u2, mhr2, sp3, auth));
		assertTrue(machine.evt_give_general_access_sp_authorised_rep.guard_give_general_access_sp_authorised_rep(u2, mhr2, sp3, auth));
		assertTrue(machine.evt_add_nominated_authorised_rep.guard_add_nominated_authorised_rep(u2, mhr2, nom1, auth));
		assertTrue(machine.evt_grant_full_access_to_nominated_authorised_rep.guard_grant_full_access_to_nominated_authorised_rep(u2, mhr2, nom2, auth));
	}
	
}
