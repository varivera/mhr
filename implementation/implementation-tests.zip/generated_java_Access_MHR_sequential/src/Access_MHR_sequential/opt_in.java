package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class opt_in{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public opt_in(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.PEOPLE.has(c) && !machine.get_consumer().has(c) && machine.MY_HEALTH_RECORD.has(mhr) && !machine.get_my_health_record_DB().has(mhr) && machine.get_system_operator().has(so) && !machine.get_system_operator().has(c)); */
	public /*@ pure */ boolean guard_opt_in( Integer c, Integer mhr, Integer so) {
		return (machine.PEOPLE.has(c) && !machine.get_consumer().has(c) && machine.MY_HEALTH_RECORD.has(mhr) && !machine.get_my_health_record_DB().has(mhr) && machine.get_system_operator().has(so) && !machine.get_system_operator().has(c));
	}

	/*@ public normal_behavior
		requires guard_opt_in(c,mhr,so);
		assignable machine.consumer, machine.my_health_record_DB, machine.MyHR;
		ensures guard_opt_in(c,mhr,so) &&  machine.get_consumer().equals(\old((machine.get_consumer().union(new BSet<Integer>(c))))) &&  machine.get_my_health_record_DB().equals(\old((machine.get_my_health_record_DB().union(new BSet<Integer>(mhr))))) &&  machine.get_MyHR().equals(\old((machine.get_MyHR().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(c,mhr)))))); 
	 also
		requires !guard_opt_in(c,mhr,so);
		assignable \nothing;
		ensures true; */
	public void run_opt_in( Integer c, Integer mhr, Integer so){
		if(guard_opt_in(c,mhr,so)) {
			BSet<Integer> consumer_tmp = machine.get_consumer();
			BSet<Integer> my_health_record_DB_tmp = machine.get_my_health_record_DB();
			BRelation<Integer,Integer> MyHR_tmp = machine.get_MyHR();

			machine.set_consumer((consumer_tmp.union(new BSet<Integer>(c))));
			machine.set_my_health_record_DB((my_health_record_DB_tmp.union(new BSet<Integer>(mhr))));
			machine.set_MyHR((MyHR_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(c,mhr)))));

			System.out.println("opt_in executed c: " + c + " mhr: " + mhr + " so: " + so + " ");
		}
	}

}
