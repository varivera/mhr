package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class view_record_owner{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public view_record_owner(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)) && !machine.get_hidden_records().has(r) && !machine.get_authorised_rep().range().has(machine.get_records_mhr().apply(r))); */
	public /*@ pure */ boolean guard_view_record_owner( Integer c, Integer r) {
		return (machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)) && !machine.get_hidden_records().has(r) && !machine.get_authorised_rep().range().has(machine.get_records_mhr().apply(r)));
	}

	/*@ public normal_behavior
		requires guard_view_record_owner(c,r);
		assignable \nothing;
		ensures guard_view_record_owner(c,r) && true; 
	 also
		requires !guard_view_record_owner(c,r);
		assignable \nothing;
		ensures true; */
	public void run_view_record_owner( Integer c, Integer r){
		if(guard_view_record_owner(c,r)) {


			System.out.println("view_record_owner executed c: " + c + " r: " + r + " ");
		}
	}

}
