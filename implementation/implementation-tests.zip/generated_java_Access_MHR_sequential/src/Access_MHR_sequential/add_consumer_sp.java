package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class add_consumer_sp{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public add_consumer_sp(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_consumer().has(c) && machine.get_service_providers().has(sp) && !machine.get_consumer_sp().has(new Pair<Integer,Integer>(c,sp)) && !machine.get_sp_MyHR_access().has(new Pair<Integer,Integer>(sp,machine.get_MyHR().apply(c))) && !machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c))); */
	public /*@ pure */ boolean guard_add_consumer_sp( Integer c, Integer sp) {
		return (machine.get_consumer().has(c) && machine.get_service_providers().has(sp) && !machine.get_consumer_sp().has(new Pair<Integer,Integer>(c,sp)) && !machine.get_sp_MyHR_access().has(new Pair<Integer,Integer>(sp,machine.get_MyHR().apply(c))) && !machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c)));
	}

	/*@ public normal_behavior
		requires guard_add_consumer_sp(c,sp);
		assignable machine.consumer_sp, machine.sp_MyHR_access, machine.general_sp_list, machine.general_sp_access, machine.restricted_sp_access;
		ensures guard_add_consumer_sp(c,sp) &&  machine.get_consumer_sp().equals(\old((machine.get_consumer_sp().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(c,sp)))))) &&  machine.get_sp_MyHR_access().equals(\old((machine.get_sp_MyHR_access().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,machine.get_MyHR().apply(c))))))) &&  machine.get_general_sp_list().equals(\old((machine.get_general_sp_list().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,machine.get_MyHR().apply(c))))))) &&  machine.get_general_sp_access().equals(\old((machine.get_general_sp_access().union(BRelation.cross(new BSet<Integer>(sp),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(c))).restrictDomainTo(machine.get_general_records()).domain()))))) &&  machine.get_restricted_sp_access().equals(\old((machine.get_restricted_sp_access().union(BRelation.cross(new BSet<Integer>(sp),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(c))).restrictDomainTo(machine.get_general_records()).domain()))))); 
	 also
		requires !guard_add_consumer_sp(c,sp);
		assignable \nothing;
		ensures true; */
	public void run_add_consumer_sp( Integer c, Integer sp){
		if(guard_add_consumer_sp(c,sp)) {
			BRelation<Integer,Integer> consumer_sp_tmp = machine.get_consumer_sp();
			BRelation<Integer,Integer> sp_MyHR_access_tmp = machine.get_sp_MyHR_access();
			BRelation<Integer,Integer> general_sp_list_tmp = machine.get_general_sp_list();
			BRelation<Integer,Integer> general_sp_access_tmp = machine.get_general_sp_access();
			BRelation<Integer,Integer> restricted_sp_access_tmp = machine.get_restricted_sp_access();

			machine.set_consumer_sp((consumer_sp_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(c,sp)))));
			machine.set_sp_MyHR_access((sp_MyHR_access_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,machine.get_MyHR().apply(c))))));
			machine.set_general_sp_list((general_sp_list_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,machine.get_MyHR().apply(c))))));
			machine.set_general_sp_access((general_sp_access_tmp.union(BRelation.cross(new BSet<Integer>(sp),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(c))).restrictDomainTo(machine.get_general_records()).domain()))));
			machine.set_restricted_sp_access((restricted_sp_access_tmp.union(BRelation.cross(new BSet<Integer>(sp),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(c))).restrictDomainTo(machine.get_general_records()).domain()))));

			System.out.println("add_consumer_sp executed c: " + c + " sp: " + sp + " ");
		}
	}

}
