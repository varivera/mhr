package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class add_authorised{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public add_authorised(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_consumer().has(a) && machine.get_MyHR().range().has(mhr) && !machine.get_MyHR().apply(a).equals(mhr) && !machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,mhr)) && machine.get_system_operator().has(so)); */
	public /*@ pure */ boolean guard_add_authorised( Integer a, Integer mhr, Integer so) {
		return (machine.get_consumer().has(a) && machine.get_MyHR().range().has(mhr) && !machine.get_MyHR().apply(a).equals(mhr) && !machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,mhr)) && machine.get_system_operator().has(so));
	}

	/*@ public normal_behavior
		requires guard_add_authorised(a,mhr,so);
		assignable machine.authorised_rep;
		ensures guard_add_authorised(a,mhr,so) &&  machine.get_authorised_rep().equals(\old((machine.get_authorised_rep().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(a,mhr)))))); 
	 also
		requires !guard_add_authorised(a,mhr,so);
		assignable \nothing;
		ensures true; */
	public void run_add_authorised( Integer a, Integer mhr, Integer so){
		if(guard_add_authorised(a,mhr,so)) {
			BRelation<Integer,Integer> authorised_rep_tmp = machine.get_authorised_rep();

			machine.set_authorised_rep((authorised_rep_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(a,mhr)))));

			System.out.println("add_authorised executed a: " + a + " mhr: " + mhr + " so: " + so + " ");
		}
	}

}
