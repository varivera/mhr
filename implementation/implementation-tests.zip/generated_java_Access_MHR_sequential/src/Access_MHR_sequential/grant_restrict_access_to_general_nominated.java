package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class grant_restrict_access_to_general_nominated{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public grant_restrict_access_to_general_nominated(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (new BSet<Integer>(c,n).isSubset(machine.get_consumer()) && !c.equals(n) && machine.get_MyHR().has(new Pair<Integer,Integer>(c,mhr)) && machine.get_general_nominated().has(new Pair<Integer,Integer>(n,mhr)) && !machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c))); */
	public /*@ pure */ boolean guard_grant_restrict_access_to_general_nominated( Integer c, Integer mhr, Integer n) {
		/*System.out.println(new BSet<Integer>(c,n).isSubset(machine.get_consumer()));
		System.out.println(!c.equals(n));
		System.out.println(machine.get_MyHR().has(new Pair<Integer,Integer>(c,mhr)));
		System.out.println(machine.get_general_nominated().has(new Pair<Integer,Integer>(n,mhr)));
		System.out.println(!machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c)));*/
		return (new BSet<Integer>(c,n).isSubset(machine.get_consumer()) && !c.equals(n) && machine.get_MyHR().has(new Pair<Integer,Integer>(c,mhr)) && machine.get_general_nominated().has(new Pair<Integer,Integer>(n,mhr)) && !machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c)));
	}

	/*@ public normal_behavior
		requires guard_grant_restrict_access_to_general_nominated(c,mhr,n);
		assignable machine.restricted_nominated, machine.general_nominated, machine.restricted_nominated_access, machine.general_nominated_access;
		ensures guard_grant_restrict_access_to_general_nominated(c,mhr,n) &&  machine.get_restricted_nominated().equals(\old((machine.get_restricted_nominated().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr)))))) &&  machine.get_general_nominated().equals(\old(machine.get_general_nominated().difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr))))) &&  machine.get_restricted_nominated_access().equals(\old((machine.get_restricted_nominated_access().union(BRelation.cross(new BSet<Integer>(n),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(mhr)).restrictDomainTo(machine.get_restricted_records()).domain()))))) &&  machine.get_general_nominated_access().equals(\old(machine.get_general_nominated_access().difference(BRelation.cross(new BSet<Integer>(n),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(mhr)).restrictDomainTo(machine.get_general_records()).domain())))); 
	 also
		requires !guard_grant_restrict_access_to_general_nominated(c,mhr,n);
		assignable \nothing;
		ensures true; */
	public void run_grant_restrict_access_to_general_nominated( Integer c, Integer mhr, Integer n){
		if(guard_grant_restrict_access_to_general_nominated(c,mhr,n)) {
			BRelation<Integer,Integer> restricted_nominated_tmp = machine.get_restricted_nominated();
			BRelation<Integer,Integer> general_nominated_tmp = machine.get_general_nominated();
			BRelation<Integer,Integer> restricted_nominated_access_tmp = machine.get_restricted_nominated_access();
			BRelation<Integer,Integer> general_nominated_access_tmp = machine.get_general_nominated_access();

			machine.set_restricted_nominated((restricted_nominated_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr)))));
			machine.set_general_nominated(general_nominated_tmp.difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr))));
			machine.set_restricted_nominated_access((restricted_nominated_access_tmp.union(BRelation.cross(new BSet<Integer>(n),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(mhr)).restrictDomainTo(machine.get_restricted_records()).domain()))));
			machine.set_general_nominated_access(general_nominated_access_tmp.difference(BRelation.cross(new BSet<Integer>(n),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(mhr)).restrictDomainTo(machine.get_general_records()).domain())));

			System.out.println("grant_restrict_access_to_general_nominated executed c: " + c + " mhr: " + mhr + " n: " + n + " ");
		}
	}

}
