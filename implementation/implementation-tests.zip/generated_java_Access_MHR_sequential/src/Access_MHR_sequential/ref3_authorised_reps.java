package Access_MHR_sequential;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ref3_authorised_reps{
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;

	public add_consumer_sp_authorised_rep evt_add_consumer_sp_authorised_rep = new add_consumer_sp_authorised_rep(this);
	public upload_general_record_nominated evt_upload_general_record_nominated = new upload_general_record_nominated(this);
	public upload_restricted_record_authorised_rep evt_upload_restricted_record_authorised_rep = new upload_restricted_record_authorised_rep(this);
	public upload_general_record_SP evt_upload_general_record_SP = new upload_general_record_SP(this);
	public opt_out evt_opt_out = new opt_out(this);
	public grant_restrict_access_to_full_access_nominated_authorised_rep evt_grant_restrict_access_to_full_access_nominated_authorised_rep = new grant_restrict_access_to_full_access_nominated_authorised_rep(this);
	public restrict_record evt_restrict_record = new restrict_record(this);
	public add_sp evt_add_sp = new add_sp(this);
	public view_record_service_provider evt_view_record_service_provider = new view_record_service_provider(this);
	public give_restricted_access_sp_authorised_rep evt_give_restricted_access_sp_authorised_rep = new give_restricted_access_sp_authorised_rep(this);
	public add_nominated_authorised_rep evt_add_nominated_authorised_rep = new add_nominated_authorised_rep(this);
	public give_restricted_access_sp evt_give_restricted_access_sp = new give_restricted_access_sp(this);
	public revoke_access_sp_authorised_rep evt_revoke_access_sp_authorised_rep = new revoke_access_sp_authorised_rep(this);
	public give_general_access_sp evt_give_general_access_sp = new give_general_access_sp(this);
	public view_record_nominated evt_view_record_nominated = new view_record_nominated(this);
	public give_general_access_sp_authorised_rep evt_give_general_access_sp_authorised_rep = new give_general_access_sp_authorised_rep(this);
	public unhide_record_authorised_rep evt_unhide_record_authorised_rep = new unhide_record_authorised_rep(this);
	public grant_restrict_access_to_general_nominated_authorised_rep evt_grant_restrict_access_to_general_nominated_authorised_rep = new grant_restrict_access_to_general_nominated_authorised_rep(this);
	public general_record evt_general_record = new general_record(this);
	public add_consumer_sp evt_add_consumer_sp = new add_consumer_sp(this);
	public upload_general_record_owner evt_upload_general_record_owner = new upload_general_record_owner(this);
	public hide_record_authorised_rep evt_hide_record_authorised_rep = new hide_record_authorised_rep(this);
	public grant_full_access_to_nominated_authorised_rep evt_grant_full_access_to_nominated_authorised_rep = new grant_full_access_to_nominated_authorised_rep(this);
	public upload_restricted_record_SP evt_upload_restricted_record_SP = new upload_restricted_record_SP(this);
	public revoke_access_sp evt_revoke_access_sp = new revoke_access_sp(this);
	public grant_restrict_access_to_general_nominated evt_grant_restrict_access_to_general_nominated = new grant_restrict_access_to_general_nominated(this);
	public grant_restrict_access_to_full_access_nominated evt_grant_restrict_access_to_full_access_nominated = new grant_restrict_access_to_full_access_nominated(this);
	public view_record_authorised_rep evt_view_record_authorised_rep = new view_record_authorised_rep(this);
	public view_record_owner evt_view_record_owner = new view_record_owner(this);
	public upload_restricted_record_owner evt_upload_restricted_record_owner = new upload_restricted_record_owner(this);
	public delete_general_nominated_authorised_rep evt_delete_general_nominated_authorised_rep = new delete_general_nominated_authorised_rep(this);
	public restrict_record_authorised_rep evt_restrict_record_authorised_rep = new restrict_record_authorised_rep(this);
	public delete_record_authorised_rep evt_delete_record_authorised_rep = new delete_record_authorised_rep(this);
	public upload_general_record_authorised_rep evt_upload_general_record_authorised_rep = new upload_general_record_authorised_rep(this);
	public upload_restricted_record_nominated evt_upload_restricted_record_nominated = new upload_restricted_record_nominated(this);
	public delete_authorised evt_delete_authorised = new delete_authorised(this);
	public unhide_record evt_unhide_record = new unhide_record(this);
	public grant_general_access_to_nominated evt_grant_general_access_to_nominated = new grant_general_access_to_nominated(this);
	public delete_record_owner evt_delete_record_owner = new delete_record_owner(this);
	public delete_general_nominated evt_delete_general_nominated = new delete_general_nominated(this);
	public add_authorised evt_add_authorised = new add_authorised(this);
	public grant_general_access_to_nominated_authorised_rep evt_grant_general_access_to_nominated_authorised_rep = new grant_general_access_to_nominated_authorised_rep(this);
	public general_record_authorised_rep evt_general_record_authorised_rep = new general_record_authorised_rep(this);
	public opt_in evt_opt_in = new opt_in(this);
	public hide_record evt_hide_record = new hide_record(this);
	public add_nominated evt_add_nominated = new add_nominated(this);
	public grant_full_access_to_nominated evt_grant_full_access_to_nominated = new grant_full_access_to_nominated(this);


	/******Set definitions******/
	//@ public static constraint MY_HEALTH_RECORD.equals(\old(MY_HEALTH_RECORD)); 
	public static final BSet<Integer> MY_HEALTH_RECORD = new Enumerated(min_integer,max_integer);

	//@ public static constraint PEOPLE.equals(\old(PEOPLE)); 
	public static final BSet<Integer> PEOPLE = new Enumerated(min_integer,max_integer);

	//@ public static constraint RESOURCES.equals(\old(RESOURCES)); 
	public static final BSet<Integer> RESOURCES = new Enumerated(min_integer,max_integer);

	//@ public static constraint SERVICE_PROVIDERS.equals(\old(SERVICE_PROVIDERS)); 
	public static final BSet<Integer> SERVICE_PROVIDERS = new Enumerated(min_integer,max_integer);


	/******Constant definitions******/


	/******Axiom definitions******/
	/*@ public static invariant MY_HEALTH_RECORD.finite(); */
	/*@ public static invariant PEOPLE.finite(); */
	/*@ public static invariant RESOURCES.finite(); */
	/*@ public static invariant new Integer(MY_HEALTH_RECORD.size()).equals(new Integer(4)); */
	/*@ public static invariant new Integer(PEOPLE.size()).equals(new Integer(5)); */
	/*@ public static invariant new Integer(RESOURCES.size()).equals(new Integer(6)); */
	/*@ public static invariant SERVICE_PROVIDERS.finite(); */
	/*@ public static invariant new Integer(SERVICE_PROVIDERS.size()).equals(new Integer(2)); */


	/******Variable definitions******/
	/*@ spec_public */ private BRelation<Integer,Integer> MyHR;

	/*@ spec_public */ private BRelation<Integer,Integer> authorised_rep;

	/*@ spec_public */ private BSet<Integer> consumer;

	/*@ spec_public */ private BRelation<Integer,Integer> consumer_sp;

	/*@ spec_public */ private BRelation<Integer,Integer> full_access_nominated;

	/*@ spec_public */ private BRelation<Integer,Integer> general_nominated;

	/*@ spec_public */ private BRelation<Integer,Integer> general_nominated_access;

	/*@ spec_public */ private BSet<Integer> general_records;

	/*@ spec_public */ private BRelation<Integer,Integer> general_sp_access;

	/*@ spec_public */ private BRelation<Integer,Integer> general_sp_list;

	/*@ spec_public */ private BSet<Integer> hidden_records;

	/*@ spec_public */ private BSet<Integer> my_health_record_DB;

	/*@ spec_public */ private BSet<Integer> records;

	/*@ spec_public */ private BRelation<Integer,Integer> records_mhr;

	/*@ spec_public */ private BRelation<Integer,Integer> records_ownership;

	/*@ spec_public */ private BRelation<Integer,Integer> restricted_nominated;

	/*@ spec_public */ private BRelation<Integer,Integer> restricted_nominated_access;

	/*@ spec_public */ private BSet<Integer> restricted_records;

	/*@ spec_public */ private BRelation<Integer,Integer> restricted_sp_access;

	/*@ spec_public */ private BRelation<Integer,Integer> restricted_sp_list;

	/*@ spec_public */ private BRelation<Integer,Integer> revoked_sp_list;

	/*@ spec_public */ private BSet<Integer> service_providers;

	/*@ spec_public */ private BRelation<Integer,Integer> sp_MyHR_access;

	/*@ spec_public */ private BSet<Integer> system_operator;




	/******Invariant definition******/
	/*@ public invariant
		my_health_record_DB.isSubset(MY_HEALTH_RECORD) &&
		consumer.isSubset(PEOPLE) &&
		 MyHR.domain().equals(consumer) && MyHR.range().equals(my_health_record_DB) && MyHR.isaFunction() && MyHR.inverse().isaFunction() && BRelation.cross(consumer,my_health_record_DB).has(MyHR) &&
		system_operator.isSubset(PEOPLE.difference(consumer)) &&
		records.isSubset(RESOURCES) &&
		 records_mhr.domain().equals(records) && records_mhr.range().isSubset(my_health_record_DB) && records_mhr.isaFunction() && BRelation.cross(records,my_health_record_DB).has(records_mhr) &&
		general_records.isSubset(records) &&
		restricted_records.isSubset(records) &&
		hidden_records.isSubset(records) &&
		BSet.partition(records,general_records,restricted_records,hidden_records) &&
		 records_ownership.domain().equals(records) && records_ownership.range().isSubset(consumer) && records_ownership.isaFunction() && BRelation.cross(records,consumer).has(records_ownership) &&
		records_ownership.equals((records_mhr.compose(MyHR.inverse()))) &&
		service_providers.isSubset(SERVICE_PROVIDERS) &&
		 consumer_sp.domain().isSubset(consumer) && consumer_sp.range().isSubset(service_providers) && BRelation.cross(consumer,service_providers).has(consumer_sp) &&
		 sp_MyHR_access.domain().isSubset(service_providers) && sp_MyHR_access.range().isSubset(my_health_record_DB) && BRelation.cross(service_providers,my_health_record_DB).has(sp_MyHR_access) &&
		sp_MyHR_access.equals((consumer_sp.inverse().compose(MyHR))) &&
		 general_sp_list.domain().isSubset(service_providers) && general_sp_list.range().isSubset(my_health_record_DB) && BRelation.cross(service_providers,my_health_record_DB).has(general_sp_list) &&
		 restricted_sp_list.domain().isSubset(service_providers) && restricted_sp_list.range().isSubset(my_health_record_DB) && BRelation.cross(service_providers,my_health_record_DB).has(restricted_sp_list) &&
		 revoked_sp_list.domain().isSubset(service_providers) && revoked_sp_list.range().isSubset(my_health_record_DB) && BRelation.cross(service_providers,my_health_record_DB).has(revoked_sp_list) &&
		BSet.partition(sp_MyHR_access,general_sp_list,restricted_sp_list,revoked_sp_list) &&
		 general_sp_access.domain().isSubset(service_providers) && general_sp_access.range().isSubset(records) && BRelation.cross(service_providers,records).has(general_sp_access) &&
		general_sp_access.domain().isSubset(general_sp_list.domain()) &&
		general_sp_access.range().isSubset(general_records) &&
		 restricted_sp_access.domain().isSubset(service_providers) && restricted_sp_access.range().isSubset(records) && BRelation.cross(service_providers,records).has(restricted_sp_access) &&
		restricted_sp_access.domain().isSubset((general_sp_list.union(restricted_sp_list)).domain()) &&
		restricted_sp_access.range().isSubset((general_records.union(restricted_records))) &&
		general_sp_access.equals((general_sp_list.compose(records_mhr.restrictDomainTo(general_records).inverse()))) &&
		restricted_sp_access.equals(((restricted_sp_list.compose(records_mhr.restrictDomainTo((general_records.union(restricted_records))).inverse())).union((general_sp_list.compose(records_mhr.restrictDomainTo(general_records).inverse()))))) &&
		general_sp_access.isSubset(restricted_sp_access) &&
		 general_nominated.domain().isSubset(consumer) && general_nominated.range().isSubset(my_health_record_DB) && BRelation.cross(consumer,my_health_record_DB).has(general_nominated) &&
		 restricted_nominated.domain().isSubset(consumer) && restricted_nominated.range().isSubset(my_health_record_DB) && BRelation.cross(consumer,my_health_record_DB).has(restricted_nominated) &&
		 full_access_nominated.domain().isSubset(consumer) && full_access_nominated.range().isSubset(my_health_record_DB) && BRelation.cross(consumer,my_health_record_DB).has(full_access_nominated) &&
		(general_nominated.intersection(restricted_nominated)).equals(BSet.EMPTY) &&
		full_access_nominated.isSubset(restricted_nominated) &&
		((general_nominated.union(restricted_nominated)).intersection(MyHR)).equals(BSet.EMPTY) &&
		 restricted_nominated_access.domain().isSubset(consumer) && restricted_nominated_access.range().isSubset(records) && BRelation.cross(consumer,records).has(restricted_nominated_access) &&
		restricted_nominated_access.domain().isSubset((general_nominated.union(restricted_nominated)).domain()) &&
		restricted_nominated_access.range().isSubset((general_records.union(restricted_records))) &&
		 general_nominated_access.domain().isSubset(consumer) && general_nominated_access.range().isSubset(records) && BRelation.cross(consumer,records).has(general_nominated_access) &&
		general_nominated_access.domain().isSubset(general_nominated.domain()) &&
		general_nominated_access.range().isSubset(general_records) &&
		general_nominated_access.isSubset(restricted_nominated_access) &&
		restricted_nominated_access.equals(((restricted_nominated.compose(records_mhr.restrictDomainTo((general_records.union(restricted_records))).inverse())).union((general_nominated.compose(records_mhr.restrictDomainTo(general_records).inverse()))))) &&
		general_nominated_access.equals((general_nominated.compose(records_mhr.restrictDomainTo(general_records).inverse()))) &&
		 authorised_rep.domain().isSubset(consumer) && authorised_rep.range().isSubset(my_health_record_DB) && BRelation.cross(consumer,my_health_record_DB).has(authorised_rep) &&
		(MyHR.intersection(authorised_rep)).equals(BSet.EMPTY); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.general_nominated;*/
	public /*@ pure */ BRelation<Integer,Integer> get_general_nominated(){
		return this.general_nominated;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.general_nominated;
	    ensures this.general_nominated == general_nominated;*/
	public void set_general_nominated(BRelation<Integer,Integer> general_nominated){
		this.general_nominated = general_nominated;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.authorised_rep;*/
	public /*@ pure */ BRelation<Integer,Integer> get_authorised_rep(){
		return this.authorised_rep;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.authorised_rep;
	    ensures this.authorised_rep == authorised_rep;*/
	public void set_authorised_rep(BRelation<Integer,Integer> authorised_rep){
		this.authorised_rep = authorised_rep;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.full_access_nominated;*/
	public /*@ pure */ BRelation<Integer,Integer> get_full_access_nominated(){
		return this.full_access_nominated;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.full_access_nominated;
	    ensures this.full_access_nominated == full_access_nominated;*/
	public void set_full_access_nominated(BRelation<Integer,Integer> full_access_nominated){
		this.full_access_nominated = full_access_nominated;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.general_sp_access;*/
	public /*@ pure */ BRelation<Integer,Integer> get_general_sp_access(){
		return this.general_sp_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.general_sp_access;
	    ensures this.general_sp_access == general_sp_access;*/
	public void set_general_sp_access(BRelation<Integer,Integer> general_sp_access){
		this.general_sp_access = general_sp_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.records;*/
	public /*@ pure */ BSet<Integer> get_records(){
		return this.records;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.records;
	    ensures this.records == records;*/
	public void set_records(BSet<Integer> records){
		this.records = records;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.general_records;*/
	public /*@ pure */ BSet<Integer> get_general_records(){
		return this.general_records;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.general_records;
	    ensures this.general_records == general_records;*/
	public void set_general_records(BSet<Integer> general_records){
		this.general_records = general_records;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.hidden_records;*/
	public /*@ pure */ BSet<Integer> get_hidden_records(){
		return this.hidden_records;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.hidden_records;
	    ensures this.hidden_records == hidden_records;*/
	public void set_hidden_records(BSet<Integer> hidden_records){
		this.hidden_records = hidden_records;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.restricted_sp_access;*/
	public /*@ pure */ BRelation<Integer,Integer> get_restricted_sp_access(){
		return this.restricted_sp_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.restricted_sp_access;
	    ensures this.restricted_sp_access == restricted_sp_access;*/
	public void set_restricted_sp_access(BRelation<Integer,Integer> restricted_sp_access){
		this.restricted_sp_access = restricted_sp_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.revoked_sp_list;*/
	public /*@ pure */ BRelation<Integer,Integer> get_revoked_sp_list(){
		return this.revoked_sp_list;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.revoked_sp_list;
	    ensures this.revoked_sp_list == revoked_sp_list;*/
	public void set_revoked_sp_list(BRelation<Integer,Integer> revoked_sp_list){
		this.revoked_sp_list = revoked_sp_list;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.service_providers;*/
	public /*@ pure */ BSet<Integer> get_service_providers(){
		return this.service_providers;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.service_providers;
	    ensures this.service_providers == service_providers;*/
	public void set_service_providers(BSet<Integer> service_providers){
		this.service_providers = service_providers;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.records_mhr;*/
	public /*@ pure */ BRelation<Integer,Integer> get_records_mhr(){
		return this.records_mhr;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.records_mhr;
	    ensures this.records_mhr == records_mhr;*/
	public void set_records_mhr(BRelation<Integer,Integer> records_mhr){
		this.records_mhr = records_mhr;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.my_health_record_DB;*/
	public /*@ pure */ BSet<Integer> get_my_health_record_DB(){
		return this.my_health_record_DB;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.my_health_record_DB;
	    ensures this.my_health_record_DB == my_health_record_DB;*/
	public void set_my_health_record_DB(BSet<Integer> my_health_record_DB){
		this.my_health_record_DB = my_health_record_DB;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.restricted_records;*/
	public /*@ pure */ BSet<Integer> get_restricted_records(){
		return this.restricted_records;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.restricted_records;
	    ensures this.restricted_records == restricted_records;*/
	public void set_restricted_records(BSet<Integer> restricted_records){
		this.restricted_records = restricted_records;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.MyHR;*/
	public /*@ pure */ BRelation<Integer,Integer> get_MyHR(){
		return this.MyHR;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.MyHR;
	    ensures this.MyHR == MyHR;*/
	public void set_MyHR(BRelation<Integer,Integer> MyHR){
		this.MyHR = MyHR;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.restricted_nominated_access;*/
	public /*@ pure */ BRelation<Integer,Integer> get_restricted_nominated_access(){
		return this.restricted_nominated_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.restricted_nominated_access;
	    ensures this.restricted_nominated_access == restricted_nominated_access;*/
	public void set_restricted_nominated_access(BRelation<Integer,Integer> restricted_nominated_access){
		this.restricted_nominated_access = restricted_nominated_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.consumer_sp;*/
	public /*@ pure */ BRelation<Integer,Integer> get_consumer_sp(){
		return this.consumer_sp;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.consumer_sp;
	    ensures this.consumer_sp == consumer_sp;*/
	public void set_consumer_sp(BRelation<Integer,Integer> consumer_sp){
		this.consumer_sp = consumer_sp;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.general_nominated_access;*/
	public /*@ pure */ BRelation<Integer,Integer> get_general_nominated_access(){
		return this.general_nominated_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.general_nominated_access;
	    ensures this.general_nominated_access == general_nominated_access;*/
	public void set_general_nominated_access(BRelation<Integer,Integer> general_nominated_access){
		this.general_nominated_access = general_nominated_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.sp_MyHR_access;*/
	public /*@ pure */ BRelation<Integer,Integer> get_sp_MyHR_access(){
		return this.sp_MyHR_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.sp_MyHR_access;
	    ensures this.sp_MyHR_access == sp_MyHR_access;*/
	public void set_sp_MyHR_access(BRelation<Integer,Integer> sp_MyHR_access){
		this.sp_MyHR_access = sp_MyHR_access;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.restricted_nominated;*/
	public /*@ pure */ BRelation<Integer,Integer> get_restricted_nominated(){
		return this.restricted_nominated;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.restricted_nominated;
	    ensures this.restricted_nominated == restricted_nominated;*/
	public void set_restricted_nominated(BRelation<Integer,Integer> restricted_nominated){
		this.restricted_nominated = restricted_nominated;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.general_sp_list;*/
	public /*@ pure */ BRelation<Integer,Integer> get_general_sp_list(){
		return this.general_sp_list;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.general_sp_list;
	    ensures this.general_sp_list == general_sp_list;*/
	public void set_general_sp_list(BRelation<Integer,Integer> general_sp_list){
		this.general_sp_list = general_sp_list;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.records_ownership;*/
	public /*@ pure */ BRelation<Integer,Integer> get_records_ownership(){
		return this.records_ownership;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.records_ownership;
	    ensures this.records_ownership == records_ownership;*/
	public void set_records_ownership(BRelation<Integer,Integer> records_ownership){
		this.records_ownership = records_ownership;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.system_operator;*/
	public /*@ pure */ BSet<Integer> get_system_operator(){
		return this.system_operator;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.system_operator;
	    ensures this.system_operator == system_operator;*/
	public void set_system_operator(BSet<Integer> system_operator){
		this.system_operator = system_operator;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.restricted_sp_list;*/
	public /*@ pure */ BRelation<Integer,Integer> get_restricted_sp_list(){
		return this.restricted_sp_list;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.restricted_sp_list;
	    ensures this.restricted_sp_list == restricted_sp_list;*/
	public void set_restricted_sp_list(BRelation<Integer,Integer> restricted_sp_list){
		this.restricted_sp_list = restricted_sp_list;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.consumer;*/
	public /*@ pure */ BSet<Integer> get_consumer(){
		return this.consumer;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.consumer;
	    ensures this.consumer == consumer;*/
	public void set_consumer(BSet<Integer> consumer){
		this.consumer = consumer;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		my_health_record_DB.isEmpty() &&
		consumer.isEmpty() &&
		MyHR.isEmpty() &&
		(\exists BSet<Integer> system_operator_localVar; PEOPLE.has(system_operator_localVar); system_operator.equals(system_operator_localVar)) &&
		records.isEmpty() &&
		records_mhr.isEmpty() &&
		general_records.isEmpty() &&
		restricted_records.isEmpty() &&
		hidden_records.isEmpty() &&
		records_ownership.isEmpty() &&
		service_providers.isEmpty() &&
		consumer_sp.isEmpty() &&
		sp_MyHR_access.isEmpty() &&
		general_sp_list.isEmpty() &&
		restricted_sp_list.isEmpty() &&
		revoked_sp_list.isEmpty() &&
		general_sp_access.isEmpty() &&
		restricted_sp_access.isEmpty() &&
		general_nominated.isEmpty() &&
		restricted_nominated.isEmpty() &&
		full_access_nominated.isEmpty() &&
		general_nominated_access.isEmpty() &&
		restricted_nominated_access.isEmpty() &&
		authorised_rep.isEmpty();*/
	public ref3_authorised_reps(){
		my_health_record_DB = new BSet<Integer>();
		consumer = new BSet<Integer>();
		MyHR = new BRelation<Integer,Integer>();
		system_operator = new BSet<Integer>();
		records = new BSet<Integer>();
		records_mhr = new BRelation<Integer,Integer>();
		general_records = new BSet<Integer>();
		restricted_records = new BSet<Integer>();
		hidden_records = new BSet<Integer>();
		records_ownership = new BRelation<Integer,Integer>();
		service_providers = new BSet<Integer>();
		consumer_sp = new BRelation<Integer,Integer>();
		sp_MyHR_access = new BRelation<Integer,Integer>();
		general_sp_list = new BRelation<Integer,Integer>();
		restricted_sp_list = new BRelation<Integer,Integer>();
		revoked_sp_list = new BRelation<Integer,Integer>();
		general_sp_access = new BRelation<Integer,Integer>();
		restricted_sp_access = new BRelation<Integer,Integer>();
		general_nominated = new BRelation<Integer,Integer>();
		restricted_nominated = new BRelation<Integer,Integer>();
		full_access_nominated = new BRelation<Integer,Integer>();
		general_nominated_access = new BRelation<Integer,Integer>();
		restricted_nominated_access = new BRelation<Integer,Integer>();
		authorised_rep = new BRelation<Integer,Integer>();
	}
}