package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class upload_general_record_authorised_rep{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public upload_general_record_authorised_rep(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_consumer().has(ow) && machine.RESOURCES.difference(machine.get_records()).has(r) && machine.get_consumer().has(a) && machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,machine.get_MyHR().apply(ow)))); */
	public /*@ pure */ boolean guard_upload_general_record_authorised_rep( Integer ow, Integer r, Integer a) {
		return (machine.get_consumer().has(ow) && machine.RESOURCES.difference(machine.get_records()).has(r) && machine.get_consumer().has(a) && machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,machine.get_MyHR().apply(ow))));
	}

	/*@ public normal_behavior
		requires guard_upload_general_record_authorised_rep(ow,r,a);
		assignable machine.records, machine.general_records, machine.records_mhr, machine.records_ownership, machine.general_sp_access, machine.restricted_sp_access, machine.general_nominated_access, machine.restricted_nominated_access;
		ensures guard_upload_general_record_authorised_rep(ow,r,a) &&  machine.get_records().equals(\old((machine.get_records().union(new BSet<Integer>(r))))) &&  machine.get_general_records().equals(\old((machine.get_general_records().union(new BSet<Integer>(r))))) &&  machine.get_records_mhr().equals(\old((machine.get_records_mhr().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(r,machine.get_MyHR().apply(ow))))))) &&  machine.get_records_ownership().equals(\old((machine.get_records_ownership().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(r,ow)))))) &&  machine.get_general_sp_access().equals(\old((machine.get_general_sp_access().union(BRelation.cross(machine.get_general_sp_list().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))))) &&  machine.get_restricted_sp_access().equals(\old((machine.get_restricted_sp_access().union(BRelation.cross((machine.get_general_sp_list().union(machine.get_restricted_sp_list())).restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))))) &&  machine.get_general_nominated_access().equals(\old((machine.get_general_nominated_access().union(BRelation.cross(machine.get_general_nominated().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))))) &&  machine.get_restricted_nominated_access().equals(\old(((machine.get_restricted_nominated_access().union(BRelation.cross(machine.get_general_nominated().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))).union(BRelation.cross(machine.get_restricted_nominated().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))))); 
	 also
		requires !guard_upload_general_record_authorised_rep(ow,r,a);
		assignable \nothing;
		ensures true; */
	public void run_upload_general_record_authorised_rep( Integer ow, Integer r, Integer a){
		if(guard_upload_general_record_authorised_rep(ow,r,a)) {
			BSet<Integer> records_tmp = machine.get_records();
			BSet<Integer> general_records_tmp = machine.get_general_records();
			BRelation<Integer,Integer> records_mhr_tmp = machine.get_records_mhr();
			BRelation<Integer,Integer> records_ownership_tmp = machine.get_records_ownership();
			BRelation<Integer,Integer> general_sp_access_tmp = machine.get_general_sp_access();
			BRelation<Integer,Integer> restricted_sp_access_tmp = machine.get_restricted_sp_access();
			BRelation<Integer,Integer> general_nominated_access_tmp = machine.get_general_nominated_access();
			BRelation<Integer,Integer> restricted_nominated_access_tmp = machine.get_restricted_nominated_access();

			machine.set_records((records_tmp.union(new BSet<Integer>(r))));
			machine.set_general_records((general_records_tmp.union(new BSet<Integer>(r))));
			machine.set_records_mhr((records_mhr_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(r,machine.get_MyHR().apply(ow))))));
			machine.set_records_ownership((records_ownership_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(r,ow)))));
			machine.set_general_sp_access((general_sp_access_tmp.union(BRelation.cross(machine.get_general_sp_list().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))));
			machine.set_restricted_sp_access((restricted_sp_access_tmp.union(BRelation.cross((machine.get_general_sp_list().union(machine.get_restricted_sp_list())).restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))));
			machine.set_general_nominated_access((general_nominated_access_tmp.union(BRelation.cross(machine.get_general_nominated().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))));
			machine.set_restricted_nominated_access(((restricted_nominated_access_tmp.union(BRelation.cross(machine.get_general_nominated().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))).union(BRelation.cross(machine.get_restricted_nominated().restrictRangeTo(new BSet<Integer>(machine.get_MyHR().apply(ow))).domain(),new BSet<Integer>(r)))));

			System.out.println("upload_general_record_authorised_rep executed ow: " + ow + " r: " + r + " a: " + a + " ");
		}
	}

}
