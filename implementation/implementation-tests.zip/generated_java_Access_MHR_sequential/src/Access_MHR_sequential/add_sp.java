package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class add_sp{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public add_sp(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.SERVICE_PROVIDERS.difference(machine.get_service_providers()).has(sp) && machine.get_system_operator().has(so)); */
	public /*@ pure */ boolean guard_add_sp( Integer so, Integer sp) {
		return (machine.SERVICE_PROVIDERS.difference(machine.get_service_providers()).has(sp) && machine.get_system_operator().has(so));
	}

	/*@ public normal_behavior
		requires guard_add_sp(so,sp);
		assignable machine.service_providers;
		ensures guard_add_sp(so,sp) &&  machine.get_service_providers().equals(\old((machine.get_service_providers().union(new BSet<Integer>(sp))))); 
	 also
		requires !guard_add_sp(so,sp);
		assignable \nothing;
		ensures true; */
	public void run_add_sp( Integer so, Integer sp){
		if(guard_add_sp(so,sp)) {
			BSet<Integer> service_providers_tmp = machine.get_service_providers();

			machine.set_service_providers((service_providers_tmp.union(new BSet<Integer>(sp))));

			System.out.println("add_sp executed so: " + so + " sp: " + sp + " ");
		}
	}

}
