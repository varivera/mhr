package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class view_record_nominated{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public view_record_nominated(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)) && !machine.get_hidden_records().has(r) && machine.get_restricted_nominated_access().has(new Pair<Integer,Integer>(n,r))); */
	public /*@ pure */ boolean guard_view_record_nominated( Integer c, Integer r, Integer n) {
		/*System.out.println(machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)));
		System.out.println(!machine.get_hidden_records().has(r));
		System.out.println(machine.get_restricted_nominated_access().has(new Pair<Integer,Integer>(n,r)));*/
		return (machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)) && !machine.get_hidden_records().has(r) && machine.get_restricted_nominated_access().has(new Pair<Integer,Integer>(n,r)));
	}

	/*@ public normal_behavior
		requires guard_view_record_nominated(c,r,n);
		assignable \nothing;
		ensures guard_view_record_nominated(c,r,n) && true; 
	 also
		requires !guard_view_record_nominated(c,r,n);
		assignable \nothing;
		ensures true; */
	public void run_view_record_nominated( Integer c, Integer r, Integer n){
		if(guard_view_record_nominated(c,r,n)) {


			System.out.println("view_record_nominated executed c: " + c + " r: " + r + " n: " + n + " ");
		}
	}

}
