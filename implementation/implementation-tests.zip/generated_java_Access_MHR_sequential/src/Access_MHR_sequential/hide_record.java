package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class hide_record{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public hide_record(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_records().has(r) && machine.get_consumer().has(c) && machine.get_restricted_records().has(r) || machine.get_general_records().has(r) && machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)) && !machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c))); */
	public /*@ pure */ boolean guard_hide_record( Integer c, Integer r) {
		return (machine.get_records().has(r) && machine.get_consumer().has(c) && machine.get_restricted_records().has(r) || machine.get_general_records().has(r) && machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)) && !machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c)));
	}

	/*@ public normal_behavior
		requires guard_hide_record(c,r);
		assignable machine.restricted_records, machine.general_records, machine.hidden_records, machine.general_sp_access, machine.restricted_sp_access, machine.general_nominated_access, machine.restricted_nominated_access;
		ensures guard_hide_record(c,r) &&  machine.get_restricted_records().equals(\old(machine.get_restricted_records().difference(new BSet<Integer>(r)))) &&  machine.get_general_records().equals(\old(machine.get_general_records().difference(new BSet<Integer>(r)))) &&  machine.get_hidden_records().equals(\old((machine.get_hidden_records().union(new BSet<Integer>(r))))) &&  machine.get_general_sp_access().equals(\old(machine.get_general_sp_access().rangeSubtraction(new BSet<Integer>(r)))) &&  machine.get_restricted_sp_access().equals(\old(machine.get_restricted_sp_access().rangeSubtraction(new BSet<Integer>(r)))) &&  machine.get_general_nominated_access().equals(\old(machine.get_general_nominated_access().rangeSubtraction(new BSet<Integer>(r)))) &&  machine.get_restricted_nominated_access().equals(\old(machine.get_restricted_nominated_access().rangeSubtraction(new BSet<Integer>(r)))); 
	 also
		requires !guard_hide_record(c,r);
		assignable \nothing;
		ensures true; */
	public void run_hide_record( Integer c, Integer r){
		if(guard_hide_record(c,r)) {
			BSet<Integer> restricted_records_tmp = machine.get_restricted_records();
			BSet<Integer> general_records_tmp = machine.get_general_records();
			BSet<Integer> hidden_records_tmp = machine.get_hidden_records();
			BRelation<Integer,Integer> general_sp_access_tmp = machine.get_general_sp_access();
			BRelation<Integer,Integer> restricted_sp_access_tmp = machine.get_restricted_sp_access();
			BRelation<Integer,Integer> general_nominated_access_tmp = machine.get_general_nominated_access();
			BRelation<Integer,Integer> restricted_nominated_access_tmp = machine.get_restricted_nominated_access();

			machine.set_restricted_records(restricted_records_tmp.difference(new BSet<Integer>(r)));
			machine.set_general_records(general_records_tmp.difference(new BSet<Integer>(r)));
			machine.set_hidden_records((hidden_records_tmp.union(new BSet<Integer>(r))));
			machine.set_general_sp_access(general_sp_access_tmp.rangeSubtraction(new BSet<Integer>(r)));
			machine.set_restricted_sp_access(restricted_sp_access_tmp.rangeSubtraction(new BSet<Integer>(r)));
			machine.set_general_nominated_access(general_nominated_access_tmp.rangeSubtraction(new BSet<Integer>(r)));
			machine.set_restricted_nominated_access(restricted_nominated_access_tmp.rangeSubtraction(new BSet<Integer>(r)));

			System.out.println("hide_record executed c: " + c + " r: " + r + " ");
		}
	}

}
