package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class grant_general_access_to_nominated_authorised_rep{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public grant_general_access_to_nominated_authorised_rep(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (new BSet<Integer>(c,n).isSubset(machine.get_consumer()) && !c.equals(n) && machine.get_MyHR().has(new Pair<Integer,Integer>(c,mhr)) && machine.get_restricted_nominated().has(new Pair<Integer,Integer>(n,mhr)) && machine.get_consumer().has(a) && machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,mhr))); */
	public /*@ pure */ boolean guard_grant_general_access_to_nominated_authorised_rep( Integer c, Integer mhr, Integer n, Integer a) {
		return (new BSet<Integer>(c,n).isSubset(machine.get_consumer()) && !c.equals(n) && machine.get_MyHR().has(new Pair<Integer,Integer>(c,mhr)) && machine.get_restricted_nominated().has(new Pair<Integer,Integer>(n,mhr)) && machine.get_consumer().has(a) && machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,mhr)));
	}

	/*@ public normal_behavior
		requires guard_grant_general_access_to_nominated_authorised_rep(c,mhr,n,a);
		assignable machine.general_nominated, machine.restricted_nominated, machine.full_access_nominated, machine.restricted_nominated_access, machine.general_nominated_access;
		ensures guard_grant_general_access_to_nominated_authorised_rep(c,mhr,n,a) &&  machine.get_general_nominated().equals(\old((machine.get_general_nominated().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr)))))) &&  machine.get_restricted_nominated().equals(\old(machine.get_restricted_nominated().difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr))))) &&  machine.get_full_access_nominated().equals(\old(machine.get_full_access_nominated().difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr))))) &&  machine.get_restricted_nominated_access().equals(\old(machine.get_restricted_nominated_access().difference(BRelation.cross(new BSet<Integer>(n),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(mhr)).restrictDomainTo(machine.get_restricted_records()).domain())))) &&  machine.get_general_nominated_access().equals(\old((machine.get_general_nominated_access().union(BRelation.cross(new BSet<Integer>(n),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(mhr)).restrictDomainTo(machine.get_general_records()).domain()))))); 
	 also
		requires !guard_grant_general_access_to_nominated_authorised_rep(c,mhr,n,a);
		assignable \nothing;
		ensures true; */
	public void run_grant_general_access_to_nominated_authorised_rep( Integer c, Integer mhr, Integer n, Integer a){
		if(guard_grant_general_access_to_nominated_authorised_rep(c,mhr,n,a)) {
			BRelation<Integer,Integer> general_nominated_tmp = machine.get_general_nominated();
			BRelation<Integer,Integer> restricted_nominated_tmp = machine.get_restricted_nominated();
			BRelation<Integer,Integer> full_access_nominated_tmp = machine.get_full_access_nominated();
			BRelation<Integer,Integer> restricted_nominated_access_tmp = machine.get_restricted_nominated_access();
			BRelation<Integer,Integer> general_nominated_access_tmp = machine.get_general_nominated_access();

			machine.set_general_nominated((general_nominated_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr)))));
			machine.set_restricted_nominated(restricted_nominated_tmp.difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr))));
			machine.set_full_access_nominated(full_access_nominated_tmp.difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(n,mhr))));
			machine.set_restricted_nominated_access(restricted_nominated_access_tmp.difference(BRelation.cross(new BSet<Integer>(n),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(mhr)).restrictDomainTo(machine.get_restricted_records()).domain())));
			machine.set_general_nominated_access((general_nominated_access_tmp.union(BRelation.cross(new BSet<Integer>(n),machine.get_records_mhr().restrictRangeTo(new BSet<Integer>(mhr)).restrictDomainTo(machine.get_general_records()).domain()))));

			System.out.println("grant_general_access_to_nominated_authorised_rep executed c: " + c + " mhr: " + mhr + " n: " + n + " a: " + a + " ");
		}
	}

}
