package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class opt_out{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public opt_out(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_consumer().has(c) && machine.get_system_operator().has(so) && !machine.get_general_nominated().domain().has(c) && !machine.get_restricted_nominated().domain().has(c) && !machine.get_full_access_nominated().domain().has(c)); */
	public /*@ pure */ boolean guard_opt_out( Integer c, Integer so) {
		return (machine.get_consumer().has(c) && machine.get_system_operator().has(so) && !machine.get_general_nominated().domain().has(c) && !machine.get_restricted_nominated().domain().has(c) && !machine.get_full_access_nominated().domain().has(c));
	}

	/*@ public normal_behavior
		requires guard_opt_out(c,so);
		assignable machine.consumer, machine.my_health_record_DB, machine.MyHR, machine.records, machine.records_mhr, machine.general_records, machine.restricted_records, machine.hidden_records, machine.records_ownership, machine.consumer_sp, machine.sp_MyHR_access, machine.general_sp_list, machine.restricted_sp_list, machine.revoked_sp_list, machine.general_sp_access, machine.restricted_sp_access, machine.general_nominated, machine.restricted_nominated, machine.full_access_nominated, machine.general_nominated_access, machine.restricted_nominated_access, machine.authorised_rep;
		ensures guard_opt_out(c,so) &&  machine.get_consumer().equals(\old(machine.get_consumer().difference(new BSet<Integer>(c)))) &&  machine.get_my_health_record_DB().equals(\old(machine.get_my_health_record_DB().difference(new BSet<Integer>(machine.get_MyHR().apply(c))))) &&  machine.get_MyHR().equals(\old(machine.get_MyHR().difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(c,machine.get_MyHR().apply(c)))))) &&  machine.get_records().equals(\old(machine.get_records().difference(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_records_mhr().equals(\old(machine.get_records_mhr().domainSubtraction(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_general_records().equals(\old(machine.get_general_records().difference(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_restricted_records().equals(\old(machine.get_restricted_records().difference(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_hidden_records().equals(\old(machine.get_hidden_records().difference(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_records_ownership().equals(\old(machine.get_records_ownership().rangeSubtraction(new BSet<Integer>(c)))) &&  machine.get_consumer_sp().equals(\old(machine.get_consumer_sp().domainSubtraction(new BSet<Integer>(c)))) &&  machine.get_sp_MyHR_access().equals(\old(machine.get_sp_MyHR_access().rangeSubtraction(new BSet<Integer>(machine.get_MyHR().apply(c))))) &&  machine.get_general_sp_list().equals(\old(machine.get_general_sp_list().rangeSubtraction(new BSet<Integer>(machine.get_MyHR().apply(c))))) &&  machine.get_restricted_sp_list().equals(\old(machine.get_restricted_sp_list().rangeSubtraction(new BSet<Integer>(machine.get_MyHR().apply(c))))) &&  machine.get_revoked_sp_list().equals(\old(machine.get_revoked_sp_list().rangeSubtraction(new BSet<Integer>(machine.get_MyHR().apply(c))))) &&  machine.get_general_sp_access().equals(\old(machine.get_general_sp_access().rangeSubtraction(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_restricted_sp_access().equals(\old(machine.get_restricted_sp_access().rangeSubtraction(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_general_nominated().equals(\old(machine.get_general_nominated().rangeSubtraction(new BSet<Integer>(machine.get_MyHR().apply(c))))) &&  machine.get_restricted_nominated().equals(\old(machine.get_restricted_nominated().rangeSubtraction(new BSet<Integer>(machine.get_MyHR().apply(c))))) &&  machine.get_full_access_nominated().equals(\old(machine.get_full_access_nominated().rangeSubtraction(new BSet<Integer>(machine.get_MyHR().apply(c))))) &&  machine.get_general_nominated_access().equals(\old(machine.get_general_nominated_access().rangeSubtraction(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_restricted_nominated_access().equals(\old(machine.get_restricted_nominated_access().rangeSubtraction(machine.get_records_ownership().inverse().image(new BSet<Integer>(c))))) &&  machine.get_authorised_rep().equals(\old(machine.get_authorised_rep().rangeSubtraction(new BSet<Integer>(machine.get_MyHR().apply(c))).domainSubtraction(new BSet<Integer>(c)))); 
	 also
		requires !guard_opt_out(c,so);
		assignable \nothing;
		ensures true; */
	public void run_opt_out( Integer c, Integer so){
		if(guard_opt_out(c,so)) {
			BSet<Integer> consumer_tmp = machine.get_consumer();
			BSet<Integer> my_health_record_DB_tmp = machine.get_my_health_record_DB();
			BRelation<Integer,Integer> MyHR_tmp = machine.get_MyHR();
			BSet<Integer> records_tmp = machine.get_records();
			BRelation<Integer,Integer> records_mhr_tmp = machine.get_records_mhr();
			BSet<Integer> general_records_tmp = machine.get_general_records();
			BSet<Integer> restricted_records_tmp = machine.get_restricted_records();
			BSet<Integer> hidden_records_tmp = machine.get_hidden_records();
			BRelation<Integer,Integer> records_ownership_tmp = machine.get_records_ownership();
			BRelation<Integer,Integer> consumer_sp_tmp = machine.get_consumer_sp();
			BRelation<Integer,Integer> sp_MyHR_access_tmp = machine.get_sp_MyHR_access();
			BRelation<Integer,Integer> general_sp_list_tmp = machine.get_general_sp_list();
			BRelation<Integer,Integer> restricted_sp_list_tmp = machine.get_restricted_sp_list();
			BRelation<Integer,Integer> revoked_sp_list_tmp = machine.get_revoked_sp_list();
			BRelation<Integer,Integer> general_sp_access_tmp = machine.get_general_sp_access();
			BRelation<Integer,Integer> restricted_sp_access_tmp = machine.get_restricted_sp_access();
			BRelation<Integer,Integer> general_nominated_tmp = machine.get_general_nominated();
			BRelation<Integer,Integer> restricted_nominated_tmp = machine.get_restricted_nominated();
			BRelation<Integer,Integer> full_access_nominated_tmp = machine.get_full_access_nominated();
			BRelation<Integer,Integer> general_nominated_access_tmp = machine.get_general_nominated_access();
			BRelation<Integer,Integer> restricted_nominated_access_tmp = machine.get_restricted_nominated_access();
			BRelation<Integer,Integer> authorised_rep_tmp = machine.get_authorised_rep();

			machine.set_consumer(consumer_tmp.difference(new BSet<Integer>(c)));
			machine.set_my_health_record_DB(my_health_record_DB_tmp.difference(new BSet<Integer>(MyHR_tmp.apply(c))));
			machine.set_MyHR(MyHR_tmp.difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(c,MyHR_tmp.apply(c)))));
			machine.set_records(records_tmp.difference(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_records_mhr(records_mhr_tmp.domainSubtraction(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_general_records(general_records_tmp.difference(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_restricted_records(restricted_records_tmp.difference(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_hidden_records(hidden_records_tmp.difference(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_records_ownership(records_ownership_tmp.rangeSubtraction(new BSet<Integer>(c)));
			machine.set_consumer_sp(consumer_sp_tmp.domainSubtraction(new BSet<Integer>(c)));
			machine.set_sp_MyHR_access(sp_MyHR_access_tmp.rangeSubtraction(new BSet<Integer>(MyHR_tmp.apply(c))));
			machine.set_general_sp_list(general_sp_list_tmp.rangeSubtraction(new BSet<Integer>(MyHR_tmp.apply(c))));
			machine.set_restricted_sp_list(restricted_sp_list_tmp.rangeSubtraction(new BSet<Integer>(MyHR_tmp.apply(c))));
			machine.set_revoked_sp_list(revoked_sp_list_tmp.rangeSubtraction(new BSet<Integer>(MyHR_tmp.apply(c))));
			machine.set_general_sp_access(general_sp_access_tmp.rangeSubtraction(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_restricted_sp_access(restricted_sp_access_tmp.rangeSubtraction(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_general_nominated(general_nominated_tmp.rangeSubtraction(new BSet<Integer>(MyHR_tmp.apply(c))));
			machine.set_restricted_nominated(restricted_nominated_tmp.rangeSubtraction(new BSet<Integer>(MyHR_tmp.apply(c))));
			machine.set_full_access_nominated(full_access_nominated_tmp.rangeSubtraction(new BSet<Integer>(MyHR_tmp.apply(c))));
			machine.set_general_nominated_access(general_nominated_access_tmp.rangeSubtraction(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_restricted_nominated_access(restricted_nominated_access_tmp.rangeSubtraction(records_ownership_tmp.inverse().image(new BSet<Integer>(c))));
			machine.set_authorised_rep(authorised_rep_tmp.rangeSubtraction(new BSet<Integer>(MyHR_tmp.apply(c))).domainSubtraction(new BSet<Integer>(c)));

			System.out.println("opt_out executed c: " + c + " so: " + so + " ");
		}
	}

}
