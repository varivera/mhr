package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class revoke_access_sp{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public revoke_access_sp(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_service_providers().has(sp) && machine.get_my_health_record_DB().has(mhr) && machine.get_consumer().has(c) && machine.get_MyHR().has(new Pair<Integer,Integer>(c,mhr)) && machine.get_consumer_sp().has(new Pair<Integer,Integer>(c,sp)) && !machine.get_revoked_sp_list().has(new Pair<Integer,Integer>(sp,machine.get_MyHR().apply(c))) && !machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c))); */
	public /*@ pure */ boolean guard_revoke_access_sp( Integer c, Integer mhr, Integer sp) {
		return (machine.get_service_providers().has(sp) && machine.get_my_health_record_DB().has(mhr) && machine.get_consumer().has(c) && machine.get_MyHR().has(new Pair<Integer,Integer>(c,mhr)) && machine.get_consumer_sp().has(new Pair<Integer,Integer>(c,sp)) && !machine.get_revoked_sp_list().has(new Pair<Integer,Integer>(sp,machine.get_MyHR().apply(c))) && !machine.get_authorised_rep().range().has(machine.get_MyHR().apply(c)));
	}

	/*@ public normal_behavior
		requires guard_revoke_access_sp(c,mhr,sp);
		assignable machine.revoked_sp_list, machine.restricted_sp_list, machine.general_sp_list, machine.general_sp_access, machine.restricted_sp_access;
		ensures guard_revoke_access_sp(c,mhr,sp) &&  machine.get_revoked_sp_list().equals(\old((machine.get_revoked_sp_list().union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,mhr)))))) &&  machine.get_restricted_sp_list().equals(\old(machine.get_restricted_sp_list().difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,mhr))))) &&  machine.get_general_sp_list().equals(\old(machine.get_general_sp_list().difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,mhr))))) &&  machine.get_general_sp_access().equals(\old(machine.get_general_sp_access().difference(machine.get_general_sp_access().restrictDomainTo(new BSet<Integer>(sp)).restrictRangeTo(machine.get_records_mhr().inverse().image(new BSet<Integer>(mhr)))))) &&  machine.get_restricted_sp_access().equals(\old(machine.get_restricted_sp_access().difference(machine.get_restricted_sp_access().restrictDomainTo(new BSet<Integer>(sp)).restrictRangeTo(machine.get_records_mhr().inverse().image(new BSet<Integer>(mhr)))))); 
	 also
		requires !guard_revoke_access_sp(c,mhr,sp);
		assignable \nothing;
		ensures true; */
	public void run_revoke_access_sp( Integer c, Integer mhr, Integer sp){
		if(guard_revoke_access_sp(c,mhr,sp)) {
			BRelation<Integer,Integer> revoked_sp_list_tmp = machine.get_revoked_sp_list();
			BRelation<Integer,Integer> restricted_sp_list_tmp = machine.get_restricted_sp_list();
			BRelation<Integer,Integer> general_sp_list_tmp = machine.get_general_sp_list();
			BRelation<Integer,Integer> general_sp_access_tmp = machine.get_general_sp_access();
			BRelation<Integer,Integer> restricted_sp_access_tmp = machine.get_restricted_sp_access();

			machine.set_revoked_sp_list((revoked_sp_list_tmp.union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,mhr)))));
			machine.set_restricted_sp_list(restricted_sp_list_tmp.difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,mhr))));
			machine.set_general_sp_list(general_sp_list_tmp.difference(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(sp,mhr))));
			machine.set_general_sp_access(general_sp_access_tmp.difference(general_sp_access_tmp.restrictDomainTo(new BSet<Integer>(sp)).restrictRangeTo(machine.get_records_mhr().inverse().image(new BSet<Integer>(mhr)))));
			machine.set_restricted_sp_access(restricted_sp_access_tmp.difference(restricted_sp_access_tmp.restrictDomainTo(new BSet<Integer>(sp)).restrictRangeTo(machine.get_records_mhr().inverse().image(new BSet<Integer>(mhr)))));

			System.out.println("revoke_access_sp executed c: " + c + " mhr: " + mhr + " sp: " + sp + " ");
		}
	}

}
