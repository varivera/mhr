package Access_MHR_sequential;
import java.util.Random;
import Util.Utilities;
import eventb_prelude.*;

public class Test_ref3_authorised_reps{


	static Random rnd = new Random();
	static Integer max_size_BSet = 10;
	Integer min_integer = Utilities.min_integer;
	Integer max_integer = Utilities.max_integer;

	public Integer GenerateRandomInteger(){
		BSet<Integer> S =  new BSet<Integer>(
				new Enumerated(min_integer, max_integer)
				);
		/** User defined code that reflects axioms and theorems: Begin **/

		/** User defined code that reflects axioms and theorems: End **/

		return (Integer) S.toArray()[rnd.nextInt(S.size())];
	}

	public boolean GenerateRandomBoolean(){
		boolean res = (Boolean) BOOL.instance.toArray()[rnd.nextInt(2)];

		/** User defined code that reflects axioms and theorems: Begin **/

		/** User defined code that reflects axioms and theorems: End **/

		return res;
	}


	public BSet<Integer> GenerateRandomIntegerBSet(){
		int size = rnd.nextInt(max_size_BSet);
		BSet<Integer> S = new BSet<Integer>();
		while (S.size() != size){
			S.add(GenerateRandomInteger());
		}

		/** User defined code that reflects axioms and theorems: Begin **/

		/** User defined code that reflects axioms and theorems: End **/

		return S;
	}

	public BSet<Boolean> GenerateRandomBooleanBSet(){
		int size = rnd.nextInt(2);
		BSet<Boolean> res = new BSet<Boolean>();
		if (size == 0){
			res = new BSet<Boolean>(GenerateRandomBoolean());
		}else{
			res = new BSet<Boolean>(true,false);
		}

		/** User defined code that reflects axioms and theorems: Begin **/

		/** User defined code that reflects axioms and theorems: End **/

		return res;
	}

	public BRelation<Integer,Integer> GenerateRandomBRelation(){
		BRelation<Integer,Integer> res = new BRelation<Integer,Integer>();
		int size = rnd.nextInt(max_size_BSet);
		while (res.size() != size){
			res.add(
					new Pair<Integer, Integer>(GenerateRandomInteger(), GenerateRandomInteger()));
		}
		/** User defined code that reflects axioms and theorems: Begin **/

		/** User defined code that reflects axioms and theorems: End **/

		return res;
	}

	public static void main(String[] args){
		Test_ref3_authorised_reps test = new Test_ref3_authorised_reps();

		/** User defined code that reflects axioms and theorems: Begin **/
		/** User defined code that reflects axioms and theorems: End **/

		/*
		 * ref3_authorised_reps machine = new ref3_authorised_reps(); int n = 47; //the
		 * number of events in the machine //Init values for parameters in event: opt_in
		 * Integer c = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: opt_out Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer so = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: view_record_owner Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: view_record_authorised_rep Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: view_record_nominated Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: view_record_service_provider Integer c
		 * = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: delete_record_owner Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: delete_record_authorised_rep Integer c
		 * = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: upload_general_record_owner Integer ow
		 * = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: upload_general_record_authorised_rep
		 * Integer ow = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: upload_restricted_record_owner Integer
		 * ow = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * upload_restricted_record_authorised_rep Integer ow = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: upload_general_record_nominated
		 * Integer ow = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: upload_restricted_record_nominated
		 * Integer ow = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: upload_general_record_SP Integer ow =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: upload_restricted_record_SP Integer ow
		 * = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: restrict_record Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: restrict_record_authorised_rep Integer
		 * c = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: general_record Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: general_record_authorised_rep Integer
		 * c = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: hide_record Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: hide_record_authorised_rep Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: unhide_record Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: unhide_record_authorised_rep Integer c
		 * = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: add_consumer_sp Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: add_consumer_sp_authorised_rep Integer
		 * c = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: add_sp Integer so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: revoke_access_sp Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: revoke_access_sp_authorised_rep
		 * Integer c = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: give_restricted_access_sp Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * give_restricted_access_sp_authorised_rep Integer c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: give_general_access_sp Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: give_general_access_sp_authorised_rep
		 * Integer c = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: add_nominated Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: add_nominated_authorised_rep Integer c
		 * = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: delete_general_nominated Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * delete_general_nominated_authorised_rep Integer c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * grant_restrict_access_to_general_nominated Integer c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * grant_restrict_access_to_general_nominated_authorised_rep Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * grant_restrict_access_to_full_access_nominated Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * grant_restrict_access_to_full_access_nominated_authorised_rep Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: grant_general_access_to_nominated
		 * Integer c = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * grant_general_access_to_nominated_authorised_rep Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: grant_full_access_to_nominated Integer
		 * c = Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event:
		 * grant_full_access_to_nominated_authorised_rep Integer c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: add_authorised Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * //Init values for parameters in event: delete_authorised Integer a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); Integer mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); Integer so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer))));
		 * 
		 * while (true){ switch (rnd.nextInt(n)){ case 0: if
		 * (machine.evt_opt_in.guard_opt_in(c,mhr,so))
		 * machine.evt_opt_in.run_opt_in(c,mhr,so); break; case 1: if
		 * (machine.evt_opt_out.guard_opt_out(c,so))
		 * machine.evt_opt_out.run_opt_out(c,so); break; case 2: if
		 * (machine.evt_view_record_owner.guard_view_record_owner(c,r))
		 * machine.evt_view_record_owner.run_view_record_owner(c,r); break; case 3: if
		 * (machine.evt_view_record_authorised_rep.guard_view_record_authorised_rep(c,r,
		 * a))
		 * machine.evt_view_record_authorised_rep.run_view_record_authorised_rep(c,r,a);
		 * break; case 4: if
		 * (machine.evt_view_record_nominated.guard_view_record_nominated(c,r,n))
		 * machine.evt_view_record_nominated.run_view_record_nominated(c,r,n); break;
		 * case 5: if
		 * (machine.evt_view_record_service_provider.guard_view_record_service_provider(
		 * c,r,sp))
		 * machine.evt_view_record_service_provider.run_view_record_service_provider(c,r
		 * ,sp); break; case 6: if
		 * (machine.evt_delete_record_owner.guard_delete_record_owner(c,r))
		 * machine.evt_delete_record_owner.run_delete_record_owner(c,r); break; case 7:
		 * if
		 * (machine.evt_delete_record_authorised_rep.guard_delete_record_authorised_rep(
		 * c,r,a))
		 * machine.evt_delete_record_authorised_rep.run_delete_record_authorised_rep(c,r
		 * ,a); break; case 8: if
		 * (machine.evt_upload_general_record_owner.guard_upload_general_record_owner(ow
		 * ,r))
		 * machine.evt_upload_general_record_owner.run_upload_general_record_owner(ow,r)
		 * ; break; case 9: if (machine.evt_upload_general_record_authorised_rep.
		 * guard_upload_general_record_authorised_rep(ow,r,a))
		 * machine.evt_upload_general_record_authorised_rep.
		 * run_upload_general_record_authorised_rep(ow,r,a); break; case 10: if
		 * (machine.evt_upload_restricted_record_owner.
		 * guard_upload_restricted_record_owner(ow,r))
		 * machine.evt_upload_restricted_record_owner.run_upload_restricted_record_owner
		 * (ow,r); break; case 11: if
		 * (machine.evt_upload_restricted_record_authorised_rep.
		 * guard_upload_restricted_record_authorised_rep(ow,r,a))
		 * machine.evt_upload_restricted_record_authorised_rep.
		 * run_upload_restricted_record_authorised_rep(ow,r,a); break; case 12: if
		 * (machine.evt_upload_general_record_nominated.
		 * guard_upload_general_record_nominated(ow,r,n))
		 * machine.evt_upload_general_record_nominated.
		 * run_upload_general_record_nominated(ow,r,n); break; case 13: if
		 * (machine.evt_upload_restricted_record_nominated.
		 * guard_upload_restricted_record_nominated(ow,r,n))
		 * machine.evt_upload_restricted_record_nominated.
		 * run_upload_restricted_record_nominated(ow,r,n); break; case 14: if
		 * (machine.evt_upload_general_record_SP.guard_upload_general_record_SP(ow,r,sp)
		 * ) machine.evt_upload_general_record_SP.run_upload_general_record_SP(ow,r,sp);
		 * break; case 15: if
		 * (machine.evt_upload_restricted_record_SP.guard_upload_restricted_record_SP(ow
		 * ,r,sp))
		 * machine.evt_upload_restricted_record_SP.run_upload_restricted_record_SP(ow,r,
		 * sp); break; case 16: if
		 * (machine.evt_restrict_record.guard_restrict_record(c,r))
		 * machine.evt_restrict_record.run_restrict_record(c,r); break; case 17: if
		 * (machine.evt_restrict_record_authorised_rep.
		 * guard_restrict_record_authorised_rep(c,r,a))
		 * machine.evt_restrict_record_authorised_rep.run_restrict_record_authorised_rep
		 * (c,r,a); break; case 18: if
		 * (machine.evt_general_record.guard_general_record(c,r))
		 * machine.evt_general_record.run_general_record(c,r); break; case 19: if
		 * (machine.evt_general_record_authorised_rep.
		 * guard_general_record_authorised_rep(c,r,a))
		 * machine.evt_general_record_authorised_rep.run_general_record_authorised_rep(c
		 * ,r,a); break; case 20: if (machine.evt_hide_record.guard_hide_record(c,r))
		 * machine.evt_hide_record.run_hide_record(c,r); break; case 21: if
		 * (machine.evt_hide_record_authorised_rep.guard_hide_record_authorised_rep(c,r,
		 * a))
		 * machine.evt_hide_record_authorised_rep.run_hide_record_authorised_rep(c,r,a);
		 * break; case 22: if (machine.evt_unhide_record.guard_unhide_record(c,r,so))
		 * machine.evt_unhide_record.run_unhide_record(c,r,so); break; case 23: if
		 * (machine.evt_unhide_record_authorised_rep.guard_unhide_record_authorised_rep(
		 * c,r,so,a))
		 * machine.evt_unhide_record_authorised_rep.run_unhide_record_authorised_rep(c,r
		 * ,so,a); break; case 24: if
		 * (machine.evt_add_consumer_sp.guard_add_consumer_sp(c,sp))
		 * machine.evt_add_consumer_sp.run_add_consumer_sp(c,sp); break; case 25: if
		 * (machine.evt_add_consumer_sp_authorised_rep.
		 * guard_add_consumer_sp_authorised_rep(c,sp,a))
		 * machine.evt_add_consumer_sp_authorised_rep.run_add_consumer_sp_authorised_rep
		 * (c,sp,a); break; case 26: if (machine.evt_add_sp.guard_add_sp(so,sp))
		 * machine.evt_add_sp.run_add_sp(so,sp); break; case 27: if
		 * (machine.evt_revoke_access_sp.guard_revoke_access_sp(c,mhr,sp))
		 * machine.evt_revoke_access_sp.run_revoke_access_sp(c,mhr,sp); break; case 28:
		 * if (machine.evt_revoke_access_sp_authorised_rep.
		 * guard_revoke_access_sp_authorised_rep(c,mhr,sp,a))
		 * machine.evt_revoke_access_sp_authorised_rep.
		 * run_revoke_access_sp_authorised_rep(c,mhr,sp,a); break; case 29: if
		 * (machine.evt_give_restricted_access_sp.guard_give_restricted_access_sp(c,mhr,
		 * sp))
		 * machine.evt_give_restricted_access_sp.run_give_restricted_access_sp(c,mhr,sp)
		 * ; break; case 30: if (machine.evt_give_restricted_access_sp_authorised_rep.
		 * guard_give_restricted_access_sp_authorised_rep(c,mhr,sp,a))
		 * machine.evt_give_restricted_access_sp_authorised_rep.
		 * run_give_restricted_access_sp_authorised_rep(c,mhr,sp,a); break; case 31: if
		 * (machine.evt_give_general_access_sp.guard_give_general_access_sp(c,mhr,sp))
		 * machine.evt_give_general_access_sp.run_give_general_access_sp(c,mhr,sp);
		 * break; case 32: if (machine.evt_give_general_access_sp_authorised_rep.
		 * guard_give_general_access_sp_authorised_rep(c,mhr,sp,a))
		 * machine.evt_give_general_access_sp_authorised_rep.
		 * run_give_general_access_sp_authorised_rep(c,mhr,sp,a); break; case 33: if
		 * (machine.evt_add_nominated.guard_add_nominated(c,mhr,n))
		 * machine.evt_add_nominated.run_add_nominated(c,mhr,n); break; case 34: if
		 * (machine.evt_add_nominated_authorised_rep.guard_add_nominated_authorised_rep(
		 * c,mhr,n,a))
		 * machine.evt_add_nominated_authorised_rep.run_add_nominated_authorised_rep(c,
		 * mhr,n,a); break; case 35: if
		 * (machine.evt_delete_general_nominated.guard_delete_general_nominated(c,mhr,n)
		 * ) machine.evt_delete_general_nominated.run_delete_general_nominated(c,mhr,n);
		 * break; case 36: if (machine.evt_delete_general_nominated_authorised_rep.
		 * guard_delete_general_nominated_authorised_rep(c,mhr,n,a))
		 * machine.evt_delete_general_nominated_authorised_rep.
		 * run_delete_general_nominated_authorised_rep(c,mhr,n,a); break; case 37: if
		 * (machine.evt_grant_restrict_access_to_general_nominated.
		 * guard_grant_restrict_access_to_general_nominated(c,mhr,n))
		 * machine.evt_grant_restrict_access_to_general_nominated.
		 * run_grant_restrict_access_to_general_nominated(c,mhr,n); break; case 38: if
		 * (machine.evt_grant_restrict_access_to_general_nominated_authorised_rep.
		 * guard_grant_restrict_access_to_general_nominated_authorised_rep(c,mhr,n,a))
		 * machine.evt_grant_restrict_access_to_general_nominated_authorised_rep.
		 * run_grant_restrict_access_to_general_nominated_authorised_rep(c,mhr,n,a);
		 * break; case 39: if
		 * (machine.evt_grant_restrict_access_to_full_access_nominated.
		 * guard_grant_restrict_access_to_full_access_nominated(c,mhr,n))
		 * machine.evt_grant_restrict_access_to_full_access_nominated.
		 * run_grant_restrict_access_to_full_access_nominated(c,mhr,n); break; case 40:
		 * if
		 * (machine.evt_grant_restrict_access_to_full_access_nominated_authorised_rep.
		 * guard_grant_restrict_access_to_full_access_nominated_authorised_rep(c,mhr,n,a
		 * )) machine.evt_grant_restrict_access_to_full_access_nominated_authorised_rep.
		 * run_grant_restrict_access_to_full_access_nominated_authorised_rep(c,mhr,n,a);
		 * break; case 41: if (machine.evt_grant_general_access_to_nominated.
		 * guard_grant_general_access_to_nominated(c,mhr,n))
		 * machine.evt_grant_general_access_to_nominated.
		 * run_grant_general_access_to_nominated(c,mhr,n); break; case 42: if
		 * (machine.evt_grant_general_access_to_nominated_authorised_rep.
		 * guard_grant_general_access_to_nominated_authorised_rep(c,mhr,n,a))
		 * machine.evt_grant_general_access_to_nominated_authorised_rep.
		 * run_grant_general_access_to_nominated_authorised_rep(c,mhr,n,a); break; case
		 * 43: if (machine.evt_grant_full_access_to_nominated.
		 * guard_grant_full_access_to_nominated(c,mhr,n))
		 * machine.evt_grant_full_access_to_nominated.run_grant_full_access_to_nominated
		 * (c,mhr,n); break; case 44: if
		 * (machine.evt_grant_full_access_to_nominated_authorised_rep.
		 * guard_grant_full_access_to_nominated_authorised_rep(c,mhr,n,a))
		 * machine.evt_grant_full_access_to_nominated_authorised_rep.
		 * run_grant_full_access_to_nominated_authorised_rep(c,mhr,n,a); break; case 45:
		 * if (machine.evt_add_authorised.guard_add_authorised(a,mhr,so))
		 * machine.evt_add_authorised.run_add_authorised(a,mhr,so); break; case 46: if
		 * (machine.evt_delete_authorised.guard_delete_authorised(a,mhr,so))
		 * machine.evt_delete_authorised.run_delete_authorised(a,mhr,so); break; } c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); ow = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); ow = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); ow =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); ow =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); ow = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); ow =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); ow = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); ow =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); r = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); r =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); so = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); sp =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); sp = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); c =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); n =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); c = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); n = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); a = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); mhr =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); so = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); a =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); mhr = Utilities.someVal(new
		 * BSet<Integer>((new Enumerated(1,Utilities.max_integer)))); so =
		 * Utilities.someVal(new BSet<Integer>((new
		 * Enumerated(1,Utilities.max_integer)))); }
		 */
	}

}
