package Access_MHR_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class view_record_authorised_rep{
	/*@ spec_public */ private ref3_authorised_reps machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public view_record_authorised_rep(ref3_authorised_reps m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)) && !machine.get_hidden_records().has(r) && machine.get_consumer().has(a) && machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,machine.get_MyHR().apply(c)))); */
	public /*@ pure */ boolean guard_view_record_authorised_rep( Integer c, Integer r, Integer a) {
		/*System.out.println(machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)));
		System.out.println(!machine.get_hidden_records().has(r));
		System.out.println(machine.get_consumer().has(a));
		System.out.println(machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,machine.get_MyHR().apply(c))));*/
		return (machine.get_records_ownership().has(new Pair<Integer,Integer>(r,c)) && !machine.get_hidden_records().has(r) && machine.get_consumer().has(a) && machine.get_authorised_rep().has(new Pair<Integer,Integer>(a,machine.get_MyHR().apply(c))));
	}

	/*@ public normal_behavior
		requires guard_view_record_authorised_rep(c,r,a);
		assignable \nothing;
		ensures guard_view_record_authorised_rep(c,r,a) && true; 
	 also
		requires !guard_view_record_authorised_rep(c,r,a);
		assignable \nothing;
		ensures true; */
	public void run_view_record_authorised_rep( Integer c, Integer r, Integer a){
		if(guard_view_record_authorised_rep(c,r,a)) {


			System.out.println("view_record_authorised_rep executed c: " + c + " r: " + r + " a: " + a + " ");
		}
	}

}
